"""Atualização automática do Escritório Dark (só biblioteca padrão, grátis).

Roda sozinho no começo do iniciar.bat. Se não houver fonte configurada, ou se estiver sem
internet, ou se já estiver na última versão, não faz nada e o escritório abre normalmente.

Como funciona:
  1. Lê `fonte_atualizacao` do config.json: o endereço (https ou caminho de arquivo) de um
     manifesto JSON {"versao": "2026.11.05.1", "zip": "<endereço do zip>", "sha256": "<hash>"}.
  2. Se a versão for diferente da de `versao.txt`, baixa o zip e confere o sha256.
  3. Guarda uma cópia do código atual em backup-auto/<versao antiga>/ (mantém as 3 últimas).
  4. Troca só o código (escritorio/, painel/, scripts e documentação). NUNCA mexe em
     credenciais/, saida/, fundos/, clipes/, musica/, vozes/, prontos/, usados nem nos bancos
     de roteiros. config.json e canal.json só ganham as chaves novas; o que você mudou fica.
  5. Testa se o código novo compila e se o config.json continua válido. Se algo falhar,
     restaura o backup e o escritório abre na versão anterior.
Tudo fica registrado em atualizacao.log.
"""
from __future__ import annotations

import hashlib
import json
import py_compile
import shutil
import sys
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
LOG = RAIZ / "atualizacao.log"
# o que uma atualização pode trocar (pastas inteiras ou arquivos soltos)
CODIGO = ["escritorio", "painel", "escritorio_virtual.py", "autorizar_youtube.py", "atualizar.py",
          "instalar.bat", "instalar.sh", "iniciar.bat", "criar_atalho.bat", "README.md",
          "PROMPT-PARA-OUTRO-CHAT.md", "referencias.json"]
CAB = {"User-Agent": "EscritorioDark-Atualizador/1.0"}


def log(texto: str) -> None:
    linha = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {texto}"
    print(f"[atualizar] {texto}", flush=True)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(linha + "\n")
    except OSError:
        pass


def ler(endereco: str, timeout: int = 15) -> bytes:
    if endereco.startswith(("http://", "https://")):
        with urllib.request.urlopen(urllib.request.Request(endereco, headers=CAB), timeout=timeout) as r:
            return r.read()
    return Path(endereco).expanduser().read_bytes()


def versao_atual() -> str:
    arq = RAIZ / "versao.txt"
    return arq.read_text(encoding="utf-8").strip() if arq.exists() else "0"


def mesclar(novo: dict, atual: dict) -> dict:
    """Mantém tudo que o usuário já tem e acrescenta só as chaves que não existiam."""
    for chave, valor in novo.items():
        if chave not in atual:
            atual[chave] = valor
        elif isinstance(valor, dict) and isinstance(atual[chave], dict):
            mesclar(valor, atual[chave])
    return atual


def copiar(origem: Path, destino: Path) -> None:
    if origem.is_dir():
        if destino.exists():
            shutil.rmtree(destino)
        shutil.copytree(origem, destino, ignore=shutil.ignore_patterns("__pycache__"))
    else:
        destino.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(origem, destino)


def extrair(zip_bytes: bytes, pasta: Path) -> Path:
    zpath = pasta / "pacote.zip"
    zpath.write_bytes(zip_bytes)
    saida = pasta / "novo"
    with zipfile.ZipFile(zpath) as z:
        for nome in z.namelist():  # recusa caminhos que saem da pasta
            alvo = (saida / nome).resolve()
            if saida.resolve() not in alvo.parents and alvo != saida.resolve():
                raise ValueError(f"zip com caminho suspeito: {nome}")
        z.extractall(saida)
    topo = [p for p in saida.iterdir()]
    if len(topo) == 1 and topo[0].is_dir() and (topo[0] / "escritorio").exists():
        return topo[0]  # o zip tem a pasta escritorio-virtual/ no topo
    return saida


def testar() -> None:
    for arq in list((RAIZ / "escritorio").rglob("*.py")) + [RAIZ / "escritorio_virtual.py"]:
        py_compile.compile(str(arq), doraise=True, cfile=str(Path(tempfile.gettempdir()) / "ed_teste.pyc"))
    json.loads((RAIZ / "config.json").read_text(encoding="utf-8-sig"))
    for arq in (RAIZ / "canais").glob("*/canal.json"):
        json.loads(arq.read_text(encoding="utf-8-sig"))


def restaurar(backup: Path) -> None:
    for nome in CODIGO + ["config.json"]:
        if (backup / nome).exists():
            copiar(backup / nome, RAIZ / nome)
    for arq in backup.glob("canais/*/canal.json"):
        copiar(arq, RAIZ / "canais" / arq.parent.name / "canal.json")


def atualizar() -> int:
    try:
        cfg = json.loads((RAIZ / "config.json").read_text(encoding="utf-8-sig"))
    except Exception as e:
        log(f"config.json ilegível, não atualizei ({e})")
        return 1
    fonte = str(cfg.get("fonte_atualizacao") or "").strip()
    if not fonte or cfg.get("atualizar_sozinho") is False:
        return 0
    try:
        manifesto = json.loads(ler(fonte, 10).decode("utf-8-sig"))
    except Exception as e:
        log(f"sem como checar atualização agora ({str(e)[:80]}); abrindo como está")
        return 0
    nova, atual = str(manifesto.get("versao", "")).strip(), versao_atual()
    if not nova or nova == atual:
        return 0
    log(f"atualizando {atual} -> {nova}")
    backup = RAIZ / "backup-auto" / (atual.replace("/", "_") or "0")
    try:
        with tempfile.TemporaryDirectory() as tmp:
            dados = ler(manifesto["zip"], 120)
            if manifesto.get("sha256") and hashlib.sha256(dados).hexdigest() != manifesto["sha256"].lower():
                raise ValueError("sha256 do pacote não confere")
            origem = extrair(dados, Path(tmp))
            if backup.exists():
                shutil.rmtree(backup)
            backup.mkdir(parents=True)
            for nome in CODIGO + ["config.json"]:
                if (RAIZ / nome).exists():
                    copiar(RAIZ / nome, backup / nome)
            for arq in (RAIZ / "canais").glob("*/canal.json"):
                copiar(arq, backup / "canais" / arq.parent.name / "canal.json")
            try:
                for nome in CODIGO:
                    if (origem / nome).exists():
                        copiar(origem / nome, RAIZ / nome)
                if (origem / "config.json").exists():
                    novo = json.loads((origem / "config.json").read_text(encoding="utf-8-sig"))
                    (RAIZ / "config.json").write_text(
                        json.dumps(mesclar(novo, cfg), ensure_ascii=False, indent=2), encoding="utf-8")
                for arq in (origem / "canais").glob("*/canal.json") if (origem / "canais").exists() else []:
                    pasta = RAIZ / "canais" / arq.parent.name
                    if pasta.exists():  # canal novo só entra se o usuário criar a pasta
                        atualc = json.loads((pasta / "canal.json").read_text(encoding="utf-8-sig"))
                        (pasta / "canal.json").write_text(json.dumps(
                            mesclar(json.loads(arq.read_text(encoding="utf-8-sig")), atualc),
                            ensure_ascii=False, indent=2), encoding="utf-8")
                testar()
            except Exception:
                restaurar(backup)
                raise
        (RAIZ / "versao.txt").write_text(nova + "\n", encoding="utf-8")
        antigos = sorted((RAIZ / "backup-auto").iterdir(), key=lambda p: p.stat().st_mtime)
        for p in antigos[:-3]:
            shutil.rmtree(p, ignore_errors=True)
        log(f"pronto: agora na versão {nova}. Notas: {str(manifesto.get('notas', ''))[:200]}")
        return 0
    except Exception as e:
        log(f"atualização falhou e a versão {atual} foi mantida ({str(e)[:120]})")
        return 0  # nunca impede o escritório de abrir


if __name__ == "__main__":
    sys.exit(atualizar())
