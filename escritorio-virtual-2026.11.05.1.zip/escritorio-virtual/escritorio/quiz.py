"""Formato "Real ou IA?": o vídeo mostra fotos e desafia quem assiste a adivinhar quais são
reais (fotos da Wikimedia Commons) e quais foram criadas por inteligência artificial
(imagem gerada de graça no Pollinations). As coisas do banco são reais mas parecem falsas,
o que deixa o desafio difícil. O banco fica no quiz_real_ou_ia.json do canal (ou no da pasta
principal) e pode ganhar itens novos. Um item com "arquivo" usa exatamente aquela foto da Commons.
"""
from __future__ import annotations

import json
import random
from pathlib import Path

from . import canais
from .nucleo import RAIZ, Job

GANCHOS = [  # curtos: o gancho precisa prender nos primeiros 2 ou 3 segundos
    "Duvido você acertar o que é real e o que é IA!",
    "Só quem tem olho bom acerta todas!",
    "Real ou IA? Duvido você acertar!",
]
FINAIS = [
    "Comenta quantas você acertou!",
    "Quantas você acertou? Comenta aí!",
]
USADOS = RAIZ / "saida" / "quiz_usados.json"


def banco(pasta: Path | None = None) -> list[dict]:
    arq = pasta / "quiz_real_ou_ia.json" if pasta and (pasta / "quiz_real_ou_ia.json").exists() \
        else RAIZ / "quiz_real_ou_ia.json"
    return canais.ler(arq)


def pergunta(n: int, item: dict) -> str:
    return f"{item['nome'][0].upper()}{item['nome'][1:]}: real ou IA?"  # o número aparece na tela


def revelacao(item: dict) -> str:
    if item["resposta"] == "real":
        return f"É real! {item['fato']}"
    return f"É IA! Mas existe de verdade: {item['fato'][0].lower()}{item['fato'][1:]}"


def escolher(job: Job, qtd: int, pasta: Path | None = None) -> list[dict]:
    """Itens ainda não usados em vídeos anteriores. Quando sobram menos que o necessário, usa
    todos os que sobraram e completa com outros, que já abrem o próximo rodízio."""
    todos = banco(pasta)
    arq = pasta / "quiz_usados.json" if pasta else USADOS
    fora = canais.indisponiveis(arq)
    livres = [i for i in todos if i["foto"] not in fora]
    if len(livres) >= qtd:
        itens = random.sample(livres, qtd)
        canais.reservar(job, arq, [i["foto"] for i in itens])
        return itens
    resto = [i for i in todos if i not in livres]
    extra = random.sample(resto, min(qtd - len(livres), len(resto)))
    canais.reservar(job, arq, [i["foto"] for i in extra], novo_ciclo=True)
    itens = livres + extra
    random.shuffle(itens)
    return itens


def montar(job: Job, qtd: int = 4, pasta: Path | None = None) -> Job:
    """Roteiro do desafio. O Carregador busca as imagens e, se uma não vier, troca a resposta."""
    itens = [dict(i) for i in escolher(job, qtd, pasta)]
    # metade real e metade IA (sorteando a sobra), em ordem aleatória
    respostas = ["real", "ia"] * (len(itens) // 2) + [random.choice(["real", "ia"])] * (len(itens) % 2)
    random.shuffle(respostas)  # sempre tem pelo menos uma real e uma IA
    roteiro = [random.choice(GANCHOS)]
    for n, (item, resp) in enumerate(zip(itens, respostas), 1):
        item["resposta"] = resp
        item["q"] = len(roteiro)
        roteiro.append(pergunta(n, item))
        item["r"] = len(roteiro)
        roteiro.append(revelacao(item))
    roteiro.append(random.choice(FINAIS))
    job.tema = "real ou IA"
    job.roteiro = roteiro
    job.buscas = []
    job.arquivos["quiz"] = itens
    return job
