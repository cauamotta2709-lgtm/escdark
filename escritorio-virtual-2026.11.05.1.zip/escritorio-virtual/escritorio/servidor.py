"""Servidor do painel ao vivo: http://127.0.0.1:8765 (só biblioteca padrão do Python)."""
from __future__ import annotations

import json
import queue
import socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread

from .nucleo import RAIZ, Telemetria


def iniciar(tele: Telemetria, porta: int = 8765) -> ThreadingHTTPServer:
    class Painel(BaseHTTPRequestHandler):
        def log_message(self, *a):  # silencia o log de acesso
            pass

        def _enviar(self, corpo: bytes, tipo: str) -> None:
            self.send_response(200)
            self.send_header("Content-Type", tipo)
            self.send_header("Content-Length", str(len(corpo)))
            self.end_headers()
            self.wfile.write(corpo)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                topo = (b'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">'
                        b'<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">')
                self._enviar(topo + (RAIZ / "painel" / "index.html").read_bytes(), "text/html; charset=utf-8")
            elif self.path == "/estado":
                self._enviar(json.dumps(tele.instantaneo()).encode(), "application/json")
            elif self.path == "/eventos":
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-cache")
                self.end_headers()
                q = tele.ouvir()
                try:
                    self.wfile.write(f"data: {json.dumps({'tipo': 'tudo', 'dados': tele.instantaneo()})}\n\n".encode())
                    while True:
                        try:
                            ev = q.get(timeout=15)
                            self.wfile.write(f"data: {json.dumps(ev)}\n\n".encode())
                        except queue.Empty:
                            self.wfile.write(b": ping\n\n")
                        self.wfile.flush()
                except ConnectionError:  # navegador fechou ou recarregou (no Windows, WinError 10053)
                    pass
                finally:
                    tele.parar_de_ouvir(q)
            else:
                self.send_error(404)

    class Exclusivo(ThreadingHTTPServer):
        # sem isso, no Windows o servidor "divide" a porta com outro programa que já a usa
        # (um jogo, por exemplo) e o navegador acaba abrindo o outro programa
        allow_reuse_address = False

        def server_bind(self) -> None:
            if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            super().server_bind()

    for tentativa in range(porta, porta + 20):  # porta ocupada: tenta a próxima
        try:
            srv = Exclusivo(("127.0.0.1", tentativa), Painel)
            break
        except OSError:
            continue
    else:
        raise OSError(f"nenhuma porta livre entre {porta} e {porta + 19}")
    srv.daemon_threads = True
    Thread(target=srv.serve_forever, daemon=True).start()
    return srv
