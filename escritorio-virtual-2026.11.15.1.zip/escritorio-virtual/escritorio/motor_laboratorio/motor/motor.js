// Laboratório Otaku: linha do tempo, camadas fixas (fundo, cabeçalho, legenda) e transições.
// Recebe window.VIDEO = { roteiro, segs: [{id, cena, t0, t1, palavras:[{w,t,d}]}], duracao }.
'use strict';

const cv = document.getElementById('c');
const ctx = cv.getContext('2d');
const camadaA = new OffscreenCanvas(W, H), cA = camadaA.getContext('2d');
const camadaB = new OffscreenCanvas(W, H), cB = camadaB.getContext('2d');

const norm = s => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');

let BLOCOS = [], GRUPOS = [], CUES = [], DUR = 0, ROT = null;
const TRANS = 0.34;            // duração da transição entre cenas

function montar() {
  const V = window.VIDEO;
  ROT = V.roteiro; DUR = V.duracao;
  if (ROT.cor) PAL.cor = ROT.cor;
  if (ROT.cor2) PAL.cor2 = ROT.cor2;
  // agrupa segmentos consecutivos da mesma cena em blocos
  for (const s of V.segs) {
    const ult = BLOCOS[BLOCOS.length - 1];
    if (ult && ult.nome === s.cena) { ult.segs.push(s); }
    else BLOCOS.push({ nome: s.cena, segs: [s] });
  }
  BLOCOS.forEach((b, i) => {
    b.t0 = i === 0 ? 0 : Math.max(0, b.segs[0].t0 - 0.12);
    b.indice = i;
  });
  BLOCOS.forEach((b, i) => { b.t1 = i < BLOCOS.length - 1 ? BLOCOS[i + 1].t0 : DUR; b.dur = b.t1 - b.t0; });
  BLOCOS.forEach(b => {
    const palavras = b.segs.flatMap(s => s.palavras);
    b.palavras = palavras;
    b.fala0 = b.segs[0].t0;
    b.falaFim = b.segs[b.segs.length - 1].t1;
    // instante em que a n-ésima ocorrência de uma palavra começa (ou um valor padrão)
    b.palavra = (alvo, n = 0, padrao = null) => {
      const a = norm(alvo); let k = 0;
      for (const p of palavras) if (norm(p.w).startsWith(a)) { if (k === n) return p.t; k++; }
      return padrao ?? b.fala0;
    };
    b.fimPalavra = (alvo, n = 0) => {
      const a = norm(alvo); let k = 0;
      for (const p of palavras) if (norm(p.w).startsWith(a)) { if (k === n) return p.t + p.d; k++; }
      return b.falaFim;
    };
    b.seg = id => b.segs.find(s => s.id === id) || b.segs[0];
    const def = CENAS[b.nome];
    if (!def) throw new Error('Cena não existe: ' + b.nome);
    b.def = def;
  });

  // legendas: grupos curtos de palavras
  const todas = V.segs.flatMap(s => s.palavras.map(p => ({ ...p, seg: s.id })));
  let g = null;
  todas.forEach((p, i) => {
    const prox = todas[i + 1];
    if (!g) g = { palavras: [], t0: p.t };
    g.palavras.push(p);
    const txt = g.palavras.map(x => x.w).join(' ');
    const pontua = /[.,:;!?…]$/.test(p.w);
    const pausa = prox ? prox.t - (p.t + p.d) > 0.32 : true;
    const cheio = txt.length >= 15 || g.palavras.length >= 3;
    const proxLonga = prox && (txt.length + 1 + prox.w.length) > 19;
    if (!prox || pontua || pausa || cheio || proxLonga || prox.seg !== p.seg) {
      g.t1 = prox ? Math.min(prox.t, p.t + p.d + 0.55) : p.t + p.d + 0.6;
      GRUPOS.push(g); g = null;
    }
  });

  // efeitos sonoros: os das cenas + um "whoosh" em cada troca
  BLOCOS.forEach((b, i) => {
    if (i > 0) CUES.push({ t: b.t0 - 0.05, tipo: 'whoosh', ganho: 0.55 });
    if (b.def.sons) for (const c of b.def.sons(b)) CUES.push(c);
  });
  CUES.sort((a, b) => a.t - b.t);
}

// ---------------- fundo ----------------
const grao = (() => {
  const c = new OffscreenCanvas(256, 256), g = c.getContext('2d');
  const img = g.createImageData(256, 256), r = rng(99);
  for (let i = 0; i < img.data.length; i += 4) { const v = r() * 255; img.data[i] = img.data[i + 1] = img.data[i + 2] = v; img.data[i + 3] = 255; }
  g.putImageData(img, 0, 0); return c;
})();

function fundo(t) {
  const gr = ctx.createLinearGradient(0, 0, 0, H);
  gr.addColorStop(0, PAL.fundo2); gr.addColorStop(0.55, PAL.fundo1); gr.addColorStop(1, '#020308');
  ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
  // brilho central da cor do vídeo
  const rg = ctx.createRadialGradient(W / 2, 820, 0, W / 2, 820, 900);
  rg.addColorStop(0, rgba(PAL.cor, 0.10)); rg.addColorStop(1, rgba(PAL.cor, 0));
  ctx.fillStyle = rg; ctx.fillRect(0, 0, W, H);
  // grade técnica que desliza devagar
  const passo = 60, off = (t * 6) % passo;
  ctx.save(); ctx.lineWidth = 1;
  for (let x = -passo; x < W + passo; x += passo) { ctx.strokeStyle = (Math.round((x - off) / passo) % 4 === 0) ? PAL.gradeForte : PAL.grade; ctx.beginPath(); ctx.moveTo(x + off, 0); ctx.lineTo(x + off, H); ctx.stroke(); }
  for (let y = -passo; y < H + passo; y += passo) { ctx.strokeStyle = (Math.round((y - off) / passo) % 4 === 0) ? PAL.gradeForte : PAL.grade; ctx.beginPath(); ctx.moveTo(0, y + off); ctx.lineTo(W, y + off); ctx.stroke(); }
  ctx.restore();
  // poeira
  const r = rng(5);
  ctx.save();
  for (let i = 0; i < 46; i++) {
    const x0 = r() * W, y0 = r() * H, v = 8 + r() * 22, ph = r() * TAU, s = 1 + r() * 2.2;
    const y = (y0 - t * v + H * 4) % H, x = x0 + Math.sin(t * 0.4 + ph) * 18;
    ctx.globalAlpha = 0.15 + 0.25 * (0.5 + 0.5 * Math.sin(t * 1.3 + ph));
    ctx.fillStyle = i % 5 === 0 ? PAL.cor : PAL.tinta;
    ctx.beginPath(); ctx.arc(x, y, s, 0, TAU); ctx.fill();
  }
  ctx.restore();
}

function acabamento(t) {
  // vinheta
  const v = ctx.createRadialGradient(W / 2, H * 0.45, H * 0.3, W / 2, H * 0.45, H * 0.78);
  v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,0.62)');
  ctx.fillStyle = v; ctx.fillRect(0, 0, W, H);
  // grão de filme
  ctx.save(); ctx.globalAlpha = 0.045; ctx.globalCompositeOperation = 'overlay';
  const r = rng(Math.floor(t * 30) + 7), ox = -Math.floor(r() * 256), oy = -Math.floor(r() * 256);
  for (let x = ox; x < W; x += 256) for (let y = oy; y < H; y += 256) ctx.drawImage(grao, x, y);
  ctx.restore();
}

// ---------------- cabeçalho ----------------
function logo(c, x, y, s, t, alpha = 1) {
  c.save(); c.globalAlpha *= alpha; c.translate(x, y);
  c.strokeStyle = PAL.tinta; c.lineWidth = 3 * s;
  c.beginPath(); for (let i = 0; i < 6; i++) { const a = i * TAU / 6 + TAU / 12; c.lineTo(Math.cos(a) * 22 * s, Math.sin(a) * 22 * s); } c.closePath(); c.stroke();
  c.save(); c.rotate(t * 1.6); c.strokeStyle = PAL.cor; c.lineWidth = 2.5 * s;
  c.beginPath(); c.ellipse(0, 0, 14 * s, 5.5 * s, 0, 0, TAU); c.stroke();
  c.rotate(TAU / 3); c.beginPath(); c.ellipse(0, 0, 14 * s, 5.5 * s, 0, 0, TAU); c.stroke(); c.restore();
  c.fillStyle = PAL.cor; c.beginPath(); c.arc(0, 0, 4 * s, 0, TAU); c.fill();
  c.restore();
}

function cabecalho(t) {
  const a = entra(t, 0.15, 0.6);
  const y = 196;
  logo(ctx, 96, y, 1, t, a);
  texto(ctx, 'LABORATÓRIO OTAKU', 136, y + 1, { fonte: F.mono(28, 700), alinha: 'left', alpha: a * 0.95, espaco: 3 });
  const exp = 'EXP. ' + String(ROT.numero).padStart(3, '0');
  texto(ctx, exp, W - 78, y + 1, { fonte: F.mono(28, 700), alinha: 'right', cor: PAL.cor, alpha: a, espaco: 3 });
  // barra de progresso do vídeo
  const k = clamp(t / DUR);
  ctx.save(); ctx.globalAlpha = a;
  ctx.fillStyle = 'rgba(255,255,255,0.10)'; ctx.fillRect(78, y + 38, W - 156, 4);
  ctx.shadowColor = PAL.cor; ctx.shadowBlur = 14; ctx.fillStyle = PAL.cor; ctx.fillRect(78, y + 38, (W - 156) * k, 4);
  ctx.restore();
}

// ---------------- legenda ----------------
function legenda(t) {
  const g = GRUPOS.find(g => t >= g.t0 - 0.04 && t < g.t1);
  if (!g) return;
  const y = 1340, px = 82, fonte = F.texto(px, 900);
  const palavras = g.palavras.map(p => p.w.toUpperCase().replace(/[.,:;…]+$/, ''));
  ctx.save(); ctx.font = fonte; ctx.letterSpacing = '1px';
  const esp = ctx.measureText(' ').width;
  const ws = palavras.map(p => ctx.measureText(p).width);
  const total = ws.reduce((a, b) => a + b, 0) + esp * (ws.length - 1);
  const escala = Math.min(1, 920 / total);
  const kIn = entra(t, g.t0 - 0.04, 0.16, E.back);
  ctx.translate(W / 2, y); ctx.scale(escala * lerp(0.86, 1, kIn), escala * lerp(0.86, 1, kIn));
  let x = -total / 2;
  g.palavras.forEach((p, i) => {
    const ativa = t >= p.t - 0.03;
    const agora = t >= p.t - 0.03 && t < p.t + Math.max(p.d, 0.18);
    const pop = agora ? 1 + 0.08 * Math.sin(prog(t, p.t - 0.03, p.t + 0.2) * Math.PI) : 1;
    ctx.save(); ctx.translate(x + ws[i] / 2, 0); ctx.scale(pop, pop);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.lineJoin = 'round'; ctx.lineWidth = 16; ctx.strokeStyle = 'rgba(2,4,10,0.92)';
    ctx.strokeText(palavras[i], 0, 0);
    if (agora) { ctx.shadowColor = PAL.cor; ctx.shadowBlur = 26; }
    ctx.fillStyle = agora ? PAL.cor : (ativa ? PAL.tinta : 'rgba(233,238,251,0.55)');
    ctx.globalAlpha = kIn;
    ctx.fillText(palavras[i], 0, 0);
    ctx.restore();
    x += ws[i] + esp;
  });
  ctx.restore();
}

// ---------------- quadro ----------------
function desenharBloco(c, b, t) {
  c.clearRect(0, 0, W, H);
  c.save();
  // câmera: aproximação lenta e respiração leve
  const k = prog(t, b.t0, b.t1);
  const z = 1 + 0.04 * k;
  const dx = ruido1(t * 0.35, b.indice + 1) * 6, dy = ruido1(t * 0.3, b.indice + 9) * 6;
  c.translate(W / 2 + dx, 800 + dy); c.scale(z, z); c.translate(-W / 2, -800);
  b.def.desenhar(c, t, b);
  c.restore();
}

function quadro(t) {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; ctx.filter = 'none';
  fundo(t);
  let i = BLOCOS.findIndex(b => t >= b.t0 && t < b.t1);
  if (i < 0) i = BLOCOS.length - 1;
  const b = BLOCOS[i];
  const kT = i > 0 ? prog(t, b.t0, b.t0 + TRANS) : 1;
  desenharBloco(cA, b, t);
  if (kT < 1) {
    const ant = BLOCOS[i - 1];
    desenharBloco(cB, ant, t);
    const e = E.io(kT);
    // a cena que sai cresce, borra e some; a que entra vem de leve atrás
    ctx.save(); ctx.globalAlpha = 1 - e; ctx.filter = `blur(${(e * 14).toFixed(1)}px)`;
    ctx.translate(W / 2, 800); ctx.scale(1 + e * 0.18, 1 + e * 0.18); ctx.translate(-W / 2, -800);
    ctx.drawImage(camadaB, 0, 0); ctx.restore();
    ctx.save(); ctx.globalAlpha = e; ctx.filter = `blur(${((1 - e) * 10).toFixed(1)}px)`;
    ctx.translate(W / 2, 800); ctx.scale(0.9 + e * 0.1, 0.9 + e * 0.1); ctx.translate(-W / 2, -800);
    ctx.drawImage(camadaA, 0, 0); ctx.restore();
    // risco de luz na troca
    ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = Math.sin(e * Math.PI) * 0.22;
    const lg = ctx.createLinearGradient(0, 0, W, 0); lg.addColorStop(0, 'rgba(0,0,0,0)'); lg.addColorStop(0.5, PAL.cor); lg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = lg; ctx.fillRect(0, 0, W, H); ctx.restore();
  } else {
    ctx.drawImage(camadaA, 0, 0);
  }
  acabamento(t);
  cabecalho(t);
  legenda(t);
  // fade de entrada e saída
  const fi = 1 - prog(t, 0, 0.25), fo = prog(t, DUR - 0.35, DUR);
  const f = Math.max(fi, fo);
  if (f > 0) { ctx.fillStyle = `rgba(0,0,0,${f})`; ctx.fillRect(0, 0, W, H); }
}

window.__seek = t => quadro(t);

(async () => {
  await Promise.all([
    document.fonts.load(F.titulo(100)), document.fonts.load(F.mono(30, 400)), document.fonts.load(F.mono(30, 700)),
    document.fonts.load(F.texto(80, 900)), document.fonts.load(F.texto(80, 700))
  ]);
  await document.fonts.ready;
  montar();
  window.__duracao = DUR;
  window.__cues = CUES;
  window.__blocos = BLOCOS.map(b => ({ nome: b.nome, t0: b.t0, t1: b.t1 }));
  quadro(0);
  window.__pronto = true;
})().catch(e => { window.__erro = String(e.stack || e); console.error(e); });
