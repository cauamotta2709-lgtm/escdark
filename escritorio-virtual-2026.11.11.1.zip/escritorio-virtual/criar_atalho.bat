@echo off
REM Cria o atalho "Escritorio Dark" na area de trabalho. Rode uma vez.
cd /d "%~dp0"
powershell -NoProfile -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut(\"$d\Escritorio Dark.lnk\"); $s.TargetPath='%~dp0iniciar.bat'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.IconLocation='%SystemRoot%\System32\imageres.dll,190'; $s.Save()"
echo Atalho "Escritorio Dark" criado na area de trabalho.
pause
