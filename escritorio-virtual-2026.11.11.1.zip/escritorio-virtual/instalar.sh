#!/usr/bin/env bash
# Instala tudo o que o escritório usa. Tudo gratuito e open source.
# Linux/macOS. No Windows, rode dentro do WSL (Ubuntu).
set -e
cd "$(dirname "$0")"

if ! command -v ffmpeg >/dev/null; then
  if command -v apt-get >/dev/null; then sudo apt-get install -y ffmpeg; else brew install ffmpeg; fi
fi
python3 -m pip install --user -U psutil yt-dlp piper-tts edge-tts faster-whisper google-api-python-client google-auth-oauthlib
python3 -m pip install --user "av<14"  # o faster-whisper ainda não funciona com o av 14+

# Voz neural em português (Piper, roda offline)
mkdir -p vozes
base=https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/medium
[ -f vozes/pt_BR-faber-medium.onnx ] || curl -L -o vozes/pt_BR-faber-medium.onnx "$base/pt_BR-faber-medium.onnx"
[ -f vozes/pt_BR-faber-medium.onnx.json ] || curl -L -o vozes/pt_BR-faber-medium.onnx.json "$base/pt_BR-faber-medium.onnx.json"

# LLM local para roteiros e descrições (opcional, mas recomendado)
if ! command -v ollama >/dev/null; then
  echo "Instale o Ollama em https://ollama.com e depois rode: ollama pull llama3.2:3b"
else
  ollama pull llama3.2:3b
fi
echo "Pronto. Rode: python3 escritorio_virtual.py"
