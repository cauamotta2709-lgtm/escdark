# Prompt para continuar o Escritório Dark em outro chat

Cole tudo abaixo da linha no começo de um chat novo com o Claude. Junto, anexe o arquivo
escritorio-virtual.zip, sem a pasta credenciais, ou dê ao Claude acesso à pasta "Escritorio Dark".

---

Você vai continuar um projeto meu que já funciona. Leia este texto inteiro antes de mexer em qualquer coisa.

## Quem sou eu e como trabalhar comigo

- Sou o Cauã, uso Windows e falo português. Responda sempre em português simples, sem jargão.
- Não sou programador. Quando eu precisar fazer algo, diga o passo exato: qual pasta, qual arquivo, o que clicar e o que digitar.
- Tudo precisa ser grátis. Use só ferramentas gratuitas e de código aberto. Se algo for pago, me avise antes e dê uma alternativa grátis.
- Quero o máximo de automação, mas três coisas são só comigo:
  - criar contas;
  - ligar a postagem;
  - publicar.
- Não faça nenhuma delas sem eu pedir com essas palavras.
- Nunca me peça senha nem chave, e nunca abra, copie ou mostre nada da pasta `credenciais/`. O login no Google ou no TikTok eu faço no navegador.
- Antes de dizer que algo está pronto, teste. Se não deu para testar, diga isso com clareza.
- Se você tem acesso à minha pasta, mexa direto nela. Se não tem, me entregue o arquivo inteiro já pronto e diga em qual pasta ele vai e qual arquivo ele substitui. Antes, me peça para guardar uma cópia do arquivo antigo.
- Se não der para rodar um teste aí, me passe o comando exato e me peça para colar o que apareceu na tela.
- Para abrir o terminal na pasta certa: abro a pasta "Escritorio Dark", clico na barra de endereço, digito `cmd` e aperto Enter.

## Onde está o projeto

- Pasta no meu PC: `C:\Users\cauam\OneDrive\Área de Trabalho\Escritorio Dark`. É ela que vale.
- Em 19/10/2026 essa pasta ainda tinha a versão anterior, sem a pasta `canais\`.
- Primeiro passo de qualquer conversa: confira se existe `Escritorio Dark\canais\` com 5 pastas dentro. Se não existir, a pasta está velha. Pare e me guie para atualizar antes de mexer em qualquer coisa.
- Como atualizar:
  1. Abra o `escritorio-virtual.zip` e entre na pasta `escritorio-virtual` que fica dentro dele.
  2. Selecione tudo com Ctrl+A e copie com Ctrl+C.
  3. Cole com Ctrl+V dentro de "Escritorio Dark" e escolha "Substituir os arquivos no destino".
  4. Não extraia o zip direto, senão ele cria uma subpasta e nada é trocado.
  5. As pastas `credenciais`, `saida` e `vozes` continuam como estão. O `config.json` é trocado pelo novo.
- As pastas `Documents\escritorio-virtual` e `Área de Trabalho\escritorio-virtual` são cópias velhas. Não use.
- Leia primeiro o `README.md` e depois o `PERFIL.md` de cada canal, em `canais\<pasta>\`.

## O que é o projeto

O "Escritório Dark" é um escritório virtual de agentes de IA que faz vídeos curtos verticais sozinho. São canais "dark", sem rosto, para TikTok, YouTube Shorts e Instagram Reels. O objetivo é renda passiva com a monetização das plataformas. Um painel no navegador mostra cada agente trabalhando e o consumo do PC em tempo real.

Do que o projeto depende:
- O núcleo é Python, só com a biblioteca padrão, mais o ffmpeg.
- Também usa estes pacotes grátis, instalados pelo `instalar.bat`:
  - edge-tts, para a voz;
  - psutil, para o consumo no painel;
  - yt-dlp, para buscar referências;
  - piper-tts, para a voz sem internet;
  - faster-whisper, com av menor que 14;
  - google-api-python-client e google-auth-oauthlib, para o YouTube.
- O Ollama é opcional: é um programa grátis que roda uma IA no próprio PC. Não remova nenhum desses usos.
- Se um pacote faltar, o programa tem que continuar funcionando sem ele.
- Não adicione pacote novo sem necessidade e nunca adicione serviço pago.

### A linha de produção (pasta `escritorio\agentes\`)

1. **Olheiro** (`olheiro.py`): reveza entre os canais ativos e pega os itens do banco do canal. O roteiro segue a ordem do banco. Perguntas e fotos são sorteadas entre as que ainda não foram usadas.
2. **Carregador** (`carregador.py`) faz a narração e as imagens.
   - Voz: edge-tts, as vozes neurais grátis da Microsoft. Ele também dá o tempo de cada palavra para a legenda.
   - Se a voz do canal falhar, ele tenta 3 vezes e depois usa a voz Antonio, também com 3 tentativas.
   - Se o edge-tts não funcionar, ele usa o piper, mas só se existir `vozes\pt_BR-faber-medium.onnx`.
   - Depois tenta o espeak-ng, que o instalar.bat não instala. Por último, deixa silêncio no tempo de leitura.
   - A troca de voz é frase por frase. Se a voz do vídeo aparecer como "mista" ou "muda", o vídeo não deve ser postado.
   - Imagens: uma por frase. Vêm do Pollinations (IA grátis, sem conta), da Wikimedia Commons, da pasta `clipes\`, ou do Pexels e do Pixabay, se houver chave.
   - Foto da Commons com licença NC ou ND é pulada.
   - Se uma cena fica sem imagem (só o degradê gerado ou o mascote de reserva), o Editor põe nessa cena um vídeo da pasta `fundos\` (ou solto na pasta principal) na tela inteira, sem som e escurecido, com legenda e cartões por cima; a vinheta final do TikTok/CapCut é cortada sozinha. Desliga com `"video_sem_imagem": false`. Desde 31/10/2026 o Pollinations responde 402 (pagamento), então isso acontece em quase todo vídeo.
3. **Legendador** (`legendador.py`): faz a legenda karaokê em ASS, o título, o texto do post e as hashtags.
4. **Editor** (`editor.py`): monta o vídeo no ffmpeg.
   - Zoom lento em cada imagem. Cena de tela cheia com mais de 4,2 segundos é dividida em duas.
   - A música abaixa sozinha quando a voz fala, e o áudio sai em -14 LUFS.
   - Põe o crédito da música.
5. **Postador** (`postador.py`): grava `video.mp4`, `descricao.txt` e `post.json` em `canais\<pasta>\prontos\<código>\`.
   - O `<código>` tem 8 letras e números aleatórios. Para saber qual roteiro virou aquele vídeo, veja o `titulo` no `post.json`.
   - Ele monta a descrição final com os créditos das fotos, da IA e da música.
   - Só publica se `postar_de_verdade` for `true`. Hoje está `false`.

Outros arquivos:
- `escritorio\canais.py`: lê os canais e o banco de roteiros. `perguntas.py` monta o quiz Miau Quiz. `quiz.py` monta o Real ou IA, apesar do nome.
- Quando eu disser "quiz", é o Miau Quiz, da pasta `quiz-desafios`. Se ficar em dúvida, pergunte.
- `nucleo.py` é a base dos agentes e a telemetria. `servidor.py` e `painel\index.html` são o painel ao vivo.

### Arquivos de usados (não apague nem edite sem me perguntar)

- Durante o vídeo, o item fica separado na memória. Quando o Postador empacota o vídeo, o item é gravado como usado:
  - `canais\<pasta>\usados.json`: roteiros, pelo `id`;
  - `canais\<pasta>\perguntas_usadas.json`: quiz, pelo `id`;
  - `canais\<pasta>\quiz_usados.json`: Real ou IA, pelo `foto`.
- Nunca troque o `id` ou o `foto` de um item que já existe, senão ele volta a ser usado.
- Cada teste gasta itens de verdade, mesmo sem postar. Antes de testar, copie o arquivo de usados do canal. Depois, me pergunte se pode devolver a cópia e apagar o vídeo de teste de `prontos\`.
- Faça poucos testes.

## Os 5 canais (pasta `canais\`)

| Pasta | Nome sugerido | Formato | Voz (`voz_edge`, velocidade, tom) | Banco |
|---|---|---|---|---|
| animais-sobrevivencia | Bicho Extremo | roteiro, imagens 3D cartoon | Thalita, +14%, -2Hz | roteiros.json, 12 |
| espaco-universo | Órbita Curiosa | roteiro documental, pintura digital | Antonio, -3%, -4Hz (grave) | roteiros.json, 12 |
| curiosidades-cotidiano | Ninguém Te Explicou | roteiro, vetor chapado | Francisca, +12%, +0Hz | roteiros.json, 12 |
| quiz-desafios | Miau Quiz | 6 perguntas de 4 alternativas, com gato mascote | Francisca, +8%, +4Hz | perguntas.json, 88 |
| real-ou-ia | Olho de Pixel | 8 rodadas de "Real ou IA?" | Antonio, +12%, +0Hz | quiz_real_ou_ia.json, 69 |

Na tabela, a porcentagem é a velocidade da fala e o Hz é o tom: negativo deixa a voz mais grave.

Quanto rende cada banco:
- O painel mostra quantos vídeos o banco de cada canal ainda rende sem repetir. Com 3 ou menos, ele avisa no log.
- O quiz gasta 6 perguntas por vídeo: 88 dão 14 vídeos. O Real ou IA gasta 8 itens: 69 dão 8 vídeos.
- O quiz e o Real ou IA nunca param. Quando os itens acabam, eles voltam a repetir os antigos.
- Se o banco de roteiros chegar a zero, o canal faz um vídeo de reserva com fatos da Wikipédia. Esse vídeo sai curto, abaixo de 61 segundos, sem o estilo do canal e sem a conferência de fontes. Não é para postar. Reponha o banco antes.

Mascote e música:
- O mascote do quiz é criado na primeira vez em `canais\quiz-desafios\mascote.jpg`, com `mascote_semente` 52817.
- Apagar o arquivo gera o mesmo gato de novo. Para um gato diferente, troque a semente no `canal.json` ou ponha um desenho meu com esse nome.
- Cada canal tem uma pasta `musica\`. Músicas grátis vêm do YouTube Audio Library, Pixabay ou incompetech.
- Se a faixa pede crédito, ponha um `.txt` com o mesmo nome e o crédito na primeira linha.

### Como `canal.json` e `config.json` se juntam

- O `canal.json` vale por cima do `config.json`, chave por chave. Uma chave do canal troca a geral inteira, sem misturar.
- Por exemplo, se o canal tem `legenda`, ela substitui toda a `legenda` geral. Por isso, repita no canal todos os campos que você quer.
- Funcionam por canal:
  - voz: `voz_edge`, `voz_edge_velocidade`, `voz_edge_tom`;
  - vídeo: `legenda`, `palavras_por_tela`, `estilo_imagem`, `formatos`, `musica_volume`, `pausa_frases_s`, `duracao_minima_s`;
  - quiz: `quiz_perguntas`, `quiz_rodadas`, `quiz_pausa_s`, `mascote_semente`, `cor_cartao`, `cor_certo`;
  - postagem: `hashtags`, `rotulo_ia`, `ativo`, `plataformas`, `postar_de_verdade`, `postador`, `youtube_privacidade`, `tiktok_privacidade`, `postiz_contas`.
- Só funcionam no `config.json`: `videos_por_canal`, `intervalo_s`, `fila_max`, `copias`, `modelo`, `voz`, `piper_modelo`, `codificador`, `preset`, `threads_ffmpeg`, `manter_intermediarios`, `offline`.
- Para trocar algo de um canal só, mexa no `canal.json` dele. Mexer no `config.json` muda todos.
- As `hashtags` do canal entram antes das do roteiro, até 8 no total.
- Os valores de `formatos` são `"roteiro"`, `"perguntas"` e `"real_ou_ia"`.

### Legenda

- O padrão é karaokê em caixa alta, com até 3 palavras e 15 caracteres por tela. A palavra falada fica na cor de destaque.
- Destaque de cada canal:
  - animais: amarelo-âmbar;
  - curiosidades: coral;
  - espaço: ciano;
  - quiz e Real ou IA: amarelo padrão.
- No espaço, a legenda não fica em caixa alta e aparece como está escrita, com fonte 80, até 20 caracteres e 4 palavras.
- Campos de `legenda`, com os padrões:
  - `fonte` Arial, `tamanho` 92;
  - `cor` branco `&H00FFFFFF` e `destaque` amarelo `&H0000F6FF`;
  - `maiusculas` true, `max_caracteres` 15, `karaoke` true;
  - `altura` é a distância da legenda até a base da tela.
- A cor do ASS vem ao contrário do HTML: `&H00` mais azul, verde e vermelho. Por exemplo, o coral #FF6F61 vira `&H00616FFF`.
- No quiz, `cor_cartao` e `cor_certo` usam outro formato, sem o 00 e com & no fim, como `&HB1355E&`.
- Atenção: no `roteiros.json`, "legenda" é o texto do post. No `canal.json`, "legenda" é o estilo das letras do vídeo.

## Estilo dos vídeos (tirado dos shorts de referência que eu escolhi)

- Sem saudação. A primeira frase já é o gancho, com até 16 palavras.
- Fale com "você" pelo menos uma vez a cada duas frases.
- Uma ideia por frase, com 4 a 18 palavras. Depois de uma frase longa vem uma curta, de impacto.
- Conectivos de escalada variados, sem repetir no mesmo roteiro. Por exemplo: "mas isso nem é o pior", "só que tem um detalhe".
- Use números exatos e uma comparação com algo do Brasil quando couber, como "do tamanho de três Maracanãs".
- Nos roteiros, a narração não pede para seguir, curtir ou se inscrever. O fim é o clímax, uma moral curta ou um gancho que volta ao começo. Só o quiz pede para comentar o placar.
- O texto vai direto para a voz. Por isso:
  - sem emoji, parênteses ou siglas;
  - sem unidades abreviadas: escreva "quilômetros" e "por cento";
  - números podem ir em algarismos.
- Todo fato precisa ser verdadeiro e confirmado numa fonte que você conseguiu abrir agora: Wikipédia, universidades, museus, órgãos de governo ou revistas científicas.
- Nunca invente link. Se não conseguir abrir sites, me avise e não ponha o item no banco.
- Hipótese só com "pode", "talvez" ou "a hipótese mais aceita".
- Nunca use pessoa real viva como personagem. Não cite marcas.
- Nada de conselho de saúde nem de política. Caça entre animais pode, mas sem sangue nem detalhe forte.
- O vídeo precisa passar de 61 segundos, porque o TikTok só paga vídeo com mais de 1 minuto.
  - O `duracao_minima_s` só estica um pouco as pausas, até 0,45 s por frase, e depois só avisa no log.
  - Quem garante o tempo é o tamanho do roteiro. Depois de cada teste, confira o `duracao_s` no `post.json`.
- Imagens só de IA, da Commons com licença livre, do Pexels, do Pixabay ou da minha pasta `clipes\`. Nunca de busca geral na internet, por causa de direitos autorais.

## Formato dos bancos (para escrever itens novos)

Cada banco é uma lista JSON em UTF-8. Para pôr itens novos:
- Acrescente no fim do arquivo, sem apagar nem mudar os que já existem.
- Leia os atuais antes e não repita tema.
- O `id` não pode repetir nenhum do banco nem do arquivo de usados.
- Entregue o arquivo completo.
- Itens novos para o código distribuir pelas atualizações vão em `escritorio\bancos\<canal>\` (mesmo nome de arquivo e
  formato); `canais.banco()` junta os dois sem repetir `id` (ou `foto`), com os itens do canal primeiro.

**roteiros.json**, um item por vídeo:
```json
{"id": "slug-sem-acento-unico", "titulo": "até 60 caracteres, em pergunta ou desafio",
 "tema": "assunto", "legenda": "texto do post, até 150 caracteres, uma pergunta que puxe comentário",
 "hashtags": ["3 a 5", "sem #"], "frases": ["frase 1", "frase 2"],
 "imagens": [{"ia": "prompt em inglês da cena da frase 1"}, {"ia": "cena da frase 2"}],
 "fontes": ["https://..."]}
```
- Tem que haver exatamente uma imagem por frase, na mesma ordem.
- Conte só as palavras das frases. Os tamanhos dos roteiros atuais servem de medida:
  - animais: 197 a 211 palavras, 65 a 80 s;
  - curiosidades: 194 a 205 palavras, 61 a 75 s;
  - espaço: 169 a 190 palavras, 65 a 85 s, porque a voz é mais lenta e tem pausas maiores.
- Não escreva o estilo da imagem no prompt, porque o código põe o `estilo_imagem` do canal.
- No canal de animais, dentro de cada roteiro, o bicho principal é descrito com as mesmas palavras em todas as imagens. Por exemplo: "a cute cartoon octopus with big round eyes and soft orange skin".
- O primeiro link de `fontes` vai para o `post.json`.

**perguntas.json** (Miau Quiz):
```json
{"id": "mq089", "tema": "Espaço", "dificuldade": 1, "pergunta": "termina com ?",
 "alternativas": ["A", "B", "C", "D"], "correta": 0,
 "curiosidade": "frase falada depois de 'Letra X!'", "ia": "prompt em inglês da ilustração",
 "fonte": "https://..."}
```
- A dificuldade vai de 1 a 3, e cada vídeo mistura as três.
- São 4 alternativas diferentes, com até 26 caracteres cada. A narração não lê as alternativas.
- `correta` é o índice da certa, de 0 a 3. Varie a posição.
- A curiosidade de uma pergunta não pode entregar a resposta de outra.

**quiz_real_ou_ia.json** (Olho de Pixel): edite só `canais\real-ou-ia\quiz_real_ou_ia.json`. O da pasta principal é antigo e só vale sem canais.
```json
{"nome": "esse sapo transparente", "foto": "texto de busca na Commons",
 "arquivo": "File:Nome exato do arquivo na Commons.jpg", "licenca": "CC BY-SA 4.0",
 "ia": "prompt em inglês da versão falsa, parecida com a foto real", "fato": "frase sobre a coisa real",
 "fontes": ["https://..."]}
```
- Cada rodada mostra só uma imagem, sorteada: a foto real ou a versão de IA. As duas precisam ser boas.
- O `nome` começa com esse, essa, esses ou essas.
- O `foto` também marca o item como usado, então não pode repetir.
- O `arquivo` é o nome exato copiado da página da foto na Commons. Tem que ser .jpg ou .png com pelo menos 600x500 px, senão o programa busca pelo texto do `foto`.
- O `fato` tem que fazer sentido depois de "É real!" e também depois de "É IA! Mas existe de verdade:". No segundo caso, a primeira letra vira minúscula.
- `licenca` e `fontes` são só para conferência. O código confere a licença na Commons e pula NC e ND.

Para conferir se um banco abre, rode na pasta:
```
python -c "import json; d=json.load(open('canais/animais-sobrevivencia/roteiros.json', encoding='utf-8')); print(len(d), 'itens')"
```
Se der para rodar aí, confira também:
- ids repetidos;
- uma imagem por frase;
- número de palavras.

## Como rodar e testar

- Dois cliques no `iniciar.bat` ligam o escritório e abrem o painel em `http://127.0.0.1:8765`. Se a porta estiver ocupada, ele usa a próxima.
  - Ele faz uma rodada: `videos_por_canal` vídeos para cada canal ativo, hoje 1. Depois para.
  - Para parar antes, feche a janela preta ou aperte Ctrl+C nela.
- Comandos, no terminal dentro da pasta:
  - `python escritorio_virtual.py --videos 1 --canal quiz-desafios` faz 1 vídeo só desse canal. Use o nome da pasta.
  - `--videos 1` sem `--canal` faz 1 vídeo no total.
  - `--sempre` repete a rodada a cada 24 horas. Use para deixar ligado.
  - `--sem-navegador` não abre o painel, e `--porta 9000` usa outra porta.
  - `--offline` só serve para ver se o programa liga. Sem internet não há voz neural nem imagens, e o Real ou IA dá erro.
- Para testar uma mudança, rode 1 vídeo do canal e assista. Confira:
  - a legenda e as imagens;
  - o áudio;
  - o `duracao_s` no `post.json`, que precisa passar de 61.
- Lembre que cada teste gasta itens do banco.
- Se um vídeo sair sem imagem, pergunte:
  - o canal e o código da pasta em `prontos\`;
  - se faltou imagem no vídeo todo ou em algumas cenas;
  - se rodou sem internet.
- Peça também o texto do terminal e um print do painel. Explique a causa antes de mudar o código. As causas comuns são internet caída, Pollinations lento ou a Commons recusando.

Para criar um canal novo:
1. Copie a pasta de um canal do mesmo tipo e use um nome sem acento e sem espaço. Não copie `prontos\` nem os arquivos de usados.
2. No `canal.json`, troque:
   - `nome`, `nicho` e `hashtags`;
   - a voz e a cor da legenda;
   - o `estilo_imagem`.
   Deixe `"ativo": false` até eu aprovar um teste.
3. Reescreva o `PERFIL.md` com nome, bio, hashtags, ideias, tamanho do roteiro e como criar a conta.
4. Escreva o banco novo. O programa acha a pasta nova sozinho.

## Postagem e monetização

- A postagem está desligada (`postar_de_verdade: false`). Os vídeos ficam prontos e eu publico à mão.
- Ao publicar à mão, eu marco o rótulo de IA nos vídeos com imagem realista e em todo Real ou IA. No YouTube é "conteúdo alterado ou sintético", e no TikTok é "conteúdo gerado por IA".
- Quando a postagem estiver ligada, o Postador marca esse rótulo sozinho a partir do `rotulo_ia`, e marca "não é feito para crianças".
- Ligar a postagem só quando eu pedir. Comece com um canal e uma rede:
  - no `canal.json` desse canal, ponha `"postar_de_verdade": true` e `"youtube_privacidade": "private"`. No `config.json` está `"public"`;
  - deixe em `plataformas` só as redes que já têm credencial;
  - o TikTok vem com `"tiktok_privacidade": "SELF_ONLY"`, que só eu vejo;
  - me peça para conferir o vídeo no app antes de deixar no automático.
- Credenciais, seguindo o passo a passo do README:
  - Ficam direto em `credenciais\`: o `client_secret.json` do Google e o `postiz.json`, só se usar o Postiz.
  - O resto vai em `credenciais\<pasta-do-canal>\`.
  - YouTube, no Google Cloud, de graça:
    1. Criar um projeto e ligar a "YouTube Data API v3".
    2. Criar uma credencial OAuth do tipo "App para computador" e salvar como `credenciais\client_secret.json`.
    3. Na "Tela de consentimento OAuth", clicar em "Publicar app", senão o acesso vence em 7 dias.
    4. Rodar `python autorizar_youtube.py <pasta-do-canal>` e entrar com o e-mail do canal. Isso cria `credenciais\<pasta-do-canal>\youtube_token.json`. Sem o nome da pasta, o token não é usado.
  - A cota grátis do YouTube costuma dar uns 6 envios por dia por projeto. Confira na página de cotas.
  - TikTok: `credenciais\<pasta-do-canal>\tiktok.json` com `client_key`, `client_secret`, `access_token` e `refresh_token`. O token é renovado sozinho.
  - Instagram: conta profissional ligada a uma página do Facebook, e `credenciais\<pasta-do-canal>\instagram.json` com `ig_user_id` e `token`.
  - Chaves do Pexels e do Pixabay: eu rodo `setx PEXELS_API_KEY minha_chave` e `setx PIXABAY_API_KEY minha_chave` e abro o programa de novo.
- O YouTube e o TikTok só deixam postar em público pela API depois de uma auditoria do app. Até lá, os vídeos ficam privados e eu publico à mão.
- O Postiz (`"postador": "postiz"`) posta nas 3 redes de uma vez.
  - Na nuvem é pago, a partir de US$ 29 por mês. Existe uma versão grátis para instalar no PC, mas ela precisa de Docker.
  - Para usar, ponha `"postiz_contas": {"tiktok": "<id>", "youtube": "<id>", "instagram": "<id>"}` no `canal.json`.
  - O padrão é `"oficial"`. Não sugira o plano pago.
- Monetização, conferida em outubro de 2026:
  - TikTok Recompensas: 10 mil seguidores, 100 mil views em 30 dias, conta pessoal (não comercial) e vídeo com mais de 1 minuto.
  - YouTube: 1 mil inscritos e 10 milhões de views em Shorts em 90 dias. Com 500 inscritos e 3 milhões de views já libera o nível inicial.
  - O YouTube não paga conteúdo repetitivo, feito em molde. Varie a estrutura dos roteiros.

## O que já está pronto (19/10/2026)

- Os 5 canais têm pasta, `canal.json`, `PERFIL.md` (nome, bio, hashtags, ideias e como criar a conta) e `musica\LEIA-ME.txt`.
- Os bancos foram escritos e conferidos com fontes: 36 roteiros, 88 perguntas e 69 itens de Real ou IA.
- Um vídeo de teste de cada canal foi conferido: legenda, imagens, duração e áudio.
- O código foi revisado, 25 defeitos foram corrigidos e foi criado o contador de banco no painel.

## Refinamento de 11/11/2026 (versão 2026.11.11.1)

- Bancos extras em `escritorio\bancos\` (18 roteiros, 32 perguntas, 15 fotos Real ou IA), música grátis automática do
  Kevin MacLeod (CC BY 4.0, com crédito na descrição), rodada diária às 21h10 de Brasília (`rodada_diaria_utc`), canal de
  roteiro sem banco é pulado, título do vídeo na tela e `capa.jpg` no pacote. Detalhes na seção "Refinamento geral" do README.

## O que ainda falta

1. Atualizar a pasta do meu PC com o zip, como explicado acima.
2. Eu preciso criar as contas dos 5 canais, cada uma com um e-mail separado. No TikTok, a conta tem que ser pessoal.
3. Música: o escritório baixa trilhas livres sozinho; se eu quiser outras, ponho nas pastas `musica\` dos canais.
4. Ligar a postagem quando as contas e as credenciais existirem, começando por um vídeo privado.
5. Repor os bancos antes de acabarem.
6. Os links de referência do TikTok não abriam para o Claude. Se eu mandar prints ou os vídeos, use-os para melhorar o estilo.

## Regras ao mexer no código

- Evolua o código que já existe em vez de recomeçar. Faça mudanças pequenas e teste cada uma.
- Não apague `credenciais\`, `saida\`, `vozes\` nem os arquivos de usados sem me perguntar.
- No fim, me diga em poucas linhas o que mudou, como testou e o que eu preciso fazer.
