@echo off
REM Liga o escritorio e abre o painel no navegador.
cd /d "%~dp0"
REM Antes de abrir, confere se ha atualizacao (silencioso se nao houver fonte, internet ou novidade).
python atualizar.py
python escritorio_virtual.py %*
pause
