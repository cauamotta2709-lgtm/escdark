"""Biblioteca de vídeos: cada vídeo pronto está "a publicar" ou "já publicado".

O estado fica em saida/biblioteca.json (a pasta saida/ o atualizador nunca mexe), assim:
  {"canal/id": {"estado": "publicado", "em": 1730000000.0}}
- Vídeo sem marca = "a publicar", e a limpeza nunca o apaga por idade.
- "publicado" guarda o momento da marcação: passados `dias_apos_publicar` dias (padrão 3) o vídeo sai do PC.
- Se o Postador publicou de verdade (link/id nas postagens) e você não marcou nada, conta como publicado
  a partir do momento em que o post.json foi gravado.
- Marcar "a publicar" de novo desfaz a marcação (o prazo de apagar some).
"""
from __future__ import annotations

import json
import threading
import time

from .nucleo import RAIZ

ARQ = RAIZ / "saida" / "biblioteca.json"
DIAS_PADRAO = 3
_trava = threading.Lock()


def dias(cfg: dict | None) -> float:
    try:
        d = float((cfg or {}).get("dias_apos_publicar", DIAS_PADRAO))
    except (TypeError, ValueError):
        d = DIAS_PADRAO
    return d if d >= 0 else DIAS_PADRAO


def ler() -> dict:
    try:
        d = json.loads(ARQ.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _gravar(d: dict) -> None:
    ARQ.parent.mkdir(parents=True, exist_ok=True)
    tmp = ARQ.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(ARQ)


def marcar(canal: str, vid: str, estado: str) -> dict:
    """Marca "publicado" (começa a contar os dias) ou "a_publicar" (desfaz). Devolve a marca atual."""
    if estado not in ("publicado", "a_publicar"):
        raise ValueError("estado inválido")
    chave = f"{canal}/{vid}"
    with _trava:
        d = ler()
        d[chave] = {"estado": estado, "em": time.time()}
        _gravar(d)
    return d[chave]


def esquecer(chaves) -> None:
    """Tira da lista o que a limpeza apagou."""
    with _trava:
        d = ler()
        if any(d.pop(c, None) is not None for c in list(chaves)):
            _gravar(d)


def estado_de(marcas: dict, canal: str, vid: str, publicado_de_verdade: bool, quando_post: float) -> tuple[str, float | None]:
    """("publicado"|"a_publicar", momento em que virou publicado)."""
    m = marcas.get(f"{canal}/{vid}")
    if m and m.get("estado") in ("publicado", "a_publicar"):
        return m["estado"], (m.get("em") if m["estado"] == "publicado" else None)
    if publicado_de_verdade:
        return "publicado", quando_post
    return "a_publicar", None
