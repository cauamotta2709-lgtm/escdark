"""Manda uma pasta de vídeo para a Lixeira do computador (dá para restaurar de lá).

Windows: usa a própria Lixeira do Windows (PowerShell/VisualBasic, que já vem no Windows; se falhar, a API
SHFileOperation). Linux/macOS: tenta `gio trash` / `trash`; sem eles move para saida/lixeira/ (nunca apaga de vez).
"""
from __future__ import annotations

import shutil
import subprocess
import time
from pathlib import Path

from .nucleo import RAIZ

SEM_JANELA = 0x08000000  # CREATE_NO_WINDOW


def _windows_powershell(pasta: Path) -> bool:
    caminho = str(pasta.resolve()).replace("'", "''")
    cmd = ("Add-Type -AssemblyName Microsoft.VisualBasic; "
           f"[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory('{caminho}', "
           "'OnlyErrorDialogs', 'SendToRecycleBin')")
    r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
                       capture_output=True, timeout=60, creationflags=SEM_JANELA)
    return r.returncode == 0


def _windows_api(pasta: Path) -> bool:
    import ctypes
    from ctypes import wintypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _pack_ = 1 if ctypes.sizeof(ctypes.c_void_p) == 4 else 8
        _fields_ = [("hwnd", wintypes.HWND), ("wFunc", wintypes.UINT), ("pFrom", wintypes.LPCWSTR),
                    ("pTo", wintypes.LPCWSTR), ("fFlags", ctypes.c_ushort), ("fAnyOperationsAborted", wintypes.BOOL),
                    ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", wintypes.LPCWSTR)]

    op = SHFILEOPSTRUCTW()
    op.wFunc = 3  # FO_DELETE
    op.pFrom = str(pasta.resolve()) + "\0"  # o Python acrescenta o segundo \0
    op.fFlags = 0x40 | 0x10 | 0x4 | 0x400  # ALLOWUNDO | NOCONFIRMATION | SILENT | NOERRORUI
    return ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op)) == 0 and not op.fAnyOperationsAborted


def enviar(pasta: Path) -> bool:
    """True se a pasta saiu do lugar e foi para a Lixeira (ou para saida/lixeira/)."""
    import os
    if not pasta.is_dir():
        return False
    try:
        if os.name == "nt":
            for tentar in (_windows_powershell, _windows_api):
                try:
                    if tentar(pasta) and not pasta.exists():
                        return True
                except Exception:
                    pass
            return False
        for cmd in (["gio", "trash"], ["trash-put"], ["trash"]):
            if shutil.which(cmd[0]):
                if subprocess.run([*cmd, str(pasta)], capture_output=True, timeout=60).returncode == 0 \
                        and not pasta.exists():
                    return True
        destino = RAIZ / "saida" / "lixeira" / f"{pasta.parent.parent.name}-{pasta.name}-{int(time.time())}"
        destino.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(pasta), str(destino))
        return not pasta.exists()
    except Exception:
        return False
