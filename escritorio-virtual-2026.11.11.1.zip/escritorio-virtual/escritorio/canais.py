"""Vários canais dark, um por nicho. Cada canal é uma pasta em canais/ com:

  canal.json           nome, nicho, formatos, voz, estilo das imagens, hashtags... (sobrepõe o config.json)
  PERFIL.md            nome sugerido, bio, como criar a conta, rótulo de IA e cuidados do nicho
  roteiros.json        banco de roteiros checados (formato "roteiro", um por vídeo)
  perguntas.json       banco do quiz de 4 alternativas (formato "perguntas")
  quiz_real_ou_ia.json banco de fotos do desafio Real ou IA (formato "real_ou_ia")
  musica/              trilhas livres de direitos só deste canal (opcional; senão usa a musica/ geral)
  prontos/             os vídeos prontos deste canal, cada um com video.mp4, post.json e descricao.txt

Os bancos também crescem pelas atualizações: escritorio/bancos/<canal>/ traz roteiros, perguntas e
fotos novas no mesmo formato, e eles entram depois dos itens do próprio canal, sem repetir (o que
você escreveu no canal vale primeiro, e os usados continuam valendo).

O Olheiro reveza os canais ativos, então cada rodada produz vídeos para todos eles.
"""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

from .nucleo import RAIZ, Job

PASTA = RAIZ / "canais"
EXTRAS = Path(__file__).resolve().parent / "bancos"  # itens novos que chegam pelas atualizações
_trava = threading.Lock()
_reservados: dict[str, set] = {}  # escolhidos nesta execução e ainda não empacotados


def ler(arq: Path):
    """JSON escrito pelo usuário (aceita o BOM que o Bloco de Notas às vezes põe)."""
    return json.loads(arq.read_text(encoding="utf-8-sig"))


def usados(arq: Path) -> set:
    """O que já virou vídeo. Só a falta do arquivo conta como "nada usado": se ele existir e não
    der para ler (OneDrive segurando, JSON cortado), o erro sobe e o histórico não é apagado."""
    try:
        return set(ler(arq))
    except FileNotFoundError:
        return set()


def indisponiveis(arq: Path) -> set:
    """Usados mais os reservados por vídeos desta execução que ainda estão na linha."""
    with _trava:
        return usados(arq) | _reservados.get(str(arq), set())


def reservar(job: Job, arq: Path, chaves, novo_ciclo: bool = False) -> None:
    """Marca como em uso agora; o arquivo de usados só é gravado quando o vídeo fica pronto,
    para um job que falhe não gastar o roteiro (veja confirmar)."""
    chaves = set(chaves)
    with _trava:
        _reservados.setdefault(str(arq), set()).update(chaves)
    job.arquivos.setdefault("usar", []).append([str(arq), sorted(chaves), novo_ciclo])


def confirmar(job: Job) -> None:
    """Chamado pelo Postador com o pacote pronto: grava os usados de forma atômica."""
    for arq, chaves, novo_ciclo in job.arquivos.get("usar") or []:
        arq = Path(arq)
        with _trava:
            # novo ciclo: o banco inteiro já foi usado, então recomeça só com os deste vídeo
            atual = set(chaves) if novo_ciclo else usados(arq) | set(chaves)
            arq.parent.mkdir(parents=True, exist_ok=True)
            tmp = arq.with_name(arq.name + ".tmp")
            tmp.write_text(json.dumps(sorted(atual), ensure_ascii=False, indent=1), encoding="utf-8")
            for tentativa in range(5):  # no Windows o OneDrive pode segurar o arquivo por um instante
                try:
                    os.replace(tmp, arq)
                    break
                except PermissionError:
                    if tentativa == 4:
                        raise
                    time.sleep(0.5)
            _reservados.get(str(arq), set()).difference_update(chaves)


def carregar(somente: str | None = None) -> list[dict]:
    """Canais ativos (pastas com canal.json e "ativo" diferente de false), em ordem alfabética."""
    canais = []
    for arq in sorted(PASTA.glob("*/canal.json")) if PASTA.exists() else []:
        try:
            canal = ler(arq)
        except ValueError as e:
            print(f"[canais] {arq} tem um erro e foi ignorado: {e}", flush=True)
            continue
        canal["pasta"] = arq.parent.name
        if canal.get("ativo", True) and (not somente or somente.lower() == canal["pasta"].lower()):
            canais.append(canal)
    return canais


def mesclar(cfg: dict, canal: dict) -> dict:
    """Configuração do vídeo: o config.json geral com o que o canal define por cima."""
    junto = dict(cfg)
    junto.update({k: v for k, v in canal.items() if k not in ("descricao_interna",)})
    return junto


def pasta(canal: str) -> Path:
    return PASTA / canal


def banco(dono: Path, nome: str, chave) -> list[dict]:
    """Itens do arquivo `nome` do canal mais os de escritorio/bancos/<canal>/nome, sem repetir a
    chave (o do canal vem primeiro). Um arquivo com erro é pulado com aviso, sem derrubar o outro."""
    pegar = chave if callable(chave) else (lambda item: item.get(chave))
    itens, vistos = [], set()
    for arq in (dono / nome, EXTRAS / dono.name / nome):
        if not arq.exists():
            continue
        try:
            dados = ler(arq)
        except ValueError as e:
            print(f"[canais] {arq} tem um erro e foi ignorado: {e}", flush=True)
            continue
        for item in dados if isinstance(dados, list) else []:
            k = pegar(item) if isinstance(item, dict) else None
            if k and k not in vistos:
                vistos.add(k)
                itens.append(item)
    return itens


def tem_banco(canal: str, nome: str) -> bool:
    return (pasta(canal) / nome).exists() or (EXTRAS / canal / nome).exists()


def roteiros(canal: str) -> list[dict]:
    """Banco de roteiros do canal (com os extras das atualizações); arquivo com erro vale vazio."""
    return [r for r in banco(pasta(canal), "roteiros.json", lambda r: r.get("id") or r.get("titulo"))
            if r.get("frases")]


def proximo_roteiro(job: Job, canal: str) -> dict | None:
    """O primeiro roteiro do banco do canal que ainda não virou vídeo (ou None se acabou)."""
    arq = pasta(canal) / "usados.json"
    fora = indisponiveis(arq)
    for roteiro in roteiros(canal):
        chave = roteiro.get("id") or roteiro["titulo"]
        if chave not in fora:
            reservar(job, arq, [chave])
            return roteiro
    return None


def restantes(canal: str, cfg: dict | None = None) -> int:
    """Quantos vídeos o banco do canal ainda rende sem repetir item. No roteiro, um item é um
    vídeo; no quiz e no Real ou IA, cada vídeo gasta quiz_perguntas ou quiz_rodadas itens."""
    cfg = cfg or {}
    p = pasta(canal)
    try:
        if tem_banco(canal, "roteiros.json"):
            fora = indisponiveis(p / "usados.json")
            return sum(1 for r in roteiros(canal) if (r.get("id") or r["titulo"]) not in fora)
        for nome, arq, chave, por_video in (
                ("perguntas.json", "perguntas_usadas.json", "id", cfg.get("quiz_perguntas", 8)),
                ("quiz_real_ou_ia.json", "quiz_usados.json", "foto", cfg.get("quiz_rodadas", 4))):
            if tem_banco(canal, nome):
                fora = indisponiveis(p / arq)
                livres = sum(1 for i in banco(p, nome, chave) if i.get(chave) not in fora)
                return livres // max(1, int(por_video))
    except (OSError, ValueError) as e:
        print(f"[canais] não deu para ler o banco ou os usados de {canal}: {e}", flush=True)
    return 0
