"""Formato "perguntas": quiz de conhecimentos gerais com 4 alternativas na tela.

Cada vídeo tem um gancho, N perguntas da mais fácil para a mais difícil e um final pedindo
comentário. Em cada pergunta a voz lê a pergunta, as alternativas A, B, C e D aparecem em
cartões, vem a contagem 3-2-1 em silêncio (o momento em que quem assiste pensa) e depois a
alternativa certa fica verde e a voz conta uma curiosidade. O banco fica no perguntas.json do
canal e não repete pergunta até usar todas.
"""
from __future__ import annotations

import json
import random
from pathlib import Path

from . import canais
from .nucleo import Job

LETRAS = "ABCD"
GANCHOS = [
    "Duvido você acertar as {n}. A última é quase impossível!",
    "Só gênio acerta as {n}. Valendo!",
    "{n} perguntas, e a última derruba quase todo mundo.",
    "Se você acertar as {n}, pode se gabar nos comentários.",
]
ULTIMA = ["Última, e a mais difícil: ", "Agora a mais difícil: ", "Pergunta final: "]
FINAIS = [
    "Quantas você acertou? Comenta aí!",
    "Comenta quantas você acertou, sem mentir!",
]


def banco(pasta: Path) -> list[dict]:
    """Perguntas do canal mais as que chegam pelas atualizações (escritorio/bancos/<canal>/)."""
    return canais.banco(pasta, "perguntas.json", "id")


def escolher(job: Job, pasta: Path, qtd: int) -> list[dict]:
    """Perguntas ainda não usadas, misturando fáceis, médias e difíceis, em ordem crescente.
    Quando sobram menos que o necessário, usa as que sobraram e completa com outras."""
    todas = [p for p in banco(pasta) if len(p.get("alternativas", [])) == 4]
    arq = pasta / "perguntas_usadas.json"
    fora = canais.indisponiveis(arq)
    livres = [p for p in todas if p["id"] not in fora]
    random.shuffle(livres)
    novo_ciclo = len(livres) < qtd
    # cerca de 40% fáceis, 35% médias e o resto difíceis; completa com o que sobrar
    cotas = {1: round(qtd * 0.4), 2: round(qtd * 0.35)}
    cotas[3] = qtd - cotas[1] - cotas[2]
    itens = []
    if novo_ciclo:
        resto = [p for p in todas if p not in livres]
        extra = random.sample(resto, min(qtd - len(livres), len(resto)))
        itens = livres + extra
    else:
        for nivel, cota in cotas.items():
            itens += [p for p in livres if p.get("dificuldade", 2) == nivel][:cota]
        itens += [p for p in livres if p not in itens][:qtd - len(itens)]
        extra = itens
    itens.sort(key=lambda p: p.get("dificuldade", 2))
    canais.reservar(job, arq, [p["id"] for p in extra], novo_ciclo=novo_ciclo)
    return itens


def montar(job: Job, pasta: Path, qtd: int = 8) -> Job:
    itens = [dict(p) for p in escolher(job, pasta, qtd)]
    roteiro = [random.choice(GANCHOS).format(n=len(itens))]
    for n, item in enumerate(itens, 1):
        item["letra"] = LETRAS[item["correta"]]
        item["q"] = len(roteiro)
        prefixo = random.choice(ULTIMA) if n == len(itens) and n > 1 else ""
        roteiro.append(prefixo + item["pergunta"])
        item["r"] = len(roteiro)
        roteiro.append(f"Letra {item['letra']}! {item['curiosidade']}")
    roteiro.append(random.choice(FINAIS))
    job.tema = "quiz de conhecimentos gerais"
    job.roteiro = roteiro
    job.buscas = []
    job.arquivos["perguntas"] = itens
    return job
