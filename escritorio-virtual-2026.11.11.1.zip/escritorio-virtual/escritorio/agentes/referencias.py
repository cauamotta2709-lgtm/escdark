"""Agente 2: o Olheiro de Referências procura um filme, série, meme ou assunto viral que combine com
o roteiro e, quando acha, põe UMA frase citando a obra (veja escritorio/cultura.py)."""
from __future__ import annotations

from .. import cultura
from ..nucleo import Agente, Job


class Referencias(Agente):
    chave = "referencias"
    nome = "Referências"
    cargo = "Procura filmes, séries e memes que combinem com o roteiro"
    emoji = "🎞️"
    motor = "regras"

    def processar(self, job: Job) -> Job:
        cfg = self.conf(job)
        if job.arquivos.get("quiz") or job.arquivos.get("perguntas") or len(job.roteiro) < 4:
            self.tarefa("este formato não leva referência")
            return job
        self.tarefa("procurando uma referência de filme, série, meme ou assunto viral")
        try:
            if not cultura.aplicar(job, cfg, self.log):
                self.log(f"nenhuma referência combinou com o roteiro (job {job.id})")
        except Exception as e:  # a referência é um extra: nunca derruba o vídeo
            self.log(f"referência de cultura pop falhou ({str(e)[:60]})", "aviso")
        return job
