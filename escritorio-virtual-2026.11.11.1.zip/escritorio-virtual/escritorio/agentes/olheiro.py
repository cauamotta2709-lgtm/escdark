"""Agente 1: busca referências virais e escreve a pauta + roteiro do vídeo."""
from __future__ import annotations

import json
import random
import re
import time
import unicodedata
import urllib.parse
import urllib.request

from .. import canais, llm, perguntas, quiz
from ..nucleo import RAIZ, Agente, Job, py, tem_modulo

GANCHOS = [
    "Você não vai acreditar nisso sobre {t}.",
    "Ninguém te contou isso sobre {t}.",
    "Pare tudo: um fato sobre {t} que vai te surpreender.",
    "Em 30 segundos você vai entender {t}.",
]


# fechos sem pedido de "segue" ou "curte": os shorts de referência terminam no impacto
FECHOS = ["Agora você nunca mais vai olhar para isso do mesmo jeito.",
          "E quase ninguém sabe disso.",
          "Pensa nisso da próxima vez."]

PARADAS = set("""a o as os um uma uns umas de da do das dos em na no nas nos por para com sem que
e é ou se sua seu suas seus ele ela eles elas isso essa esse este esta mais muito você voce
ninguém nunca ainda cada dele dela tem têm foi ser são está pode até como quando porque""".split())


def palavras_chave(frase: str, tema: str = "") -> str:
    """Busca de imagem tirada da própria frase: as duas palavras mais longas que não são vazias."""
    palavras = [w for w in re.findall(r"\w+", frase.lower()) if w not in PARADAS and len(w) > 3]
    escolhidas = sorted(palavras, key=len, reverse=True)[:2]
    return " ".join(escolhidas) or tema


# o símbolo de grau é da mesma categoria dos emojis: temperatura vira palavra, e o ° sozinho
# fica, porque também é ordinal ("1° lugar") e a voz lê os dois certo
SIMBOLOS = [(r"\s*(°\s?C|℃)", " graus Celsius"), (r"\s*(°\s?F|℉)", " graus Fahrenheit")]


def falavel(frase: str) -> str:
    """Tira emojis e marcações (*, #, _) que a voz leria ou que sujariam a legenda."""
    texto = unicodedata.normalize("NFC", str(frase))  # acentos já compostos
    for simbolo, nome in SIMBOLOS:
        texto = re.sub(simbolo, nome, texto)
    sem = "".join(c for c in texto if c == "°"
                  or unicodedata.category(c) not in ("So", "Sk", "Cs", "Co", "Cf", "Mn"))
    return re.sub(r"\s+", " ", re.sub(r"[*#_~`>|\[\]]", "", sem)).strip()


def limpar_titulo(titulo: str) -> str:
    """Tira hashtags, emojis e enfeites do título do YouTube para usar como busca."""
    t = re.sub(r"#\w+|@\w+|\|.*$", " ", titulo)
    return re.sub(r"[^\w\s\-]", " ", t).strip()


def wikipedia(consulta: str, idioma: str = "pt") -> dict | None:
    """Resumo do artigo da Wikipédia que mais combina com a consulta: {titulo, url, texto}."""
    base = f"https://{idioma}.wikipedia.org/w/api.php?"
    cab = {"User-Agent": "escritorio-virtual/1.0 (projeto pessoal de videos curtos)"}

    def api(params: dict) -> dict:
        url = base + urllib.parse.urlencode({**params, "format": "json", "formatversion": 2})
        with urllib.request.urlopen(urllib.request.Request(url, headers=cab), timeout=20) as r:
            return json.loads(r.read())

    achados = api({"action": "query", "list": "search", "srsearch": consulta, "srlimit": 1})
    achados = achados.get("query", {}).get("search", [])
    if not achados:
        return None
    titulo = achados[0]["title"]
    paginas = api({"action": "query", "prop": "extracts", "exintro": 1, "explaintext": 1,
                   "redirects": 1, "titles": titulo}).get("query", {}).get("pages", [])
    texto = (paginas[0].get("extract") or "").strip() if paginas else ""
    if len(texto) < 80:
        return None
    url = f"https://{idioma}.wikipedia.org/wiki/" + urllib.parse.quote(titulo.replace(" ", "_"))
    return {"titulo": titulo, "url": url, "texto": texto[:2500]}


def relevante(titulo_artigo: str, consulta: str) -> bool:
    """O artigo achado tem alguma palavra importante da consulta? (evita 'Superboy' para 'corpo humano')"""
    def chaves(t: str) -> set[str]:
        t = unicodedata.normalize("NFKD", t.lower()).encode("ascii", "ignore").decode()
        return {w[:5] for w in re.findall(r"[a-z]+", t) if len(w) > 3 and w not in PARADAS}
    return bool(chaves(titulo_artigo) & chaves(consulta))


def frases_curtas(texto: str, n: int = 4) -> list[str]:
    """As primeiras frases curtas e completas de um texto, boas para narrar."""
    frases = re.split(r"(?<=[.!?])\s+", re.sub(r"\s*\([^)]*\)", "", texto))
    boas = [f.strip() for f in frases if 25 <= len(f.strip()) <= 140]
    return boas[:n]


class Olheiro(Agente):
    chave = "olheiro"
    nome = "Olheiro"
    cargo = "Busca referências virais e escreve o roteiro"
    emoji = "🔎"

    def __init__(self, *a, **kw) -> None:
        super().__init__(*a, **kw)
        self.ultimo = 0.0
        self.gerados = 0
        self.vistos: set[str] = set()
        self.modelo = self.cfg.get("modelo", "llama3.2:3b")
        self.motor = "ollama" if llm.disponivel(self.modelo) else "regras"
        self.tele.atualizar(self.chave, motor=self.motor)
        # com canais em canais/, cada rodada faz "videos_por_canal" vídeos para cada canal ativo
        self.canais = canais.carregar(self.cfg.get("so_canal"))
        self.limite = self.limite_base = self.cfg.get("limite_rodada") or (
            len(self.canais) * self.cfg.get("videos_por_canal", 1) if self.canais
            else self.cfg.get("videos_por_rodada", 3))
        self.por_canal: dict[str, int] = {}
        self.vez = 0  # próximo canal do rodízio
        self.criados: dict[str, int] = {}  # vídeos começados por canal nesta rodada
        self.pulados: set[str] = set()  # canais de roteiro sem banco nesta rodada
        if self.canais:
            self.log(f"{len(self.canais)} canais ativos: " + ", ".join(c["pasta"] for c in self.canais))
        for c in self.canais:
            self.tele.canal(c["pasta"], nome=c.get("nome", c["pasta"]), nicho=c.get("nicho", ""),
                            roteiros=canais.restantes(c["pasta"], canais.mesclar(self.cfg, c)))

    def proximo_job(self) -> Job | None:
        """O Olheiro não espera ninguém: cria um job novo a cada intervalo."""
        if self.gerados >= self.limite:
            self.parar.wait(1)
            return None
        if time.time() - self.ultimo < self.cfg.get("intervalo_s", 5):
            self.parar.wait(0.5)
            return None
        self.ultimo = time.time()
        job = Job()
        if self.canais:  # rodízio entre os canais
            for _ in range(len(self.canais)):
                canal = self.canais[self.vez % len(self.canais)]
                self.vez += 1
                cfg = canais.mesclar(self.cfg, canal)
                if canal["pasta"] in self.pulados or self.sem_banco(canal["pasta"], cfg):
                    # canal de roteiro sem roteiro novo: não faz vídeo fora do nicho, pula a vez
                    self.pular(canal["pasta"])
                    continue
                job.canal, job.cfg = canal["pasta"], cfg
                break
            else:  # nenhum canal tem o que produzir: a rodada termina aqui
                self.limite = self.gerados
                return None
            self.criados[job.canal] = self.criados.get(job.canal, 0) + 1
        self.gerados += 1
        return job

    def sem_banco(self, canal: str, cfg: dict) -> bool:
        """O canal só faz roteiros e o banco dele acabou? (quiz e Real ou IA recomeçam o rodízio)"""
        formatos = cfg.get("formatos") or []
        if not cfg.get("pular_canal_sem_banco", True) or formatos != ["roteiro"]:
            return False
        return canais.restantes(canal, cfg) <= 0

    def pular(self, canal: str) -> None:
        if canal in self.pulados:
            return
        self.pulados.add(canal)
        if not self.cfg.get("limite_rodada"):  # as vagas que eram deste canal saem da rodada
            self.limite -= max(0, self.cfg.get("videos_por_canal", 1) - self.criados.get(canal, 0))
        self.tele.canal(canal, roteiros=0)
        self.log(f"o canal {canal} ficou sem roteiro novo e foi pulado nesta rodada (para não postar "
                 "vídeo fora do nicho): peça mais roteiros ao Claude", "aviso")

    def nova_rodada(self) -> None:
        """Rodada diária: zera a contagem e volta com todos os canais (o banco pode ter crescido)."""
        self.canais = canais.carregar(self.cfg.get("so_canal"))
        self.limite, self.gerados, self.vez = self.limite_base, 0, 0
        self.criados, self.pulados = {}, set()
        for c in self.canais:
            self.tele.canal(c["pasta"], roteiros=canais.restantes(c["pasta"], canais.mesclar(self.cfg, c)))

    def buscar_referencias(self, cfg: dict) -> list[dict]:
        nichos = cfg.get("nichos") or [cfg.get("nicho", "curiosidades")]
        nicho = nichos[(self.gerados - 1) % len(nichos)]  # rodízio: cada vídeo puxa um nicho
        if tem_modulo("yt_dlp") and not cfg.get("offline"):
            self.tarefa(f"pesquisando shorts virais de '{nicho}' no YouTube")
            try:
                r = self.rodar(py("yt_dlp", "--flat-playlist", "-J", f"ytsearch20:{nicho} #shorts"),
                               timeout=90)
                itens = json.loads(r.stdout).get("entries", [])
                refs = [{"titulo": i.get("title", ""), "url": i.get("url", ""),
                         "views": i.get("view_count") or 0, "canal": i.get("channel", "")}
                        for i in itens if i.get("title")]
                if refs:
                    return sorted(refs, key=lambda x: -x["views"])
            except Exception as e:
                self.log(f"busca online falhou, usando banco local ({e})", "aviso")
        self.tarefa("lendo banco local de referências")
        return canais.ler(RAIZ / "referencias.json")

    def conferir_banco(self, job: Job, cfg: dict, o_que: str) -> None:
        """No quiz e no Real ou IA o banco não para: sem itens novos, ele repete os antigos."""
        if not job.canal:
            return
        faltam = canais.restantes(job.canal, cfg)
        self.tele.canal(job.canal, roteiros=faltam)
        if faltam <= 3:
            self.log(f"o banco do canal {job.canal} só rende mais {faltam} vídeo(s) sem repetir: "
                     f"peça mais {o_que} ao Claude", "aviso")

    def processar(self, job: Job) -> Job:
        cfg = self.conf(job)
        onde = f" para o canal {job.canal}" if job.canal else ""
        n = self.por_canal[job.canal] = self.por_canal.get(job.canal, 0) + 1
        formatos = cfg.get("formatos") or ["curiosidades"]
        formato = formatos[(n - 1) % len(formatos)]  # rodízio de formatos dentro de cada canal
        if formato == "real_ou_ia":
            self.tarefa(f"montando o desafio Real ou IA{onde}")
            quiz.montar(job, cfg.get("quiz_rodadas", 4), canais.pasta(job.canal) if job.canal else None)
            job.referencia = {"titulo": "Desafio Real ou IA", "formato": "real_ou_ia",
                              "url": cfg.get("referencia_estilo", "")}
            self.log(f"desafio Real ou IA com {len(job.arquivos['quiz'])} fotos{onde} (job {job.id})")
            self.conferir_banco(job, cfg, "itens de Real ou IA")
            return job
        if formato == "perguntas" and job.canal \
                and canais.tem_banco(job.canal, "perguntas.json"):
            self.tarefa(f"sorteando as perguntas do quiz{onde}")
            perguntas.montar(job, canais.pasta(job.canal), cfg.get("quiz_perguntas", 8))
            job.referencia = {"titulo": "Quiz de perguntas", "formato": "perguntas",
                              "fontes": [p.get("fonte", "") for p in job.arquivos["perguntas"]]}
            self.log(f"quiz com {len(job.arquivos['perguntas'])} perguntas{onde} (job {job.id})")
            self.conferir_banco(job, cfg, "perguntas")
            return job
        if formato == "roteiro":
            self.tarefa(f"pegando o próximo roteiro do banco{onde}")
            roteiro = canais.proximo_roteiro(job, job.canal) if job.canal else None
            if roteiro:
                job.tema = roteiro.get("tema") or roteiro["titulo"]
                # frase que fica vazia depois da limpeza sai junto com a imagem dela
                imagens = list(roteiro.get("imagens") or [])
                pares = [(falavel(f), imagens[i] if i < len(imagens) else None)
                         for i, f in enumerate(roteiro["frases"])]
                pares = [(f, im) for f, im in pares if f]
                job.roteiro = [f for f, _ in pares]
                job.arquivos["roteiro"] = roteiro
                job.arquivos["imagens"] = [im for _, im in pares]
                job.referencia = {"titulo": roteiro["titulo"], "formato": "roteiro",
                                  "fonte": roteiro.get("fonte") or next(iter(roteiro.get("fontes") or []), "")}
                faltam = canais.restantes(job.canal, cfg)
                self.tele.canal(job.canal, roteiros=faltam)
                self.log(f"roteiro “{roteiro['titulo']}”{onde} (job {job.id}); restam {faltam} no banco")
                if faltam <= 3:
                    self.log(f"o banco de roteiros do canal {job.canal} está acabando: "
                             "peça mais roteiros ao Claude", "aviso")
                return job
            self.log(f"banco de roteiros{onde} vazio; fazendo um vídeo de curiosidades", "aviso")

        refs = [r for r in self.buscar_referencias(cfg) if r["titulo"] not in self.vistos]
        ref = refs[0] if refs else random.choice(self.buscar_referencias(cfg))
        self.vistos.add(ref["titulo"])
        job.referencia = ref
        self.log(f"referência escolhida: “{ref['titulo']}” ({ref.get('views', 0):,} views)")

        # fatos verificáveis: o roteiro se apoia num artigo da Wikipédia, e o link vai no post.json
        fonte = None
        if cfg.get("fonte_fatos", "wikipedia") == "wikipedia" and not cfg.get("offline") \
                and not ref.get("fatos"):
            self.tarefa("conferindo fatos na Wikipédia")
            consulta = ref.get("tema") or limpar_titulo(ref["titulo"])
            try:
                fonte = wikipedia(consulta)
            except Exception as e:
                self.log(f"Wikipédia indisponível ({str(e)[:60]})", "aviso")
            if fonte and not relevante(fonte["titulo"], consulta):
                self.log(f"artigo '{fonte['titulo']}' não tem a ver com o tema; descartado", "aviso")
                fonte = None
            if fonte:
                ref["fonte"] = fonte["url"]
                self.log(f"fonte dos fatos: {fonte['titulo']} (Wikipédia)")
            else:
                self.log("nenhum artigo encontrado; roteiro sem fonte verificada", "aviso")

        self.tarefa("escrevendo roteiro")
        if self.motor != "ollama" and llm.disponivel(self.modelo):  # o modelo terminou de baixar
            self.motor = "ollama"
            self.tele.atualizar(self.chave, motor=self.motor)
        feito = False
        if self.motor == "ollama":
            base = (f"Use SOMENTE fatos deste texto da Wikipédia, sem inventar nada: \"{fonte['texto']}\". "
                    if fonte else "Use apenas fatos que você tem certeza que são verdadeiros. ")
            prompt = (
                "Você roteiriza vídeos curtos virais em português do Brasil, com a energia de um "
                "youtuber jovem falando direto com quem assiste (use 'você', perguntas e surpresa). "
                "Frases de até 15 palavras, linguagem do dia a dia, sem repetir o nome do assunto "
                "em toda frase. "
                f"Inspire-se no tema deste vídeo (sem copiar): \"{ref['titulo']}\". " + base +
                "Responda em JSON: {\"tema\": str, \"frases\": [6 a 8 frases curtas, a primeira "
                "é um gancho forte, a última fecha com impacto, sem pedir para seguir ou curtir], \"buscas\": [uma busca "
                "em inglês de 1 a 3 palavras para cada frase, descrevendo a imagem de vídeo que "
                "combina com ela, ex.: \"octopus underwater\"]}")
            try:
                texto, tokens = llm.gerar(prompt, self.modelo, json_saida=True)
                self.contar_tokens(tokens)
                dados = json.loads(texto)
                # limpa a fala e mantém cada busca junto da sua frase
                buscas = list(dados.get("buscas") or [])
                pares = [(falavel(f), str(buscas[i]) if i < len(buscas) else "")
                         for i, f in enumerate(dados["frases"])]
                pares = [(f, b) for f, b in pares if f]
                job.tema, job.roteiro = str(dados["tema"]), [f for f, _ in pares]
                job.buscas = [b or palavras_chave(f, job.tema) for f, b in pares]
                feito = bool(job.roteiro)
            except Exception as e:  # sem modelo, resposta ruim etc.: segue pelas regras
                self.log(f"IA local falhou ({str(e)[:60]}); usando o modo por regras", "aviso")
        if not feito:
            job.tema = ref.get("tema") or (fonte["titulo"] if fonte else limpar_titulo(ref["titulo"]))
            fatos = ref.get("fatos") or (frases_curtas(fonte["texto"]) if fonte else []) \
                or [limpar_titulo(ref["titulo"])]
            job.roteiro = [random.choice(GANCHOS).format(t=job.tema.lower()), *fatos,
                           random.choice(FECHOS)]
            imagens = ref.get("buscas") or []
            job.buscas = [imagens[0] if imagens else job.tema,
                          *[imagens[i + 1] if i + 1 < len(imagens) else palavras_chave(f, job.tema)
                            for i, f in enumerate(fatos)],
                          imagens[0] if imagens else job.tema]
        # completa com palavras-chave da própria frase se o LLM devolveu menos buscas que frases
        job.buscas += [palavras_chave(f, job.tema) for f in job.roteiro[len(job.buscas):]]
        job.buscas = job.buscas[:len(job.roteiro)]
        # buscas tiradas das frases estão em português; o Carregador avisa isso ao Pexels/Pixabay
        job.arquivos["buscas_pt"] = [b == palavras_chave(f, job.tema) or b == job.tema
                                     for f, b in zip(job.roteiro, job.buscas)]
        self.log(f"roteiro pronto com {len(job.roteiro)} frases (job {job.id})")
        return job
