"""Agente 5: posta o vídeo no YouTube Shorts, TikTok e Instagram Reels.

Por segurança vem DESLIGADO ("postar_de_verdade": false): nesse modo ele monta o pacote de
cada plataforma em canais/<canal>/prontos/ (ou saida/prontos/ sem canais) e não publica nada. Para ligar, preencha credenciais/
(veja o README) e mude a opção. As APIs oficiais são gratuitas; TikTok (e talvez YouTube) só
publicam em público depois da auditoria do app de cada rede.

Opcional: "postador": "postiz" no config.json publica tudo por uma conta do Postiz
(https://postiz.com), que já tem os apps aprovados nas redes. O Postiz Cloud é pago (tem teste
de 7 dias); a chave fica em credenciais/postiz.json e cada canal diz quais contas usar.
"""
from __future__ import annotations

import json
import os
import shutil
import time
import urllib.parse
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .. import canais
from ..nucleo import RAIZ, Agente, Job

CRED = RAIZ / "credenciais"


def _post_json(url: str, corpo: dict, headers: dict) -> dict:
    req = urllib.request.Request(url, data=json.dumps(corpo).encode(), method="POST",
                                 headers={"Content-Type": "application/json; charset=UTF-8", **headers})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())


def _get_json(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=60) as r:
        return json.loads(r.read())


def token_tiktok(cred: Path) -> str:
    """Token do TikTok. O access token vale só 24 h: com credenciais/<canal>/tiktok.json
    (client_key, client_secret, access_token, refresh_token) ele é renovado sozinho pelo
    refresh token, que vale um ano. tiktok_token.txt (só o access token) também serve."""
    arq = cred / "tiktok.json"
    if not arq.exists():
        return (cred / "tiktok_token.txt").read_text(encoding="utf-8").strip()
    dados = canais.ler(arq)
    if time.time() > dados.get("expira_em", 0) - 300:
        corpo = urllib.parse.urlencode({
            "client_key": dados["client_key"], "client_secret": dados["client_secret"],
            "grant_type": "refresh_token", "refresh_token": dados["refresh_token"]}).encode()
        req = urllib.request.Request("https://open.tiktokapis.com/v2/oauth/token/", data=corpo,
                                     method="POST",
                                     headers={"Content-Type": "application/x-www-form-urlencoded"})
        with urllib.request.urlopen(req, timeout=60) as r:
            novo = json.loads(r.read())
        if "access_token" not in novo:
            raise RuntimeError(f"o TikTok não renovou o token: {novo.get('error_description') or novo}")
        dados.update(access_token=novo["access_token"],
                     refresh_token=novo.get("refresh_token", dados["refresh_token"]),
                     expira_em=int(time.time()) + int(novo.get("expires_in", 86400)))
        arq.write_text(json.dumps(dados, indent=2), encoding="utf-8")
    return dados["access_token"]


class Postiz:
    """Cliente mínimo da API pública do Postiz (https://docs.postiz.com/public-api)."""

    def __init__(self) -> None:
        arq = CRED / "postiz.json"
        dados = canais.ler(arq) if arq.exists() else {}
        self.chave = dados.get("api_key") or os.environ.get("POSTIZ_API_KEY", "")
        self.url = (dados.get("url") or "https://api.postiz.com/public/v1").rstrip("/")
        if not self.chave:
            raise FileNotFoundError("credenciais/postiz.json")

    def pedir(self, caminho: str, corpo: bytes | None = None, tipo: str = "application/json"):
        req = urllib.request.Request(self.url + caminho, data=corpo, method="POST" if corpo else "GET",
                                     headers={"Authorization": self.chave, "Content-Type": tipo})
        with urllib.request.urlopen(req, timeout=600) as r:
            return json.loads(r.read())

    def enviar_video(self, video: Path) -> dict:
        borda = uuid.uuid4().hex
        corpo = (f"--{borda}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"video.mp4\"\r\n"
                 f"Content-Type: video/mp4\r\n\r\n").encode() + video.read_bytes() + f"\r\n--{borda}--\r\n".encode()
        return self.pedir("/upload", corpo, f"multipart/form-data; boundary={borda}")

    def contas(self) -> list[dict]:
        return [c for c in self.pedir("/integrations") if not c.get("disabled")]


class Postador(Agente):
    chave = "postador"
    nome = "Postador"
    cargo = "Publica no YouTube, TikTok e Instagram"
    emoji = "🚀"

    def __init__(self, *a, **kw) -> None:
        super().__init__(*a, **kw)
        self.real = bool(self.cfg.get("postar_de_verdade"))
        self.motor = "APIs oficiais" if self.real else "modo seguro"
        self.tele.atualizar(self.chave, motor=self.motor)

    def texto(self, job: Job) -> str:
        creditos = job.arquivos.get("creditos") or []  # fotos e músicas livres pedem o crédito do autor
        extra = "\n\nCréditos:\n" + "\n".join(creditos) if creditos else ""
        return f"{job.legenda}\n\n" + " ".join(f"#{h}" for h in job.hashtags) + extra

    # ---------- YouTube Shorts (YouTube Data API v3, cota grátis ~6 envios/dia) ----------
    def youtube(self, job: Job, video: Path, cfg: dict, cred: Path) -> str:
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaFileUpload
        from google.auth.exceptions import RefreshError
        token = Credentials.from_authorized_user_file(str(cred / "youtube_token.json"))
        yt = build("youtube", "v3", credentials=token)
        # o YouTube aceita até 100 caracteres e recusa < e >
        titulo = job.arquivos["titulo"].replace("<", "").replace(">", "")
        corpo = {"snippet": {"title": titulo[:100 - len(" #shorts")].rstrip() + " #shorts",
                             "description": self.texto(job), "tags": job.hashtags,
                             "categoryId": "24"},
                 "status": {"privacyStatus": cfg.get("youtube_privacidade", "public"),
                            "selfDeclaredMadeForKids": False,
                            # "conteúdo alterado ou sintético": obrigatório quando a cena parece real
                            "containsSyntheticMedia": bool(cfg.get("rotulo_ia"))}}
        try:
            resp = yt.videos().insert(part="snippet,status", body=corpo,
                                      media_body=MediaFileUpload(str(video), resumable=True)).execute()
        except RefreshError:
            raise RuntimeError(f"o token do YouTube expirou: rode python autorizar_youtube.py "
                               f"{job.canal} de novo (e publique o app no Google Cloud, veja o README)")
        return f"https://youtube.com/shorts/{resp['id']}"

    # ---------- TikTok (Content Posting API, Direct Post) ----------
    def tiktok(self, job: Job, video: Path, cfg: dict, cred: Path) -> str:
        token = token_tiktok(cred)
        tam = video.stat().st_size
        init = _post_json(
            "https://open.tiktokapis.com/v2/post/publish/video/init/",
            {"post_info": {"title": self.texto(job)[:2200],
                           "privacy_level": cfg.get("tiktok_privacidade", "SELF_ONLY"),
                           "is_aigc": bool(cfg.get("rotulo_ia", True))},
             "source_info": {"source": "FILE_UPLOAD", "video_size": tam,
                             "chunk_size": tam, "total_chunk_count": 1}},
            {"Authorization": f"Bearer {token}"})
        req = urllib.request.Request(init["data"]["upload_url"], data=video.read_bytes(), method="PUT",
                                     headers={"Content-Type": "video/mp4",
                                              "Content-Range": f"bytes 0-{tam - 1}/{tam}"})
        urllib.request.urlopen(req, timeout=300)
        return f"tiktok publish_id {init['data']['publish_id']}"

    # ---------- Instagram Reels (Graph API, upload resumível) ----------
    def instagram(self, job: Job, video: Path, cfg: dict, cred: Path) -> str:
        ig = canais.ler(cred / "instagram.json")
        base, tk = f"https://graph.facebook.com/v21.0/{ig['ig_user_id']}", ig["token"]
        cont = _post_json(f"{base}/media?access_token={tk}",
                          {"media_type": "REELS", "upload_type": "resumable",
                           "caption": self.texto(job)}, {})
        req = urllib.request.Request(cont["uri"], data=video.read_bytes(), method="POST",
                                     headers={"Authorization": f"OAuth {tk}", "offset": "0",
                                              "file_size": str(video.stat().st_size)})
        urllib.request.urlopen(req, timeout=300)
        # o Instagram processa o vídeo antes de deixar publicar: espera o container ficar pronto
        for _ in range(60):
            estado = _get_json(f"https://graph.facebook.com/v21.0/{cont['id']}"
                               f"?fields=status_code,status&access_token={tk}")
            if estado.get("status_code") == "FINISHED":
                break
            if estado.get("status_code") in ("ERROR", "EXPIRED"):
                raise RuntimeError(f"o Instagram recusou o vídeo: {estado.get('status')}")
            time.sleep(5)
        else:
            raise RuntimeError("o Instagram ainda processava o vídeo depois de 5 minutos")
        pub = _post_json(f"{base}/media_publish?access_token={tk}", {"creation_id": cont["id"]}, {})
        return f"instagram media {pub.get('id')}"

    # ---------- Postiz: as três redes numa chamada só ----------
    def postiz(self, job: Job, video: Path, cfg: dict, plataformas: list[str]) -> dict[str, str]:
        api = Postiz()
        contas = api.contas()
        escolhidas = cfg.get("postiz_contas") or {}  # {"tiktok": "<id da conta no Postiz>", ...}
        alvo = {}
        for plat in plataformas:
            ids = [c["id"] for c in contas if c["identifier"].split("-")[0] == plat]
            # com vários canais, cada um diz a sua conta; a única da rede só vale sem canais
            conta = escolhidas.get(plat) or (ids[0] if len(ids) == 1 and not job.canal else None)
            achada = next((c for c in contas if c["id"] == conta), None)
            if achada:
                alvo[plat] = achada
        faltam = [p for p in plataformas if p not in alvo]
        if not alvo:
            raise RuntimeError("nenhuma conta do Postiz para este canal (veja postiz_contas no README)")
        midia = api.enviar_video(video)
        imagem = [{"id": midia["id"], "path": midia["path"]}]
        titulo = job.arquivos["titulo"]
        ajustes = {
            "tiktok": {"privacy_level": cfg.get("tiktok_privacidade", "SELF_ONLY"), "duet": True,
                       "stitch": True, "comment": True, "autoAddMusic": "no",
                       "brand_content_toggle": False, "brand_organic_toggle": False,
                       "video_made_with_ai": bool(cfg.get("rotulo_ia", True)),
                       "content_posting_method": "DIRECT_POST"},
            "youtube": {"title": (titulo[:90] + " #shorts")[:100],
                        "type": cfg.get("youtube_privacidade", "public"), "selfDeclaredMadeForKids": "no",
                        "tags": [{"value": h, "label": h} for h in job.hashtags[:8]]},
            "instagram": {"post_type": "post", "is_trial_reel": False, "collaborators": []},
        }
        posts = [{"integration": {"id": c["id"]},
                  "value": [{"content": self.texto(job)[:2000], "image": imagem}],
                  "settings": {"__type": c["identifier"], **ajustes.get(plat, {})}}
                 for plat, c in alvo.items()]
        agora = datetime.now(timezone.utc).isoformat()
        resp = api.pedir("/posts", json.dumps({"type": "now", "date": agora, "shortLink": False,
                                                "tags": [], "posts": posts}).encode())
        ids = {r.get("integration"): r.get("postId") for r in resp}
        saida = {plat: f"postiz {ids.get(c['id'], 'enviado')} ({c.get('profile') or c['name']})"
                 for plat, c in alvo.items()}
        saida.update({p: "sem conta no Postiz (confira postiz_contas no canal.json)" for p in faltam})
        return saida

    @staticmethod
    def credenciais(job: Job) -> Path:
        """Cada canal posta na própria conta, sempre de credenciais/<canal>/: sem essa pasta o
        canal fica "sem credenciais", em vez de postar na conta de outro canal."""
        return CRED / job.canal if job.canal else CRED

    def processar(self, job: Job) -> Job:
        cfg = self.conf(job)
        video = Path(job.arquivos["final"])
        pacote = (canais.pasta(job.canal) / "prontos" if job.canal else RAIZ / "saida" / "prontos") / job.id
        pacote.mkdir(parents=True, exist_ok=True)
        shutil.copy2(video, pacote / "video.mp4")
        if cfg.get("capa", True):  # capa.jpg: o quadro com o título, para escolher como capa ao postar
            try:
                self.rodar(["ffmpeg", "-y", "-v", "error", "-ss", str(cfg.get("capa_segundo", 1.2)),
                            "-i", str(pacote / "video.mp4"), "-frames:v", "1", "-q:v", "2",
                            str(pacote / "capa.jpg")], timeout=60)
            except Exception as e:
                self.log(f"não consegui tirar a capa ({str(e)[:60]})", "aviso")
        meta = {"canal": cfg.get("nome", job.canal), "titulo": job.arquivos["titulo"],
                "descricao": self.texto(job), "fonte": job.referencia.get("fonte", ""),
                "duracao_s": round(job.arquivos.get("duracao", 0), 1),
                "rotulo_ia": bool(cfg.get("rotulo_ia")),  # ao postar à mão, marque "feito com IA"

                "referencia": job.referencia, "roteiro": job.roteiro}
        (pacote / "post.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        (pacote / "descricao.txt").write_text(f"{job.arquivos['titulo']}\n\n{self.texto(job)}\n",
                                             encoding="utf-8")  # para copiar e colar ao postar à mão
        canais.confirmar(job)  # o pacote existe: o roteiro conta como usado (antes de publicar)
        real = bool(cfg.get("postar_de_verdade"))  # o canal.json pode desligar só aquele canal

        plataformas = cfg.get("plataformas", ["youtube", "tiktok", "instagram"])
        if real and cfg.get("postador") == "postiz":
            self.tarefa(f"publicando pelo Postiz (job {job.id})")
            try:
                job.postagens.update(self.postiz(job, pacote / "video.mp4", cfg, plataformas))
                self.log("Postiz: " + "; ".join(f"{k}: {v}" for k, v in job.postagens.items()))
            except FileNotFoundError:
                job.postagens["postiz"] = "sem credenciais"
                self.log("Postiz: falta a chave em credenciais/postiz.json", "aviso")
            except Exception as e:
                job.postagens["postiz"] = f"falhou: {e!r}"
                self.log(f"Postiz falhou: {e}", "erro")
            plataformas = []
        for plataforma in plataformas:
            self.tarefa(f"publicando no {plataforma} (job {job.id})")
            if not real:
                job.postagens[plataforma] = "pronto (modo seguro, não publicado)"
                continue
            try:
                job.postagens[plataforma] = getattr(self, plataforma)(job, pacote / "video.mp4",
                                                                      cfg, self.credenciais(job))
                self.log(f"{plataforma}: {job.postagens[plataforma]}")
            except FileNotFoundError:
                job.postagens[plataforma] = "sem credenciais"
                self.log(f"{plataforma}: credenciais ausentes em credenciais/", "aviso")
            except Exception as e:
                job.postagens[plataforma] = f"falhou: {e}"
                self.log(f"{plataforma} falhou: {e}", "erro")
        (pacote / "post.json").write_text(json.dumps({**meta, "postagens": job.postagens},
                                                     ensure_ascii=False, indent=2), encoding="utf-8")
        extra = str(cfg.get("pasta_para_postar") or "").strip()
        if extra:  # cópia para uma pasta sincronizada (ex.: Google Drive) abrir no celular e postar à mão
            try:
                destino = Path(extra).expanduser() / (job.canal or "geral") / job.id
                destino.mkdir(parents=True, exist_ok=True)
                for nome in ("video.mp4", "descricao.txt", "capa.jpg"):
                    if (pacote / nome).exists():
                        shutil.copy2(pacote / nome, destino / nome)
                self.log(f"cópia para postar em {destino}")
            except Exception as e:
                self.log(f"não consegui copiar para pasta_para_postar ({str(e)[:80]})", "aviso")
        if not real:
            self.log(f"pacote pronto em {pacote.relative_to(RAIZ).as_posix()} (nada foi publicado)")
        if not self.cfg.get("manter_intermediarios"):
            shutil.rmtree(job.pasta, ignore_errors=True)
        self.tele.videos_prontos += 1
        if job.canal:
            self.tele.canal(job.canal, prontos=1)
        self.tele.salvar()
        return None
