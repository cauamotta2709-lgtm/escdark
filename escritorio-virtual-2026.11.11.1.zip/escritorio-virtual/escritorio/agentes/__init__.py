from .carregador import Carregador
from .editor import Editor
from .legendador import Legendador
from .olheiro import Olheiro
from .postador import Postador
from .referencias import Referencias

# Ordem da linha de produção. O Legendador vem antes do Editor para o vídeo ser
# renderizado uma única vez, já com as legendas queimadas.
LINHA = [Olheiro, Referencias, Carregador, Legendador, Editor, Postador]
