"""Referências de cultura pop (filmes, séries, memes, jogos e assuntos virais) citadas nos roteiros, do jeito seguro para o canal.

O Olheiro chama `aplicar()` depois de escolher o roteiro. Se o assunto combina com alguma entrada de
escritorio/referencias_cultura.json (palavras-chave do roteiro), entra UMA frase narrada citando a obra, por exemplo
"Quem viu Interestelar lembra: perto de um buraco negro, o tempo passa mais devagar de verdade."
A legenda segue a fala sozinha e a descrição do vídeo ganha a linha "Referência citada".

Regras de segurança contra bloqueio e strike por direitos autorais:
  - só CITA o nome da obra e um fato verdadeiro ligado ao assunto;
  - nunca usa trechos, cenas, pôsteres, capas, trilha ou imagens oficiais;
  - a imagem da frase é uma imagem genérica criada por IA (ou foto livre da Commons), e o pedido
    não leva o nome do filme, de personagens nem de atores.

config.json: referencias_filmes (true), referencias_filmes_pausa (quantos vídeos esperar antes de repetir
a mesma obra, padrão 8). Pode desligar num canal só pelo canal.json.
"""
from __future__ import annotations

import json
import re
import unicodedata
from pathlib import Path

from .nucleo import RAIZ

ARQ = Path(__file__).resolve().parent / "referencias_cultura.json"  # dentro de escritorio/: o atualizador leva junto
HISTORICO = RAIZ / "saida" / "referencias_usadas.json"


def _norm(texto: str) -> str:
    texto = unicodedata.normalize("NFKD", texto.lower())
    return "".join(c for c in texto if not unicodedata.combining(c))


def _carregar() -> list[dict]:
    try:
        return json.loads(ARQ.read_text(encoding="utf-8-sig")).get("referencias", [])
    except (OSError, ValueError):
        return []


def _usadas() -> list[str]:
    try:
        return json.loads(HISTORICO.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _guardar(ids: list[str]) -> None:
    try:
        HISTORICO.parent.mkdir(parents=True, exist_ok=True)
        HISTORICO.write_text(json.dumps(ids[-40:]), encoding="utf-8")
    except OSError:
        pass


def escolher(frases: list[str], tema: str, titulo: str, pausa: int = 8) -> tuple[dict, int] | None:
    """Melhor referência para o roteiro e o índice da frase que a motivou (None se nada combina)."""
    texto_frases = [_norm(f) for f in frases]
    cabecalho = _norm(f"{titulo} {tema}")
    recentes = set(_usadas()[-pausa:]) if pausa else set()
    melhor = None
    for ref in _carregar():
        if ref["id"] in recentes or ref["titulo"].lower() in {t.lower() for t in
                                                              [titulo, tema] if t}:
            continue
        achadas, primeira = 0, None
        no_titulo = False
        for chave in ref.get("chaves", []):
            padrao = re.compile(rf"(?<!\w){re.escape(_norm(chave))}(?!\w)")
            onde = [i for i, f in enumerate(texto_frases) if padrao.search(f)]
            titulo_tem = bool(padrao.search(cabecalho))
            # só vale se o assunto é central: está no título/tema, ou aparece em 2+ frases, ou 2+ chaves batem
            if titulo_tem or len(onde) >= 2:
                no_titulo = True
            if onde or titulo_tem:
                achadas += 1
                if onde and (primeira is None or onde[0] < primeira):
                    primeira = onde[0]
        if not achadas or not (no_titulo or achadas >= 2):
            continue
        pontos = achadas * 2 + int(ref.get("viral", 1))
        if melhor is None or pontos > melhor[0]:
            melhor = (pontos, ref, primeira if primeira is not None else len(frases) // 2)
    return (melhor[1], melhor[2]) if melhor else None


def aplicar(job, cfg: dict, log=print) -> dict | None:
    """Insere a frase da referência no roteiro do job (e a imagem/busca alinhada a ela)."""
    if cfg.get("referencias_filmes", True) is False or len(job.roteiro) < 4:
        return None
    achado = escolher(job.roteiro, job.tema or "", (job.referencia or {}).get("titulo", ""),
                      int(cfg.get("referencias_filmes_pausa", 8)))
    if not achado:
        return None
    ref, motivo = achado
    # entra depois da frase que fala do assunto, nunca no gancho (1ª) nem no fechamento (última)
    pos = min(max(motivo + 1, 2), len(job.roteiro) - 1)
    job.roteiro.insert(pos, ref["frase"])
    if "imagens" in job.arquivos:  # roteiro do banco: uma imagem de IA por frase
        imagens = list(job.arquivos["imagens"])
        imagens += [None] * (len(job.roteiro) - 1 - len(imagens))
        imagens.insert(pos, {"ia": ref["imagem_ia"], "busca": ref["busca"]})
        job.arquivos["imagens"] = imagens
    if job.buscas:  # roteiro escrito pela IA local: busca de imagem alinhada
        job.buscas.insert(pos, ref["busca"])
        job.arquivos["buscas_pt"] = [False] * len(job.roteiro)
    creditos = job.arquivos.setdefault("creditos", [])
    nada = "Nenhum trecho, cena ou imagem da obra foi usado; só o nome é citado." \
        if ref["tipo"] in ("filme", "série", "jogo") else \
        "Nenhuma imagem original foi usada; as imagens do vídeo são geradas ou livres."
    creditos.append(f"Referência citada: {ref['titulo']} ({ref['tipo']}, {ref['ano']}). {nada}")
    job.arquivos["referencia_cultura"] = {"id": ref["id"], "titulo": ref["titulo"], "frase": pos}
    _guardar(_usadas() + [ref["id"]])
    log(f"referência: {ref['tipo']} “{ref['titulo']}” citada na frase {pos + 1} (job {job.id})")
    return ref
