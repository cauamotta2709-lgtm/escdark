"""LLM local e gratuito via Ollama (https://ollama.com). Sem Ollama, cai num modelo de texto
por regras, para o escritório continuar funcionando. Retorna (texto, tokens_usados)."""
from __future__ import annotations

import json
import threading
import urllib.request

OLLAMA = "http://127.0.0.1:11434"
_tentados: set[str] = set()  # tenta baixar cada modelo só uma vez por execução


def _modelos() -> list[str] | None:
    """Modelos já baixados no Ollama, ou None se o Ollama não está ligado."""
    try:
        with urllib.request.urlopen(OLLAMA + "/api/tags", timeout=2) as r:
            return [m.get("name", "") for m in json.loads(r.read()).get("models", [])]
    except (OSError, ValueError):
        return None


def tem_modelo(modelo: str, nomes: list[str]) -> bool:
    alvo = modelo if ":" in modelo else modelo + ":latest"
    return any(n == alvo or n == modelo for n in nomes)


def disponivel(modelo: str = "llama3.2:3b") -> bool:
    """True só se o Ollama está ligado E o modelo já foi baixado. Se o Ollama está ligado mas
    o modelo não, começa a baixá-lo em segundo plano (os próximos vídeos já usam)."""
    nomes = _modelos()
    if nomes is None:
        return False
    if tem_modelo(modelo, nomes):
        return True
    baixar_em_segundo_plano(modelo)
    return False


def baixar_em_segundo_plano(modelo: str) -> None:
    if modelo in _tentados:
        return
    _tentados.add(modelo)

    def puxar() -> None:
        try:
            req = urllib.request.Request(OLLAMA + "/api/pull",
                                         data=json.dumps({"model": modelo, "stream": False}).encode(),
                                         headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=3600).read()
            print(f"[ollama] modelo {modelo} baixado; os próximos vídeos usam a IA local.", flush=True)
        except Exception as e:
            print(f"[ollama] não deu para baixar {modelo} ({e}). Rode no terminal: "
                  f"ollama pull {modelo}", flush=True)
    threading.Thread(target=puxar, daemon=True).start()
    print(f"[ollama] baixando o modelo {modelo} em segundo plano (cerca de 2 GB); "
          "enquanto isso o roteiro usa o modo por regras.", flush=True)


def gerar(prompt: str, modelo: str = "llama3.2:3b", json_saida: bool = False) -> tuple[str, int]:
    corpo = {"model": modelo, "prompt": prompt, "stream": False,
             "options": {"temperature": 0.8, "num_predict": 400}}
    if json_saida:
        corpo["format"] = "json"
    req = urllib.request.Request(OLLAMA + "/api/generate", data=json.dumps(corpo).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=180) as r:
        resp = json.loads(r.read())
    tokens = resp.get("prompt_eval_count", 0) + resp.get("eval_count", 0)
    return resp.get("response", ""), tokens
