"""Núcleo do escritório: agentes em threads, fila entre eles e telemetria de consumo.

Cada agente roda numa thread própria e passa o "job" (um vídeo em produção) para o
próximo pela fila. Tudo que o agente faz é medido: CPU (da thread e dos processos
filhos, como o ffmpeg), memória, tokens de LLM e custo. O painel lê esse estado.
"""
from __future__ import annotations

import contextlib
import importlib.util
import json
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
import traceback
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

RAIZ = Path(__file__).resolve().parent.parent


@dataclass
class Job:
    """Um vídeo passando pela linha de produção."""
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    tema: str = ""
    referencia: dict = field(default_factory=dict)
    roteiro: list[str] = field(default_factory=list)
    buscas: list[str] = field(default_factory=list)  # o que mostrar na tela em cada frase
    arquivos: dict = field(default_factory=dict)
    legenda: str = ""
    hashtags: list[str] = field(default_factory=list)
    postagens: dict = field(default_factory=dict)
    criado_em: float = field(default_factory=time.time)
    canal: str = ""  # pasta do canal em canais/ (vazio = sem canais configurados)
    cfg: dict = field(default_factory=dict)  # config.json + canal.json deste vídeo

    @property
    def pasta(self) -> Path:
        p = RAIZ / "saida" / self.id
        p.mkdir(parents=True, exist_ok=True)
        return p


class Telemetria:
    """Estado compartilhado de todos os agentes, lido pelo painel."""

    def __init__(self) -> None:
        self._trava = threading.Lock()
        self.agentes: dict[str, dict] = {}
        self.eventos: list[dict] = []
        self._ouvintes: list[queue.Queue] = []
        self.inicio = time.time()
        self.videos_prontos = 0
        self.canais: dict[str, dict] = {}  # pasta -> {nome, nicho, prontos, roteiros}
        self.pausado = self._ler_pausa()  # botão "pausar produção" do painel (lembra ao reabrir)

    # --- pausa da produção: o programa fica aberto, mas ninguém pega trabalho novo ---
    ARQ_PAUSA = RAIZ / "saida" / "producao.json"

    def _ler_pausa(self) -> bool:
        try:
            return bool(json.loads(self.ARQ_PAUSA.read_text(encoding="utf-8")).get("pausado"))
        except (OSError, ValueError):
            return False

    def definir_pausa(self, pausado: bool) -> bool:
        """Pausa ou retoma a produção. Cada agente termina o que está fazendo e só então para."""
        pausado = bool(pausado)
        with self._trava:
            mudou = pausado != self.pausado
            self.pausado = pausado
            self._emitir({"tipo": "producao", "dados": {"pausado": pausado}})
        try:
            self.ARQ_PAUSA.parent.mkdir(parents=True, exist_ok=True)
            self.ARQ_PAUSA.write_text(json.dumps({"pausado": pausado}), encoding="utf-8")
        except OSError:
            pass
        if mudou:
            print(f"[{time.strftime('%H:%M:%S')}] produção {'pausada' if pausado else 'retomada'} pelo painel", flush=True)
            with self._trava:
                self.eventos.append({"tipo": "log", "agente": "olheiro", "nivel": "aviso" if pausado else "info", "t": time.time(),
                                     "texto": "produção pausada: cada agente termina o vídeo que está fazendo e para"
                                              if pausado else "produção retomada"})
                self._emitir(self.eventos[-1])
        return pausado

    def registrar(self, agente: "Agente") -> None:
        with self._trava:
            self.agentes[agente.chave] = {
                "chave": agente.chave, "nome": agente.nome, "cargo": agente.cargo,
                "emoji": agente.emoji, "status": "parado", "tarefa": "",
                "feitos": 0, "erros": 0, "cpu_s": 0.0, "ram_mb": 0.0,
                "tokens": 0, "custo": 0.0, "tempo_trabalho_s": 0.0,
                "fila": 0, "motor": agente.motor,
            }

    def atualizar(self, chave: str, **campos: Any) -> None:
        with self._trava:
            a = self.agentes[chave]
            if all(a.get(k) == v for k, v in campos.items()):
                return
            a.update(campos)
            self._emitir({"tipo": "agente", "dados": dict(self.agentes[chave])})

    def somar(self, chave: str, **campos: float) -> None:
        with self._trava:
            a = self.agentes[chave]
            for k, v in campos.items():
                a[k] = round(a[k] + v, 3)
            self._emitir({"tipo": "agente", "dados": dict(a)})

    def canal(self, pasta: str, **campos: Any) -> None:
        """Atualiza o quadro de canais do painel (prontos=+1 soma um vídeo pronto)."""
        with self._trava:
            c = self.canais.setdefault(pasta, {"pasta": pasta, "nome": pasta, "nicho": "",
                                              "prontos": 0, "roteiros": None})
            c["prontos"] += campos.pop("prontos", 0)
            c.update(campos)
            self._emitir({"tipo": "canais", "dados": list(self.canais.values())})

    def zerar_rodada(self) -> None:
        """Começo de uma rodada nova (--sempre): zera os contadores e repinta o painel."""
        with self._trava:
            self.videos_prontos = 0
            for c in self.canais.values():
                c["prontos"] = 0
            for a in self.agentes.values():
                a["erros"] = 0
        foto = self.instantaneo()
        with self._trava:
            self._emitir({"tipo": "tudo", "dados": foto})

    def log(self, chave: str, texto: str, nivel: str = "info") -> None:
        ev = {"tipo": "log", "agente": chave, "texto": texto, "nivel": nivel, "t": time.time()}
        with self._trava:
            self.eventos.append(ev)
            del self.eventos[:-300]
            self._emitir(ev)
        print(f"[{time.strftime('%H:%M:%S')}] {chave:>10} | {texto}", flush=True)

    def instantaneo(self) -> dict:
        with self._trava:
            return {
                "agentes": list(self.agentes.values()),
                "eventos": self.eventos[-80:],
                "inicio": self.inicio,
                "videos_prontos": self.videos_prontos,
                "canais": list(self.canais.values()),
                "pausado": self.pausado,
            }

    def ouvir(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=1000)
        with self._trava:
            self._ouvintes.append(q)
        return q

    def parar_de_ouvir(self, q: queue.Queue) -> None:
        with self._trava:
            if q in self._ouvintes:
                self._ouvintes.remove(q)

    def _emitir(self, ev: dict) -> None:
        for q in list(self._ouvintes):
            try:
                q.put_nowait(ev)
            except queue.Full:
                pass

    def salvar(self) -> None:
        destino = RAIZ / "saida" / "telemetria.json"
        destino.parent.mkdir(parents=True, exist_ok=True)
        destino.write_text(json.dumps(self.instantaneo(), ensure_ascii=False, indent=1),
                           encoding="utf-8")


try:  # psutil mede CPU e RAM no Windows, macOS e Linux; sem ele, só Linux via /proc
    import psutil
except ImportError:
    psutil = None


# --- leveza: poucos trabalhos pesados ao mesmo tempo e o programa com prioridade baixa ---
_pesado = threading.BoundedSemaphore(2)


def configurar_pesado(n: int) -> None:
    """Quantas renderizações/transcrições pesadas podem rodar juntas (todos os agentes somados)."""
    global _pesado
    _pesado = threading.BoundedSemaphore(max(1, int(n)))


def baixar_prioridade() -> None:
    """O escritório passa a rodar com prioridade abaixo do normal: o PC continua leve para você usar,
    e o ffmpeg e o whisper (que herdam isso) só pegam a CPU que sobra."""
    try:
        if os.name == "nt":
            import ctypes
            ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x4000)
        else:
            os.nice(5)
    except Exception:
        pass


def tem(programa: str) -> bool:
    return shutil.which(programa) is not None


def preparar_ffmpeg() -> bool:
    """Garante que ffmpeg e ffprobe estão acessíveis. No Windows, o winget instala o ffmpeg mas a
    janela já aberta não enxerga o PATH novo; aqui procuramos nas pastas onde ele costuma ficar."""
    if tem("ffmpeg") and tem("ffprobe"):
        return True
    if os.name != "nt":
        return False
    local = Path(os.environ.get("LOCALAPPDATA", ""))
    candidatas = [local / "Microsoft" / "WinGet" / "Links",
                  *sorted((local / "Microsoft" / "WinGet" / "Packages").glob("*FFmpeg*/**/bin")),
                  Path("C:/ffmpeg/bin"), Path(os.environ.get("ProgramFiles", "C:/Program Files")) / "ffmpeg" / "bin",
                  Path("C:/ProgramData/chocolatey/bin")]
    for pasta in candidatas:
        if (pasta / "ffmpeg.exe").exists() and (pasta / "ffprobe.exe").exists():
            os.environ["PATH"] = f"{pasta}{os.pathsep}{os.environ.get('PATH', '')}"
            return True
    return False


def tem_modulo(modulo: str) -> bool:
    return importlib.util.find_spec(modulo) is not None


def py(modulo: str, *args: str) -> list[str]:
    """Comando para rodar um módulo Python instalado (funciona mesmo fora do PATH, no Windows)."""
    return [sys.executable, "-m", modulo, *args]


def rss_mb() -> float:
    """Memória residente deste processo."""
    if psutil:
        return psutil.Process().memory_info().rss / 2**20
    try:
        for linha in Path("/proc/self/status").read_text().splitlines():
            if linha.startswith("VmRSS:"):
                return int(linha.split()[1]) / 1024
    except OSError:
        pass
    return 0.0


def medir_pid(pid: int) -> tuple[float, float]:
    """(CPU em s, RAM em MB) de um processo ainda em execução."""
    try:
        if psutil:
            p = psutil.Process(pid)
            t = p.cpu_times()
            return t.user + t.system, p.memory_info().rss / 2**20
        campos = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        return ((int(campos[11]) + int(campos[12])) / os.sysconf("SC_CLK_TCK"),
                int(campos[21]) * os.sysconf("SC_PAGE_SIZE") / 2**20)
    except Exception:
        return 0.0, 0.0


class Agente(threading.Thread):
    chave = "agente"
    nome = "Agente"
    cargo = ""
    emoji = "🤖"
    motor = "local"

    def __init__(self, tele: Telemetria, cfg: dict, entrada: queue.Queue | None,
                 saida: queue.Queue | None, numero: int = 1) -> None:
        if numero > 1:  # cópias extras do mesmo agente dividem a mesma fila
            self.chave, self.nome = f"{self.chave}{numero}", f"{self.nome} {numero}"
        super().__init__(name=self.chave, daemon=True)
        self.tele, self.cfg = tele, cfg
        self.entrada, self.saida = entrada, saida
        self.parar = threading.Event()
        tele.registrar(self)

    # --- utilidades para as subclasses ---
    def log(self, texto: str, nivel: str = "info") -> None:
        self.tele.log(self.chave, texto, nivel)

    def tarefa(self, texto: str) -> None:
        self.tele.atualizar(self.chave, tarefa=texto)

    def conf(self, job: Job | None) -> dict:
        """Configuração que vale para este vídeo: a do canal dele, ou a geral."""
        return job.cfg if job is not None and job.cfg else self.cfg

    @contextlib.contextmanager
    def vaga_pesada(self, o_que: str = "trabalho pesado"):
        """Espera uma vaga para trabalho pesado (render, transcrição). Evita 2 agentes pesados disputando o PC."""
        antes = self.tele.agentes[self.chave].get("tarefa", "")
        if not _pesado.acquire(blocking=False):
            self.tarefa(f"esperando vaga para {o_que} (o PC está ocupado com outro vídeo)")
            while not _pesado.acquire(timeout=0.5):
                if self.parar.is_set():
                    raise RuntimeError("encerrado")
            self.tarefa(antes)
        try:
            yield
        finally:
            _pesado.release()

    def rodar(self, cmd: list[str], timeout: int = 600, entrada: bytes | None = None
              ) -> subprocess.CompletedProcess:
        """Roda um processo filho, mostrando ao vivo a CPU e a RAM que ele gasta."""
        if "-c:v" in cmd:  # codificação de vídeo é o que mais pesa: uma de cada vez por vaga
            with self.vaga_pesada("renderizar"):
                return self._rodar(cmd, timeout, entrada)
        return self._rodar(cmd, timeout, entrada)

    def _rodar(self, cmd: list[str], timeout: int = 600, entrada: bytes | None = None
               ) -> subprocess.CompletedProcess:
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE if entrada else None,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        limite, cpu_contada, ram = time.time() + timeout, 0.0, 0.0
        while True:
            try:  # communicate em fatias de 0,5 s: não trava com saída grande e deixa medir
                out, err = proc.communicate(entrada, timeout=0.5)
                break
            except subprocess.TimeoutExpired:
                entrada = None
                if time.time() > limite or self.parar.is_set():
                    proc.kill()
                cpu, mem = medir_pid(proc.pid)
                ram = max(ram, mem)
                if cpu > cpu_contada:
                    self.tele.somar(self.chave, cpu_s=cpu - cpu_contada)
                    cpu_contada = cpu
        self.tele.atualizar(self.chave, ram_mb=round(max(self.tele.agentes[self.chave]["ram_mb"], ram), 1))
        if proc.returncode != 0:
            raise RuntimeError(f"{Path(cmd[0]).name} falhou ({proc.returncode}): "
                               f"{err.decode(errors='ignore')[-400:]}")
        return subprocess.CompletedProcess(cmd, proc.returncode, out, err)

    def contar_tokens(self, tokens: int, custo: float = 0.0) -> None:
        self.tele.somar(self.chave, tokens=tokens, custo=custo)

    # --- ciclo de vida ---
    def processar(self, job: Job) -> Job | list[Job] | None:
        raise NotImplementedError

    def proximo_job(self) -> Job | None:
        try:
            return self.entrada.get(timeout=0.5) if self.entrada else None
        except queue.Empty:
            return None

    def run(self) -> None:
        while not self.parar.is_set():
            self.tele.atualizar(self.chave, fila=self.entrada.qsize() if self.entrada else 0)
            if self.tele.pausado:  # produção pausada pelo painel: não pega trabalho novo
                self.tele.atualizar(self.chave, status="parado", tarefa="produção pausada")
                self.parar.wait(0.5)
                continue
            job = self.proximo_job()
            if job is None:
                self.tele.atualizar(self.chave, status="parado", tarefa="aguardando trabalho")
                continue
            self.tele.atualizar(self.chave, status="trabalhando")
            t0, c0 = time.perf_counter(), time.thread_time()
            try:
                resultado = self.processar(job)
                for j in resultado if isinstance(resultado, list) else [resultado]:
                    if j is not None and self.saida is not None:
                        self.saida.put(j)
                self.tele.somar(self.chave, feitos=1)
            except Exception as e:  # um erro não derruba o escritório
                self.tele.somar(self.chave, erros=1)
                self.log(f"erro no job {job.id}: {e}", "erro")
                traceback.print_exc()
            finally:
                self.tele.somar(self.chave, cpu_s=time.thread_time() - c0,
                                tempo_trabalho_s=time.perf_counter() - t0)
                self.tele.atualizar(self.chave, ram_mb=round(max(
                    self.tele.agentes[self.chave]["ram_mb"], rss_mb()), 1))
