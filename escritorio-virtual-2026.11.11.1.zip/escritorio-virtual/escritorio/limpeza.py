"""Limpeza automática dos vídeos prontos, para não lotar o computador.

Roda sozinha ao abrir o escritório (e a cada rodada diária com --sempre). Mexe SÓ em pastas de vídeo
com nome de 8 letras/números (o id do vídeo) dentro de:
  canais/<canal>/prontos/   saida/prontos/   e a pasta_para_postar (a cópia que vai para o Drive).
Nunca toca em roteiros, bancos, usados.json, credenciais, config.json, canal.json, música, fundos, clipes.

Regras (config.json):
  limpeza_ativa       true/false (padrão true)
  dias_apos_publicar  vídeo marcado "já publicado" na biblioteca é apagado N dias depois da marcação (padrão 3)
  limite_gb           proteção de espaço: se os vídeos passarem disso, apaga antes do prazo os já publicados,
                      do mais antigo ao mais novo; 0 = sem limite (padrão 15)
Vídeo "a publicar" NUNCA é apagado (se o limite estourar só com eles, a limpeza avisa e deixa tudo).
O estado de cada vídeo fica em saida/biblioteca.json (veja biblioteca.py). Cada remoção vai para saida/limpeza.log.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import stat
import time
from pathlib import Path

from . import biblioteca
from .nucleo import RAIZ

ID = re.compile(r"^[0-9a-f]{8}$")
ARQUIVOS_DO_VIDEO = {"video.mp4", "post.json", "descricao.txt"}
REGISTRO = RAIZ / "saida" / "limpeza.log"
ESTADO = RAIZ / "saida" / "limpeza.json"


def _tamanho(pasta: Path) -> int:
    total = 0
    for dirpath, _, nomes in os.walk(pasta):
        for n in nomes:
            try:
                total += os.path.getsize(os.path.join(dirpath, n))
            except OSError:
                pass
    return total


def _apagar(pasta: Path) -> bool:
    def forcar(func, caminho, _info):
        try:
            os.chmod(caminho, stat.S_IWRITE | stat.S_IREAD)
            func(caminho)
        except OSError:
            pass
    shutil.rmtree(pasta, onerror=forcar)
    return not pasta.exists()


def _quando_post(pasta: Path) -> float:
    try:
        return (pasta / "post.json").stat().st_mtime
    except OSError:
        return 0.0


def _publicado(pasta: Path) -> bool:
    """Mesma regra do painel: link/id do YouTube, TikTok, Instagram ou Postiz = publicado."""
    try:
        post = json.loads((pasta / "post.json").read_text(encoding="utf-8-sig")).get("postagens") or {}
    except (OSError, ValueError):
        return False
    return any(not str(v).startswith(("pronto", "falhou", "sem credenciais")) for v in post.values())


def _videos(cfg: dict) -> list[dict]:
    """Todas as pastas de vídeo pronto (e as cópias na pasta_para_postar), com id, idade e tamanho."""
    itens: list[dict] = []
    bases = [(p.parent.name, p, "prontos") for p in sorted((RAIZ / "canais").glob("*/prontos"))]
    bases.append(("geral", RAIZ / "saida" / "prontos", "prontos"))
    extra = str(cfg.get("pasta_para_postar") or "").strip()
    if extra:
        raiz_extra = Path(extra).expanduser()
        if raiz_extra.is_dir() and raiz_extra.resolve() not in (RAIZ.resolve(), Path(raiz_extra.anchor)):
            bases += [(c.name, c, "para_postar") for c in sorted(raiz_extra.iterdir()) if c.is_dir()]
    for canal, base, tipo in bases:
        if not base.is_dir():
            continue
        for pasta in base.iterdir():
            if not (pasta.is_dir() and ID.match(pasta.name)):
                continue
            arquivos = {a.name for a in pasta.iterdir()}
            if not arquivos or not arquivos <= ARQUIVOS_DO_VIDEO:  # tem algo estranho dentro: não mexe
                continue
            video = pasta / "video.mp4"
            try:
                quando = (video if video.exists() else pasta).stat().st_mtime
            except OSError:
                continue
            itens.append({"pasta": pasta, "id": pasta.name, "canal": canal, "tipo": tipo,
                          "quando": quando, "bytes": _tamanho(pasta)})
    return itens


def _classificar(itens: list[dict], marcas: dict) -> None:
    """Põe em cada item o estado (publicado/a_publicar) e o momento em que foi publicado."""
    for i in itens:
        # a cópia da pasta para postar usa o post.json do vídeo original, se achar
        post = i["pasta"] if (i["pasta"] / "post.json").is_file() else None
        real = bool(post and _publicado(post))
        i["estado"], i["publicado_em"] = biblioteca.estado_de(marcas, i["canal"], i["id"], real,
                                                              _quando_post(post) if post else 0.0)


def resumo(cfg: dict | None = None) -> dict:
    """Espaço usado pelos vídeos e o que a última limpeza fez (para o painel)."""
    if cfg is None:
        try:
            cfg = json.loads((RAIZ / "config.json").read_text(encoding="utf-8-sig"))
        except (OSError, ValueError):
            cfg = {}
    itens = _videos(cfg)
    _classificar(itens, biblioteca.ler())
    try:
        ultima = json.loads(ESTADO.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        ultima = {}
    ids = {(i["canal"], i["id"]): i for i in itens}.values()
    return {"ativa": cfg.get("limpeza_ativa", True) is not False,
            "dias_apos_publicar": biblioteca.dias(cfg), "limite_gb": cfg.get("limite_gb", 15),
            "videos": len(ids), "publicados": sum(i["estado"] == "publicado" for i in ids),
            "a_publicar": sum(i["estado"] == "a_publicar" for i in ids),
            "usado_gb": round(sum(i["bytes"] for i in itens) / 2**30, 2), "ultima": ultima}


def limpar(cfg: dict, log=print) -> dict:
    if cfg.get("limpeza_ativa", True) is False:
        return {}
    dias = biblioteca.dias(cfg)
    limite = float(cfg.get("limite_gb", 15) or 0) * 2**30
    itens = _videos(cfg)
    if not itens:
        return {}
    _classificar(itens, biblioteca.ler())
    agora = time.time()
    removidos: list[dict] = []
    aviso = ""

    def remover(item: dict, motivo: str) -> None:
        if item["estado"] != "publicado":  # trava final: "a publicar" nunca sai daqui
            return
        if _apagar(item["pasta"]):
            removidos.append(item)
            log(f"limpeza | removi {item['canal']}/{item['id']} ({item['tipo']}, "
                f"{item['bytes'] / 2**20:.0f} MB): {motivo}")
        else:
            log(f"limpeza | não consegui remover {item['pasta']} (arquivo em uso?)")

    for item in itens:  # 1) publicados há mais de `dias` dias
        if item["estado"] == "publicado" and item["publicado_em"] and agora - item["publicado_em"] > dias * 86400:
            remover(item, f"publicado há mais de {dias:g} dias")
    if limite > 0:  # 2) proteção de espaço: adianta os já publicados, do mais antigo
        restantes = [i for i in itens if i not in removidos]
        usado = sum(i["bytes"] for i in restantes)
        for item in sorted((i for i in restantes if i["estado"] == "publicado"), key=lambda x: x["publicado_em"] or 0):
            if usado <= limite:
                break
            remover(item, f"espaço acima de {limite / 2**30:g} GB")
            usado -= item["bytes"] if item in removidos else 0
        if usado > limite:
            aviso = (f"vídeos ocupam {usado / 2**30:.1f} GB (limite {limite / 2**30:g}) e o que sobrou está "
                     "\"a publicar\": nada foi apagado. Publique e marque \"já publicado\".")
            log(f"limpeza | aviso: {aviso}")
    biblioteca.esquecer({f"{i['canal']}/{i['id']}" for i in removidos
                         if not any(o is not i and o["canal"] == i["canal"] and o["id"] == i["id"] and o not in removidos
                                    for o in itens)})
    liberado = sum(i["bytes"] for i in removidos)
    resultado = {"quando": time.strftime("%Y-%m-%d %H:%M"), "removidos": len({(i["canal"], i["id"]) for i in removidos}),
                 "liberado_mb": round(liberado / 2**20), "aviso": aviso}
    try:
        REGISTRO.parent.mkdir(parents=True, exist_ok=True)
        ESTADO.write_text(json.dumps(resultado, ensure_ascii=False), encoding="utf-8")
        if removidos:
            with open(REGISTRO, "a", encoding="utf-8") as f:
                for i in removidos:
                    f.write(f"{resultado['quando']} {i['canal']}/{i['id']} {i['tipo']} "
                            f"{i['bytes'] / 2**20:.0f}MB\n")
    except OSError:
        pass
    if removidos:
        log(f"limpeza | {resultado['removidos']} vídeo(s) removido(s), {resultado['liberado_mb']} MB liberados")
    return resultado
