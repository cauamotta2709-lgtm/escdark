#!/usr/bin/env python3
"""Autoriza o Postador a enviar vídeos para um canal do YouTube (faz uma vez por canal).

Antes: baixe o client_secret.json do Google Cloud (passo a passo no README) e salve em
credenciais/client_secret.json. Este script abre o navegador, você entra na conta do canal,
aceita, e ele grava o youtube_token.json que o Postador usa daí em diante.

    python autorizar_youtube.py                        -> credenciais/youtube_token.json
    python autorizar_youtube.py animais-sobrevivencia  -> credenciais/animais-sobrevivencia/youtube_token.json
"""
import sys
from pathlib import Path

from google_auth_oauthlib.flow import InstalledAppFlow

RAIZ = Path(__file__).resolve().parent
CRED = RAIZ / "credenciais"
if len(sys.argv) > 1 and not (RAIZ / "canais" / sys.argv[1] / "canal.json").exists():
    sys.exit(f"Não existe o canal '{sys.argv[1]}'. Canais: "
             + ", ".join(p.parent.name for p in sorted((RAIZ / "canais").glob("*/canal.json"))))
destino = CRED / sys.argv[1] if len(sys.argv) > 1 else CRED
destino.mkdir(parents=True, exist_ok=True)
fluxo = InstalledAppFlow.from_client_secrets_file(
    str(CRED / "client_secret.json"), ["https://www.googleapis.com/auth/youtube.upload"])
cred = fluxo.run_local_server(port=0)
(destino / "youtube_token.json").write_text(cred.to_json(), encoding="utf-8")
print(f"Pronto: {(destino / 'youtube_token.json').relative_to(CRED.parent).as_posix()} criado.")
