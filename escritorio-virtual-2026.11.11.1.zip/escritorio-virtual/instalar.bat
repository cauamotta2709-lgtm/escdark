@echo off
REM Instala tudo o que o escritorio usa no Windows. Tudo gratuito e open source.
REM Rode com dois cliques. Precisa de internet. Pode pedir para confirmar instalacoes.
cd /d "%~dp0"

where python >nul 2>nul || winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
where ffmpeg >nul 2>nul || winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
where ollama >nul 2>nul || winget install -e --id Ollama.Ollama --accept-source-agreements --accept-package-agreements

echo.
echo Se o Python, o ffmpeg ou o Ollama acabaram de ser instalados, FECHE esta janela
echo e rode o instalar.bat de novo, para o Windows enxergar os programas novos.
echo.

python -m pip install -U psutil yt-dlp piper-tts edge-tts faster-whisper google-api-python-client google-auth-oauthlib || goto erro
REM o faster-whisper ainda nao funciona com o av 14 ou mais novo
python -m pip install "av<14"

if not exist vozes mkdir vozes
set BASE=https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/medium
if not exist vozes\pt_BR-faber-medium.onnx curl -L -o vozes\pt_BR-faber-medium.onnx %BASE%/pt_BR-faber-medium.onnx
if not exist vozes\pt_BR-faber-medium.onnx.json curl -L -o vozes\pt_BR-faber-medium.onnx.json %BASE%/pt_BR-faber-medium.onnx.json

where ollama >nul 2>nul && ollama pull llama3.2:3b

echo.
echo Pronto. Agora de dois cliques em iniciar.bat
pause
exit /b 0

:erro
echo Algo falhou na instalacao. Copie a mensagem acima e mande para o Claude.
pause
exit /b 1
