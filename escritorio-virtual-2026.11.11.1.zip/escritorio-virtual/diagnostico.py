"""Diagnóstico do Escritório Dark: testa a internet que o escritório usa e grava diagnostico.txt.

Como usar: dê dois cliques em diagnostico.bat (ou rode `python diagnostico.py`) e me mande o texto
que aparecer na tela (ou o arquivo diagnostico.txt). Não mostra senha nem token.
"""
from __future__ import annotations

import base64
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
UA = {"User-Agent": "EscritorioDark/1.1 (+https://github.com/cauamotta2709-lgtm/escdark; diagnostico) python-urllib"}
SAIDA: list[str] = []


def dizer(txt: str = "") -> None:
    print(txt, flush=True)
    SAIDA.append(txt)


def chamar(url: str, corpo: dict | None = None, token: str = "", timeout: int = 90):
    cab = dict(UA)
    if token:
        cab["Authorization"] = f"Bearer {token}"
    dados = None
    if corpo is not None:
        dados = json.dumps(corpo).encode()
        cab["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=dados, headers=cab)
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.headers.get("Content-Type", ""), r.read(), time.time() - t0
    except urllib.error.HTTPError as e:
        return e.code, e.headers.get("Content-Type", ""), e.read(), time.time() - t0
    except Exception as e:  # sem internet, DNS, etc.
        return 0, "", str(e).encode(), time.time() - t0


def resumo(status: int, corpo: bytes, n: int = 300) -> str:
    return f"HTTP {status} | " + corpo[:n].decode("utf-8", "replace").replace("\n", " ")


def main() -> int:
    dizer(f"Escritório Dark — diagnóstico {time.strftime('%Y-%m-%d %H:%M:%S')} (Python {sys.version.split()[0]})")
    versao = (RAIZ / "versao.txt").read_text().strip() if (RAIZ / "versao.txt").exists() else "(sem versao.txt)"
    dizer(f"versão instalada: {versao}")
    log = RAIZ / "atualizacao.log"
    if log.exists():
        dizer("últimas linhas de atualizacao.log:")
        for linha in log.read_text(encoding="utf-8", errors="replace").splitlines()[-4:]:
            dizer("  " + linha[:220])

    dizer("\n1) Atualizador (GitHub)")
    cfg = json.loads((RAIZ / "config.json").read_text(encoding="utf-8-sig"))
    fonte = cfg.get("fonte_atualizacao") or ""
    st, _, c, _ = chamar(fonte) if fonte else (0, "", b"fonte_atualizacao vazia", 0)
    dizer("   manifesto: " + resumo(st, c, 200))

    dizer("\n2) Cloudflare Workers AI")
    arq = RAIZ / "credenciais" / "cloudflare.json"
    if not arq.exists():
        dizer("   credenciais/cloudflare.json não existe")
    else:
        cred = json.loads(arq.read_text(encoding="utf-8-sig"))
        conta, token = cred["account_id"].strip(), cred["api_token"].strip()
        dizer(f"   account_id com {len(conta)} caracteres, token com {len(token)} caracteres")
        st, _, c, _ = chamar("https://api.cloudflare.com/client/v4/user/tokens/verify", token=token)
        dizer("   verificar token (user): " + resumo(st, c))
        st, _, c, _ = chamar(f"https://api.cloudflare.com/client/v4/accounts/{conta}/tokens/verify", token=token)
        dizer("   verificar token (conta): " + resumo(st, c))
        base = f"https://api.cloudflare.com/client/v4/accounts/{conta}/ai/run/"
        for nome, corpo in (("@cf/black-forest-labs/flux-1-schnell", {"prompt": "a small red apple on a table", "steps": 4}),
                            ("@cf/bytedance/stable-diffusion-xl-lightning",
                             {"prompt": "a small red apple on a table", "width": 512, "height": 512, "num_steps": 4})):
            st, tipo, c, seg = chamar(base + nome, corpo, token)
            if st == 200 and (tipo.startswith("image/") or b'"image"' in c[:200]):
                saida = RAIZ / f"diagnostico-{nome.split('/')[-1]}.jpg"
                saida.write_bytes(c if tipo.startswith("image/") else base64.b64decode(json.loads(c)["result"]["image"]))
                dizer(f"   {nome}: OK em {seg:.1f}s (imagem salva em {saida.name})")
            else:
                dizer(f"   {nome}: " + resumo(st, c))

    dizer("\n3) Wikimedia Commons")
    for n in range(3):
        st, _, c, _ = chamar("https://commons.wikimedia.org/w/api.php?action=query&format=json&meta=siteinfo")
        dizer(f"   pedido {n + 1}: " + resumo(st, c, 80))
        time.sleep(1.5)

    dizer("\n4) Pollinations (só para saber se voltou a ser grátis)")
    st, _, c, _ = chamar("https://image.pollinations.ai/prompt/apple?width=256&height=256&nologo=true")
    dizer("   " + resumo(st, c, 80))

    texto = "\n".join(SAIDA)
    (RAIZ / "diagnostico.txt").write_text(texto, encoding="utf-8")
    dizer("\nPronto: o resultado também está em diagnostico.txt. Copie e cole no chat.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
