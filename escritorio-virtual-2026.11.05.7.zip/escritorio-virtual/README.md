# Escritório virtual dos agentes

Cinco agentes trabalham em linha para produzir vídeos curtos verticais para cinco canais dark,
cada um com o seu nicho, e um painel no navegador mostra cada um trabalhando em tempo real com o
consumo de CPU, RAM, tokens e custo. Tudo usa ferramentas gratuitas e locais, então o custo é R$ 0,00.

| Agente | O que faz | Ferramenta grátis |
|---|---|---|
| Olheiro | Reveza os canais e monta o roteiro de cada um (roteiro checado, quiz ou "Real ou IA?") | bancos dos canais, yt-dlp, Wikipédia, Ollama |
| Carregador | Gera a narração, os efeitos sonoros e busca uma imagem para cada frase | edge-tts (voz neural), Wikimedia Commons, Pollinations, Pexels |
| Legendador | Legendas palavra por palavra no tempo da fala, textos do desafio, descrição e hashtags | tempos do edge-tts, faster-whisper, Ollama |
| Editor | Monta o vídeo 1080x1920 com zoom, trilha e legendas numa única passada | ffmpeg |
| Postador | Publica no YouTube Shorts, TikTok e Instagram Reels | APIs oficiais e gratuitas |

O Editor usa o chip de vídeo do PC quando existe (Intel, NVIDIA ou AMD), que codifica bem mais
rápido que o processador, e nesse caso trabalham dois Editores em paralelo (`"copias": {"editor": "auto"}`).
O Carregador narra todas as frases e busca o fundo ao mesmo tempo.

O Legendador vem antes do Editor de propósito: assim o vídeo é renderizado uma vez só, já
com legenda, o que corta o tempo de render pela metade. Cada agente roda em paralelo na sua
thread, então enquanto o Editor renderiza o vídeo 1, o Carregador já narra o vídeo 2.

## Passo a passo no Windows

1. Baixe `escritorio-virtual.zip` e extraia numa pasta, por exemplo `Documentos\escritorio-virtual`.
2. Dê dois cliques em `instalar.bat`. Ele instala Python, ffmpeg e Ollama pelo winget, as
   bibliotecas grátis e a voz em português. Se ele avisar que instalou programas novos, feche a
   janela e rode `instalar.bat` de novo uma vez.
3. Dê dois cliques em `criar_atalho.bat` (uma vez só). Aparece o atalho "Escritorio Dark" na
   área de trabalho. Abra por ele: o painel abre numa janela própria, como um aplicativo, e você
   vê os agentes trabalhando. Prefere numa aba do navegador? Rode `iniciar.bat --aba` ou abra
   http://127.0.0.1:8765 (se essa porta estiver ocupada por outro programa, ele usa a próxima livre e mostra o endereço na janela preta). Fechar o painel não para os agentes; para parar, feche a janela preta
   minimizada na barra de tarefas. Os vídeos ficam em
   `canais\<canal>\prontos\`, cada um com `video.mp4`, `descricao.txt` (o texto para colar ao
   postar) e `post.json`.
4. Assista aos primeiros vídeos. Cada canal se ajusta no seu `canais\<canal>\canal.json`
   (bloco de notas serve); o `config.json` vale para todos.
5. Para ligar a postagem, siga "Ligar a postagem automática" abaixo. Até lá nada é publicado.
6. Para rodar sozinho todo dia: abra um terminal na pasta e rode
   `python escritorio_virtual.py --sempre`, deixando o PC ligado.

No Linux ou macOS, troque os passos 2 e 3 por `./instalar.sh` e `python3 escritorio_virtual.py`.

Outros comandos úteis:

```
python escritorio_virtual.py --canal quiz-desafios  # só um canal
python escritorio_virtual.py --canal espaco-universo --videos 3
python escritorio_virtual.py --videos 1 --offline   # teste rápido sem internet
python escritorio_virtual.py --porta 9000           # outra porta para o painel
```

Sem nada instalado além do Python e do ffmpeg, ele já funciona: usa um banco local de
referências (`referencias.json`), narração muda no tempo de leitura e fundo animado gerado.
Cada ferramenta instalada liga um recurso a mais sozinha, e se uma falhar (sem internet, por
exemplo) o agente usa a próxima opção em vez de parar. O painel mostra o "motor" de cada agente.

## Os canais (um por nicho)

Cada pasta em `canais\` é um canal. A cada rodada o Olheiro faz um vídeo para cada canal
ativo (`videos_por_canal` no `config.json`). O painel mostra quantos roteiros cada canal ainda
tem e quantos vídeos já saíram.

| Pasta | Nome sugerido | Formato | Voz |
|---|---|---|---|
| `animais-sobrevivencia` | Bicho Extremo | roteiro: "você não duraria 1 dia sendo um..." | Thalita, animada |
| `espaco-universo` | Órbita Curiosa | roteiro: segredos do espaço, tom de documentário | Antonio, grave e lenta |
| `curiosidades-cotidiano` | Ninguém Te Explicou | roteiro: o porquê das coisas do dia a dia | Francisca, de conversa |
| `quiz-desafios` | Miau Quiz | perguntas: quiz de 4 alternativas com o gato apresentador | Francisca, de game show |
| `real-ou-ia` | Olho de Pixel | real_ou_ia: foto real ou de IA? | Antonio, provocador |

Cada pasta tem:

- `PERFIL.md`: nome e @ sugeridos, bio, hashtags, como criar a conta, rótulo de IA e os
  cuidados do nicho. **As contas você cria**: um e-mail por canal e, no TikTok, conta pessoal
  (conta comercial fica fora do Programa de Recompensas).
- `canal.json`: voz, velocidade, tom, estilo das imagens, cores da legenda, hashtags, duração
  mínima. Tudo que estiver aqui vale por cima do `config.json`. `"ativo": false` pausa o canal.
- O banco do canal, escrito e checado à mão: `roteiros.json` (um roteiro por vídeo, com as
  fontes), `perguntas.json` (quiz) ou `quiz_real_ou_ia.json`. Nada se repete até o banco acabar.
  Quando um banco de roteiros acaba, o Olheiro passa a escrever com o Ollama e a Wikipédia.
- `musica\`: as trilhas do canal (o `LEIA-ME.txt` de lá diz o estilo e onde pegar de graça).
- `prontos\`: os vídeos prontos.

Para criar um canal novo, copie uma pasta, troque o nome dela e edite o `canal.json` e o banco.

## Formatos

**roteiro**: narração de 61 a 85 segundos, sem "oi pessoal": a primeira frase já é o gancho, e
as frases são curtas e em "você". A legenda aparece palavra por palavra, com a palavra falada
em destaque, e a imagem troca a cada 2 a 4 segundos com zoom. Cada vídeo usa uma semente fixa
nas imagens de IA, então o personagem mantém a mesma cara do começo ao fim.

**perguntas** (quiz): gancho, 6 perguntas da mais fácil para a mais difícil e um final pedindo
comentário. A voz lê a pergunta, as alternativas A, B, C e D aparecem em cartões, vem a
contagem 3-2-1 em silêncio e a certa fica verde enquanto a voz conta uma curiosidade. O mascote
do canal é gerado uma vez (`mascote_prompt` e `mascote_semente`) e reaparece em todo vídeo.

**real_ou_ia**: inspirado no vídeo de referência (youtube.com/shorts/fMsUjdQztRQ). Cada vídeo
tem um gancho curto, as rodadas do canal (metade real, metade IA) e um final pedindo comentário. Em cada rodada aparece uma imagem com
"#1 REAL OU IA?", a narração pergunta, vem uma contagem 3-2-1 com tique e a resposta
aparece em verde (real) ou vermelho (IA) com um "ding", junto com o fato curioso.

- As coisas do banco (`quiz_real_ou_ia.json`) existem de verdade mas parecem falsas, o que deixa
  o desafio difícil. Dá para adicionar itens novos no mesmo formato. O programa não repete itens
  até usar o banco todo.
- Foto real: Wikimedia Commons (livre, sem chave). O crédito do autor vai sozinho na descrição.
- Foto de IA: Pollinations.ai (grátis, sem conta), no mesmo formato de uma foto comum, para a
  resposta não ficar óbvia. Se uma das fontes falhar, aquela rodada usa a outra e a resposta
  muda junto, então o vídeo nunca mente.
- Sem nenhum canal em `canais\`, o escritório usa o `formatos` do `config.json`
  (`["real_ou_ia"]`, `["curiosidades"]` ou os dois para alternar).

## Monetização e regras das plataformas

- **TikTok, Programa de Recompensas para Criadores**: 10 mil seguidores, 100 mil views em 30
  dias, 18 anos ou mais, conta pessoal e vídeos originais com mais de 1 minuto. Por isso todo
  canal tem `duracao_minima_s: 61`: se a narração ficar curta, o Carregador estica as pausas
  entre as frases até passar de 61 segundos. Vídeo só de fotos ou só de texto não conta.
- **YouTube, Programa de Parcerias**: 1.000 inscritos e 10 milhões de views no Shorts em 90
  dias para receber dos anúncios. Com 500 inscritos e 3 milhões de views já libera Super
  Thanks e membros.
- **Conteúdo repetitivo**: o YouTube não paga canal com "conteúdo em massa" ou "em template".
  Os bancos variam a estrutura, o gancho e o desfecho de cada vídeo; mantenha essa variedade
  ao acrescentar roteiros.
- **Rótulo de IA**: obrigatório só quando a cena parece real. Os canais de desenho e pintura
  não precisam; o `real-ou-ia` tem `"rotulo_ia": true` e precisa sempre (no TikTok, "Conteúdo
  gerado por IA"; no YouTube, "Conteúdo alterado ou sintético"). Quando o escritório posta
  sozinho, ele marca isso pelo `rotulo_ia`; ao postar à mão, o `post.json` lembra.

## Ajustes (`config.json`)

- `formatos`, `quiz_rodadas`, `quiz_pausa_s`: formato dos vídeos, número de rodadas e o tempo
  da contagem para quem assiste pensar.
- `nichos`: os temas que o Olheiro pesquisa, em rodízio (um por vídeo). `nicho` vale quando a lista está vazia.
- `fonte_fatos`: com `wikipedia`, cada roteiro usa fatos de um artigo da Wikipédia, e o link vai
  em `post.json` (campo `fonte`) para você conferir. Isso evita espalhar informação errada.
- `videos_por_canal`: quantos vídeos cada canal ganha por rodada (`videos_por_rodada` vale
  quando não há canais).
- `duracao_minima_s`, `pausa_frases_s`, `musica_volume`: duração mínima, pausa entre frases e
  volume da trilha (0.12 = 12%). Cada canal pode ter os seus.
- `voz`: `auto` usa o edge-tts (vozes neurais da Microsoft, naturais, grátis, precisa de internet)
  e, se ele falhar, o Piper (offline). `voz_edge` escolhe a voz: pt-BR-AntonioNeural (padrão,
  masculina), pt-BR-FranciscaNeural ou pt-BR-ThalitaMultilingualNeural. `voz_edge_velocidade`
  (ex.: `+10%`) e `voz_edge_tom` (ex.: `-2Hz` deixa mais grave) ajustam o jeito de falar.
  `piper_modelo` escolhe a voz offline do Piper (baixe outras em huggingface.co/rhasspy/piper-voices para a pasta `vozes`).
- `postar_de_verdade`: começa em `false`. Nesse modo nada é publicado, só empacotado.
- `resolucao`, `preset`: qualidade e velocidade do render.
- Música: cada canal usa a pasta `canais\<canal>\musica\` e, se ela estiver vazia, a
  `musica\` geral. Só faixas livres para uso comercial (Pixabay Música, Biblioteca de áudio do
  YouTube sem atribuição obrigatória). Faixa que pede crédito: um `.txt` de mesmo nome com o
  crédito na primeira linha, e ele vai sozinho para a descrição. A trilha fica baixa, abaixa
  mais quando a voz fala e o áudio final sai no volume padrão das plataformas (-14 LUFS).
- Imagens que combinam com cada frase: o Olheiro escolhe uma busca para cada frase e o
  Carregador procura um clipe nesta ordem:
  1. Pasta `clipes\`: seus próprios vídeos, como os feitos à mão com créditos grátis de sites de IA.
     O nome do arquivo diz o assunto (`polvo-nadando.mp4`, `coracao.mp4`). Clipes cujo nome
     combina com a frase vêm primeiro.
  2. Pexels: chave grátis em pexels.com/api, depois `setx PEXELS_API_KEY sua_chave`.
  3. Pixabay: chave grátis em pixabay.com/api/docs, depois `setx PIXABAY_API_KEY sua_chave`.
  4. Wikimedia Commons: fotos livres, sem chave. O crédito vai sozinho na descrição do post.
     Foto com licença não comercial (NC) ou sem derivações (ND) é pulada, porque o vídeo é monetizado.
  5. Se nada acima achar, a cena usa um vídeo da pasta `fundos\` na tela inteira, sem som,
     um pouco escurecido, com a legenda e os cartões por cima. Ponha na `fundos\` vídeos verticais
     sem logo de outro app, de preferência seus ou de banco grátis (Pexels, Pixabay): vídeo de
     outro criador pode derrubar a monetização. Para desligar: `"video_sem_imagem": false` no
     config.json (aí volta o fundo degradê gerado).
     A leitura é automática: todo vídeo salvo em `fundos\` ou solto na pasta principal entra no
     sorteio do próximo vídeo, e a vinheta final do TikTok ou do CapCut é cortada sozinha.
  Pexels e Pixabay liberam uso comercial sem dar crédito e têm vídeo em movimento, então
  deixam os vídeos de curiosidades melhores. Depois do `setx`, abra o programa de novo.

## Ligar a postagem automática

Cada plataforma exige uma autorização feita por você uma vez por conta. Os arquivos ficam em
`credenciais\` e nunca devem ser compartilhados. Cada canal posta na própria conta, com os
arquivos dele em `credenciais\<pasta do canal>\` (por exemplo
`credenciais\quiz-desafios\tiktok.json`). Canal sem essa pasta fica "sem credenciais" e não
posta, para nunca publicar na conta de outro canal.

**YouTube Shorts** (o mais simples, recomendo começar por ele)
1. Em console.cloud.google.com, crie um projeto e ative a "YouTube Data API v3".
2. Em "Tela de permissão OAuth", escolha Externo, adicione os e-mails dos canais como usuários
   de teste e, depois de testar, clique em "Publicar app" (Em produção). Para uso próprio não
   precisa de verificação do Google; aparece só um aviso de app não verificado. Sem publicar,
   o Google derruba a autorização a cada 7 dias.
3. Em "Credenciais", crie um "ID do cliente OAuth" do tipo "App para computador" e baixe o JSON.
4. Salve como `credenciais\client_secret.json` e rode `python autorizar_youtube.py <pasta do canal>`
   (por exemplo `python autorizar_youtube.py espaco-universo`). O navegador abre, você entra na
   conta daquele canal, aceita, e ele cria `credenciais\espaco-universo\youtube_token.json`.
   A cota grátis dá cerca de 6 envios por dia.

**TikTok**: crie um app em developers.tiktok.com com o produto "Content Posting API", autorize
a conta do canal e salve em `credenciais\<canal>\tiktok.json`:
`{"client_key": "...", "client_secret": "...", "access_token": "...", "refresh_token": "..."}`.
O access token vale 24 horas; com o refresh token (que vale um ano) o Postador renova sozinho.
Até o TikTok aprovar o app numa auditoria, os vídeos saem como privados (`tiktok_privacidade`
em `config.json`).

**Instagram Reels**: precisa de conta profissional ligada a uma página do Facebook e de um app
em developers.facebook.com. Salve `{"ig_user_id": "...", "token": "..."}` em
`credenciais\<canal>\instagram.json`.

Depois mude `postar_de_verdade` para `true` em `config.json` (ou só no `canal.json` de um canal,
para ligar um de cada vez). Em `plataformas`, deixe só as que você já configurou.

**Atalho pelo Postiz** (opcional e pago): o Postiz (postiz.com) já tem os apps aprovados nas
redes, então publica em público sem você passar pela auditoria do TikTok. O plano de nuvem é
pago (tem teste grátis de 7 dias); instalar o Postiz no próprio PC é grátis, mas aí ele usa os
seus apps e cai na mesma auditoria. Para usar: conecte as contas de todos os canais no Postiz,
crie a chave da API (Configurações > Public API), salve `{"api_key": "..."}` em
`credenciais\postiz.json`, mude `"postador": "postiz"` no `config.json` e, no `canal.json` de
cada canal, diga qual conta é dele:
`"postiz_contas": {"tiktok": "<id>", "youtube": "<id>", "instagram": "<id>"}`.

## Imagens de IA no Cloudflare e cópia para postar pelo celular

- **Cloudflare Workers AI** (grátis, cerca de 150 imagens por dia): o Pollinations passou a
  responder 402 em 31/10. Crie uma conta grátis em dash.cloudflare.com, anote o "Account ID" e
  crie um token de API com a permissão "Workers AI". Salve `{"account_id": "...", "api_token": "..."}`
  em `credenciais\cloudflare.json`. Com o arquivo, o Carregador tenta o Cloudflare primeiro e cai
  no Pollinations se falhar; sem o arquivo, tudo segue como antes.
- **`pasta_para_postar`** (no `config.json` ou no `canal.json`): caminho de uma pasta sincronizada,
  por exemplo `G:\Meu Drive\Para postar` (Google Drive para desktop). Cada vídeo pronto é copiado
  para `<pasta>\<canal>\<id>\` com `video.mp4` e `descricao.txt`, para abrir no celular e postar.
  Vazio = desligado. Para o OneDrive não lotar, o ideal é essa pasta ficar fora dele.

## Atualização automática

Toda vez que você abre o Escritório Dark (`iniciar.bat` ou o atalho), o `atualizar.py` roda antes.
Ele só age se `fonte_atualizacao` (no `config.json`) tiver o endereço de um `manifesto.json`
(`{"versao": ..., "zip": ..., "sha256": ...}`) e a versão for diferente da do `versao.txt`.
Ele guarda um backup em `backup-auto\`, troca só o código e acrescenta as chaves novas do
`config.json`/`canal.json` sem apagar as suas. Nunca mexe em `credenciais\`, `saida\`,
`prontos\`, `usados` e bancos de roteiros. Se o código novo não compilar, volta sozinho para o
anterior. Sem internet ou sem fonte, abre normalmente. Tudo fica em `atualizacao.log`; para
desligar: `"atualizar_sozinho": false`. Para publicar uma versão nova: `python
empacotar_atualizacao.py 2026.11.06.1 "o que mudou" https://endereco-base`.

## Estrutura

```
escritorio_virtual.py     liga tudo
instalar.bat, iniciar.bat, criar_atalho.bat  atalhos para Windows
autorizar_youtube.py      autoriza o envio para um canal do YouTube (uma vez por canal)
escritorio/nucleo.py      agentes em threads, filas e medição de consumo
escritorio/servidor.py    painel ao vivo (SSE, só biblioteca padrão)
escritorio/agentes/       os cinco agentes
escritorio/canais.py      os canais de canais/ e os bancos de roteiros
escritorio/quiz.py        roteiro do desafio "Real ou IA?"
escritorio/perguntas.py   roteiro do quiz de 4 alternativas
canais/<canal>/           um canal por nicho (PERFIL.md, canal.json, banco, musica, prontos)
quiz_real_ou_ia.json      banco geral do desafio (sem canais)
painel/index.html         o escritório em 3D (three.js em painel/vendor, funciona sem internet)
painel/classico.html      o painel antigo, mais leve: http://127.0.0.1:8765/classico
escritorio/painel_dados.py  vídeos prontos, canais e uso do PC para o painel (/extras)
```

## Diagnóstico da internet (diagnostico.bat)

Se as imagens de IA, as fotos da Commons ou a atualização falharem, dê dois cliques em `diagnostico.bat`.
Ele testa o GitHub (atualização), o Cloudflare (token e geração de uma imagem), a Wikimedia Commons e o
Pollinations, e grava o resultado em `diagnostico.txt` (sem mostrar token). Cole o texto no chat.
O Pollinations só é usado se `usar_pollinations` for `true` no `config.json` (hoje ele cobra, então fica desligado).

## Biblioteca de vídeos e limpeza automática

No painel, a **Biblioteca de vídeos** lista todos os vídeos prontos (miniatura, canal, tamanho, data), com filtros
"a publicar" / "já publicados" e por canal. Em cada vídeo há "Assistir e copiar" (player, título e descrição) e o
botão **Marcar já publicado** (e **Desfazer**, que volta para "a publicar"). O estado fica em `saida/biblioteca.json`
(a pasta `saida/` a atualização nunca mexe).

`escritorio/limpeza.py` roda ao abrir o escritório (e a cada rodada diária com `--sempre`):
- vídeo "já publicado" é apagado do PC `dias_apos_publicar` dias (padrão 3) depois da marcação, inclusive a cópia da
  `pasta_para_postar`; o painel mostra "apaga em N dias";
- vídeo "a publicar" nunca é apagado por idade;
- proteção de espaço `limite_gb` (15, 0 = sem limite): se passar, adianta a remoção dos já publicados, do mais antigo;
  se só sobrarem "a publicar", não apaga nada e o painel avisa;
- com `postar_de_verdade`, vídeo publicado pela API conta como "já publicado" sozinho;
- só mexe em pastas de vídeo (id de 8 letras/números) em `canais/<canal>/prontos/`, `saida/prontos/` e na pasta para
  postar; nunca em roteiros, bancos, credenciais ou configurações. Tudo que sai fica em `saida/limpeza.log`.

## Botão de pausar a produção

No topo do painel, **Pausar produção / Retomar produção** funciona com o sistema aberto: cada agente termina o vídeo
que já está fazendo e não pega outro (o Olheiro para de criar roteiros). O painel e o telão mostram PRODUZINDO ou
PAUSADA, e os agentes ociosos passeiam pela sala. A escolha fica em `saida/producao.json`: se você fechar e abrir de
novo, continua pausado até apertar Retomar. O botão só aceita pedidos feitos pela própria página em 127.0.0.1.

## Imagens: tela dividida só como último recurso

Cada cena tenta, em ordem: IA (Cloudflare) com o pedido da cena, IA com um pedido mais simples (o assunto do vídeo),
foto da Commons, clipes e, se ainda faltar, reaproveita a imagem da cena mais próxima do mesmo vídeo. A tela dividida
com o vídeo de `fundos/` só aparece se nenhuma cena do vídeo conseguiu imagem.

## Referências de cultura pop, transição suave e áudio

- **Referências (filmes, séries, memes, jogos e assuntos virais):** o agente **Referências** (`escritorio/agentes/referencias.py`, usa `escritorio/cultura.py` e
  `escritorio/referencias_cultura.json`, ~50 entradas) procura uma obra ou assunto viral que combine com o roteiro
  e insere UMA frase citando o nome e um fato verdadeiro, por exemplo "Quem viu Interestelar lembra: perto de um
  buraco negro, o tempo passa mais devagar". A legenda acompanha a fala e a descrição ganha "Referência citada".
  Nunca usa trechos, pôsteres, capturas nem imagens originais (evita bloqueio e strike): a imagem da frase é
  genérica, de IA ou da Commons, sem o nome da obra no pedido. Desligue com `referencias_filmes: false`; a mesma obra
  só repete depois de `referencias_filmes_pausa` vídeos. Para acrescentar referências, edite o JSON (`chaves` = palavras
  do roteiro que ativam a referência).
- **Transição:** as cenas se dissolvem em vez de cortar seco (`transicao_s`, 0.2 s; 0 = corte seco), com 30 quadros por
  segundo fixos. No quiz o corte seco continua.
- **Áudio:** o som a cada troca de imagem (whoosh) ficou mais baixo e suave (`efeito_transicao_volume`, 0.10; 0 desliga,
  ou `efeito_transicao: false`), e as frases da narração são unidas com micro-fade para não haver estalo na emenda.
