"""Servidor do painel ao vivo: http://127.0.0.1:8765 (só biblioteca padrão do Python).

  /            painel 3D (painel/index.html)
  /classico    painel antigo, mais leve (painel/classico.html)
  /estado      foto do estado dos agentes (JSON)
  /eventos     estado ao vivo (Server-Sent Events)
  /extras      vídeos prontos, canais, uso do PC e versão (JSON, veja painel_dados.py)
  /video/<canal>/<id>   o video.mp4 de um vídeo pronto, para assistir no painel
  /vendor/<arquivo>     bibliotecas do painel (three.js), para funcionar sem internet
  /producao             GET: {"pausado": bool}; POST {"pausado": true|false}: pausa ou retoma a produção
"""
from __future__ import annotations

import json
import queue
import re
import socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from urllib.parse import unquote, urlsplit

from . import painel_dados
from .nucleo import RAIZ, Telemetria

PAINEL = RAIZ / "painel"
TIPOS = {".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
         ".txt": "text/plain; charset=utf-8", ".png": "image/png", ".svg": "image/svg+xml"}


def iniciar(tele: Telemetria, porta: int = 8765) -> ThreadingHTTPServer:
    class Painel(BaseHTTPRequestHandler):
        def log_message(self, *a):  # silencia o log de acesso
            pass

        def _enviar(self, corpo: bytes, tipo: str, cache: str = "no-cache") -> None:
            self.send_response(200)
            self.send_header("Content-Type", tipo)
            self.send_header("Content-Length", str(len(corpo)))
            self.send_header("Cache-Control", cache)
            self.end_headers()
            self.wfile.write(corpo)

        def _pagina(self, nome: str) -> None:
            topo = (b'<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">'
                    b'<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">')
            self._enviar(topo + (PAINEL / nome).read_bytes(), "text/html; charset=utf-8")

        def _video(self, canal: str, vid: str) -> None:
            """Envia o vídeo em pedaços (Range), para o player poder pular para qualquer ponto."""
            pasta = painel_dados.pasta_video(canal, vid)
            if pasta is None:
                self.send_error(404)
                return
            arq = pasta / "video.mp4"
            tamanho = arq.stat().st_size
            ini, fim = 0, tamanho - 1
            faixa = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range", ""))
            if faixa and (faixa[1] or faixa[2]):
                if faixa[1]:
                    ini, fim = int(faixa[1]), int(faixa[2]) if faixa[2] else tamanho - 1
                else:  # "bytes=-500": os últimos 500 bytes
                    ini = max(0, tamanho - int(faixa[2]))
                fim = min(fim, tamanho - 1)
                if ini > fim:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{tamanho}")
                    self.end_headers()
                    return
                self.send_response(206)
                self.send_header("Content-Range", f"bytes {ini}-{fim}/{tamanho}")
            else:
                self.send_response(200)
            self.send_header("Content-Type", "video/mp4")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(fim - ini + 1))
            self.end_headers()
            try:
                with open(arq, "rb") as f:
                    f.seek(ini)
                    falta = fim - ini + 1
                    while falta > 0:
                        bloco = f.read(min(256 * 1024, falta))
                        if not bloco:
                            break
                        self.wfile.write(bloco)
                        falta -= len(bloco)
            except ConnectionError:  # o player cancelou o pedaço (normal ao pular no vídeo)
                pass

        def _local(self) -> bool:
            """Só aceita mudar a produção de uma página aberta neste mesmo endereço (barra sites de fora)."""
            host = (self.headers.get("Host") or "").split(":")[0]
            origem = self.headers.get("Origin")
            ok_origem = origem is None or (urlsplit(origem).hostname or "") in ("127.0.0.1", "localhost")
            return host in ("127.0.0.1", "localhost") and ok_origem and self.headers.get("X-Escritorio") == "1"

        def do_POST(self):
            rota = urlsplit(self.path).path
            if rota not in ("/producao", "/biblioteca"):
                self.send_error(404)
                return
            if not self._local():
                self.send_error(403)
                return
            try:
                n = min(int(self.headers.get("Content-Length") or 0), 1024)
                corpo = json.loads(self.rfile.read(n) or b"{}")
                if rota == "/producao":
                    pausado = bool(corpo["pausado"])
                else:
                    canal, vid, est = str(corpo["canal"]), str(corpo["id"]), str(corpo["estado"])
                    if est not in ("publicado", "a_publicar"):
                        raise ValueError
            except (ValueError, KeyError, TypeError):
                self.send_error(400)
                return
            if rota == "/producao":
                self._enviar(json.dumps({"pausado": tele.definir_pausa(pausado)}).encode(), "application/json")
                return
            marca = painel_dados.marcar(canal, vid, est)
            if marca is None:
                self.send_error(404)
                return
            self._enviar(json.dumps({"canal": canal, "id": vid, **marca}).encode(), "application/json")

        def do_GET(self):
            caminho = unquote(urlsplit(self.path).path)
            if caminho in ("/", "/index.html"):
                self._pagina("index.html")
            elif caminho in ("/classico", "/classico.html"):
                self._pagina("classico.html")
            elif caminho == "/estado":
                self._enviar(json.dumps(tele.instantaneo()).encode(), "application/json")
            elif caminho == "/producao":
                self._enviar(json.dumps({"pausado": tele.pausado}).encode(), "application/json")
            elif caminho == "/extras":
                try:
                    dados = painel_dados.extras()
                except Exception as e:  # o painel continua funcionando mesmo sem os extras
                    dados = {"erro": str(e)[:200]}
                self._enviar(json.dumps(dados, ensure_ascii=False).encode(), "application/json; charset=utf-8")
            elif m := re.fullmatch(r"/video/([^/]+)/([^/]+)", caminho):
                self._video(m[1], m[2])
            elif m := re.fullmatch(r"/vendor/([\w.-]+)", caminho):
                arq = PAINEL / "vendor" / m[1]
                if ".." in m[1] or not arq.is_file():
                    self.send_error(404)
                else:
                    self._enviar(arq.read_bytes(), TIPOS.get(arq.suffix, "application/octet-stream"),
                                 "max-age=86400")
            elif caminho == "/eventos":
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-cache")
                self.end_headers()
                q = tele.ouvir()
                try:
                    self.wfile.write(f"data: {json.dumps({'tipo': 'tudo', 'dados': tele.instantaneo()})}\n\n".encode())
                    while True:
                        try:
                            ev = q.get(timeout=15)
                            self.wfile.write(f"data: {json.dumps(ev)}\n\n".encode())
                        except queue.Empty:
                            self.wfile.write(b": ping\n\n")
                        self.wfile.flush()
                except ConnectionError:  # navegador fechou ou recarregou (no Windows, WinError 10053)
                    pass
                finally:
                    tele.parar_de_ouvir(q)
            else:
                self.send_error(404)

    class Exclusivo(ThreadingHTTPServer):
        # sem isso, no Windows o servidor "divide" a porta com outro programa que já a usa
        # (um jogo, por exemplo) e o navegador acaba abrindo o outro programa
        allow_reuse_address = False

        def server_bind(self) -> None:
            if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
            super().server_bind()

    for tentativa in range(porta, porta + 20):  # porta ocupada: tenta a próxima
        try:
            srv = Exclusivo(("127.0.0.1", tentativa), Painel)
            break
        except OSError:
            continue
    else:
        raise OSError(f"nenhuma porta livre entre {porta} e {porta + 19}")
    srv.daemon_threads = True
    Thread(target=srv.serve_forever, daemon=True).start()
    return srv
