"""Dados extras do painel: vídeos prontos no disco, canais, uso do PC e versão.

Só lê arquivos; nunca muda nada. O painel pede /extras a cada poucos segundos, então o
resultado fica guardado por 4 s para várias janelas abertas não lerem o disco à toa.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sys
import threading
import time
from pathlib import Path

from . import biblioteca, canais, limpeza
from .nucleo import RAIZ, psutil

NOME_OK = re.compile(r"^[\w.-]{1,80}$")  # pasta de canal ou id de vídeo (sem barras nem "..")
_trava = threading.Lock()
_cache: dict = {"t": 0.0, "dados": None}
_cpu_antes: list = []


def _cpu_windows() -> float | None:
    """CPU total em % pelo GetSystemTimes do Windows (quando o psutil não está instalado)."""
    import ctypes
    from ctypes import wintypes
    ocioso, nucleo, usuario = wintypes.FILETIME(), wintypes.FILETIME(), wintypes.FILETIME()
    if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(ocioso), ctypes.byref(nucleo),
                                                 ctypes.byref(usuario)):
        return None
    val = lambda f: (f.dwHighDateTime << 32) | f.dwLowDateTime  # noqa: E731
    agora = (val(ocioso), val(nucleo) + val(usuario))  # o tempo de núcleo já inclui o ocioso
    return _delta(agora)


def _cpu_linux() -> float | None:
    try:
        campos = [int(x) for x in Path("/proc/stat").read_text().split("\n", 1)[0].split()[1:]]
    except (OSError, ValueError):
        return None
    return _delta((campos[3] + campos[4], sum(campos)))


def _delta(agora: tuple[int, int]) -> float | None:
    antes = _cpu_antes[0] if _cpu_antes else None
    _cpu_antes[:] = [agora]
    if not antes or agora[1] <= antes[1]:
        return None
    return round(100 * (1 - (agora[0] - antes[0]) / (agora[1] - antes[1])), 1)


def _memoria() -> tuple[float, float] | None:
    """(% de RAM em uso, total em GB)."""
    if psutil:
        m = psutil.virtual_memory()
        return m.percent, round(m.total / 2**30, 1)
    if os.name == "nt":
        import ctypes

        class Estado(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
        e = Estado()
        e.dwLength = ctypes.sizeof(Estado)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(e)):
            return float(e.dwMemoryLoad), round(e.ullTotalPhys / 2**30, 1)
        return None
    try:
        info = {l.split(":")[0]: int(l.split()[1]) for l in Path("/proc/meminfo").read_text().splitlines()}
        return round(100 * (1 - info["MemAvailable"] / info["MemTotal"]), 1), round(info["MemTotal"] / 2**20, 1)
    except (OSError, KeyError, ValueError, IndexError):
        return None


def sistema() -> dict:
    cpu = None
    try:
        if psutil:
            cpu = psutil.cpu_percent(interval=None)
        elif os.name == "nt":
            cpu = _cpu_windows()
        else:
            cpu = _cpu_linux()
    except Exception:
        pass
    mem = None
    try:
        mem = _memoria()
    except Exception:
        pass
    try:
        disco = shutil.disk_usage(RAIZ)
        livre, total = round(disco.free / 2**30, 1), round(disco.total / 2**30, 1)
    except OSError:
        livre = total = None
    return {"cpu": cpu, "ram": mem[0] if mem else None, "ram_total_gb": mem[1] if mem else None,
            "disco_livre_gb": livre, "disco_total_gb": total, "nucleos": os.cpu_count(),
            "psutil": bool(psutil)}


def situacao(postagens: dict) -> str:
    """Resumo das postagens de um vídeo: publicado, para_postar ou erro."""
    valores = [str(v) for v in (postagens or {}).values()]
    if any(not v.startswith(("pronto", "falhou", "sem credenciais")) for v in valores):
        return "publicado"  # link do YouTube, publish_id do TikTok, id do Instagram ou do Postiz
    if any(v.startswith(("falhou", "sem credenciais")) for v in valores):
        return "erro"
    return "para_postar"


def _ler_json(arq: Path) -> dict:
    try:
        return json.loads(arq.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return {}


def pasta_video(canal: str, vid: str) -> Path | None:
    """Pasta de um vídeo pronto, só se os nomes forem simples (o servidor usa isso para o player)."""
    if not (NOME_OK.match(canal) and NOME_OK.match(vid)) or ".." in canal or ".." in vid:
        return None
    base = RAIZ / "saida" / "prontos" if canal == "geral" else canais.pasta(canal) / "prontos"
    p = base / vid
    return p if (p / "video.mp4").is_file() else None


def _limpeza(cfg: dict, videos: list) -> dict:
    """Espaço e prazo da biblioteca, para o painel."""
    try:
        r = limpeza.resumo(cfg)
    except Exception:
        r = {}
    r["mb_listados"] = round(sum(v.get("mb") or 0 for v in videos), 1)
    return r


def _coletar() -> dict:
    try:
        cfg = json.loads((RAIZ / "config.json").read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        cfg = {}
    lista_canais, videos = [], []
    marcas, dias, agora = biblioteca.ler(), biblioteca.dias(cfg), time.time()
    fontes = [(c["pasta"], c) for c in canais.carregar()]
    if (RAIZ / "saida" / "prontos").is_dir():
        fontes.append(("geral", {"nome": "Sem canal", "nicho": ""}))
    for pasta, canal in fontes:
        prontos = RAIZ / "saida" / "prontos" if pasta == "geral" else canais.pasta(pasta) / "prontos"
        total = aguardando = 0
        ultimo = None
        for p in prontos.iterdir() if prontos.is_dir() else []:
            if not (p / "video.mp4").is_file():
                continue
            meta = _ler_json(p / "post.json")
            criado = (p / "video.mp4").stat().st_mtime
            estado = situacao(meta.get("postagens") or {})
            est, quando = biblioteca.estado_de(marcas, pasta, p.name, estado == "publicado",
                                               (p / "post.json").stat().st_mtime if (p / "post.json").is_file() else criado)
            apaga_em = quando + dias * 86400 if est == "publicado" and quando else None
            total += 1
            aguardando += est == "a_publicar"
            ultimo = max(ultimo or 0, criado)
            videos.append({"canal": pasta, "canal_nome": canal.get("nome", pasta), "id": p.name,
                           "titulo": meta.get("titulo") or p.name, "duracao_s": meta.get("duracao_s"),
                           "mb": round((p / "video.mp4").stat().st_size / 2**20, 1), "criado_em": criado,
                           "situacao": estado, "estado": est, "publicado_em": quando, "apaga_em": apaga_em,
                           "dias_restantes": None if apaga_em is None else max(0, round((apaga_em - agora) / 86400, 1)),
                           "postagens": meta.get("postagens") or {},
                           "rotulo_ia": bool(meta.get("rotulo_ia")), "descricao": meta.get("descricao", "")})
        banco = None
        if pasta != "geral":
            try:
                banco = canais.restantes(pasta, canais.mesclar(cfg, canal))
            except Exception:
                banco = None
        lista_canais.append({"pasta": pasta, "nome": canal.get("nome", pasta), "nicho": canal.get("nicho", ""),
                             "formatos": canal.get("formatos") or cfg.get("formatos") or [],
                             "plataformas": canal.get("plataformas") or cfg.get("plataformas") or [],
                             "total": total, "aguardando": aguardando, "ultimo_em": ultimo, "banco": banco})
    videos.sort(key=lambda v: v["criado_em"], reverse=True)
    versao = RAIZ / "versao.txt"
    return {
        "agora": time.time(),
        "versao": versao.read_text(encoding="utf-8").strip() if versao.exists() else "",
        "sistema": sistema(),
        "canais": lista_canais,
        "videos": videos[:300],
        "limpeza": _limpeza(cfg, videos),
        "biblioteca": len(videos),
        "para_postar": sum(c["aguardando"] for c in lista_canais),
        "modo": {"postar_de_verdade": bool(cfg.get("postar_de_verdade")),
                 "postador": cfg.get("postador", "oficial"),
                 "pasta_para_postar": bool(str(cfg.get("pasta_para_postar") or "").strip()),
                 "videos_por_rodada": cfg.get("videos_por_rodada")},
        "plataforma": sys.platform,
    }


def extras() -> dict:
    with _trava:
        if _cache["dados"] is None or time.time() - _cache["t"] > 4:
            _cache["dados"], _cache["t"] = _coletar(), time.time()
        return _cache["dados"]


def marcar(canal: str, vid: str, estado: str) -> dict | None:
    """Marca um vídeo existente como publicado / a_publicar. None se o vídeo não existe."""
    if pasta_video(canal, vid) is None:
        return None
    marca = biblioteca.marcar(canal, vid, estado)
    with _trava:
        _cache["dados"] = None  # o próximo /extras já mostra a mudança
    return marca
