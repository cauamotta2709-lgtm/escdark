# Ninguém Te Explicou (curiosidades gerais)

Pasta do canal: `canais/curiosidades-cotidiano`. Tudo o que o escritório faz para este canal sai em `prontos/`.
Desde 13/11/2026 o canal fala de **curiosidades gerais**, não só do dia a dia: é um dos dois canais em que o
escritório concentra a produção (o outro é o quiz de anime, `canais/quiz-anime`). O perfil antigo ficou
em `PERFIL-antes-2026-11-13.md`.

## Nome e perfil
- **Nome:** Ninguém Te Explicou (o mesmo de antes; quem já segue não estranha). Alternativa: O Porquê das Coisas.
- **Bio:** As curiosidades que ninguém te contou: ciência, corpo, bichos, espaço e história, em 1 minuto.
- **Hashtags do nicho:** #curiosidades #fatoscuriosos #vocesabia #ciencia + as do assunto do vídeo

## O que o canal fala
Curiosidades gerais com fato conferido: o porquê das coisas do dia a dia, corpo humano, animais incríveis,
espaço e planeta Terra, história curiosa e ciência. Os roteiros que ainda não viraram vídeo nos canais de
bichos e de espaço (agora parados) também entram aqui, revezando com os do próprio canal.

## Como é o vídeo
- **Formato:** roteiro narrado de 61 a 80 s: o gancho logo de cara, a explicação em passos, o detalhe que
  ninguém conta e um fecho de impacto.
- **Voz:** Francisca (pt-BR-FranciscaNeural), +12%.
- **Visual:** uma imagem por frase (troca a cada 2 a 4 s, em dissolução, sem som de troca), ilustração
  vetorial chapada feita por IA. Cenas marcadas com `"video"` no roteiro usam vídeo real do Pexels ou do
  Pixabay (sem marca d'água) quando você tem a chave grátis em `credenciais/chaves.json`.
- Todo vídeo passa de 1 minuto, que é o mínimo para o Programa de Recompensas do TikTok.

## Séries para variar
- Ninguém te explicou: por que...
- Seu corpo faz isso e você nem percebe
- O bicho que...
- E se...? (espaço e planeta)
- A história real de...

## Rótulo de IA
Não é obrigatório: as imagens são claramente ilustração. Vídeo real de banco também não precisa.

## Cuidados
- Muitas "origens" que circulam na internet são falsas. Quando a explicação é só hipótese, o roteiro diz "a hipótese mais aceita é".
- Nada de dica de saúde, remédio ou "truque" perigoso.
- Não mostre logo nem nome de marca, e não use "Você Sabia" no nome do canal (é marca de outro canal).
- Nunca poste o mesmo vídeo em dois canais seus (o escritório não usa aqui roteiro que já virou vídeo nos canais antigos).
