# Desafio Otaku

Pasta do canal: `canais/quiz-anime`. Tudo o que o escritório faz para este canal sai em `prontos/`.
Criado em 13/11/2026, quando o escritório passou a focar em dois canais de vídeo curto: este e o
de curiosidades gerais (`canais/curiosidades-cotidiano`).

## Nome e perfil
- **Nome sugerido:** Desafio Otaku. Alternativas: Quiz Otaku BR, Otaku Raiz Quiz.
- **@ sugerido:** @desafiootaku (confira se está livre no TikTok, no YouTube e no Instagram antes de criar).
- **Bio:** Quiz de anime todo dia. Só otaku de verdade gabarita. Comenta seu placar!
- **Hashtags do nicho:** #quizanime #anime #otaku #animebrasil #desafio + a do anime do vídeo (#naruto, #onepiece...)

## Como é o vídeo
- **Formato:** quiz de 5 ou 6 perguntas (sorteado a cada vídeo), da fácil para a difícil, de 65 a 90 s.
  Metade dos vídeos é de um anime só ("Só quem viu Naruto acerta"), a outra metade é misturada.
- **Cada pergunta:** a voz lê a pergunta, as 4 alternativas aparecem em cartões, vem a contagem 3-2-1
  em silêncio e a certa fica verde com uma curiosidade.
- **Imagens:** 3 por pergunta, entrando em fade, sem som de troca. Duas são ilustrações de IA no estilo
  anime (cenários e objetos originais, sem desenhar o personagem da resposta) e a do meio é foto ou vídeo
  da web sem marca d'água (Pexels, Pixabay, Commons, Openverse) quando acha uma que combine. Na resposta,
  uma imagem maior.
- **Voz:** Thalita Multilíngue (pt-BR-ThalitaMultilingualNeural), +10%. Ela pronuncia melhor os nomes em japonês.
- **Mascote:** uma raposinha branca de fone e microfone, original do canal (criada uma vez por IA e guardada
  em `mascote.jpg`; pode trocar por um desenho seu com o mesmo nome).
- **Final:** pede o placar e o anime do próximo quiz nos comentários (comentário puxa alcance).

## Direitos autorais (importante)
- Nada de print, cena, abertura ou música de anime: tudo isso tem dono, e as distribuidoras (Crunchyroll,
  Toei, Aniplex) derrubam vídeo e dão strike. Também cai na regra de "conteúdo reutilizado" do YouTube.
- Por isso as imagens são cenários originais no clima de cada anime, e a música é livre (Kevin MacLeod, CC BY).
- Nome de anime e de personagem pode ser citado na pergunta (é fato, não cópia).

## Banco de perguntas
- Fica em `escritorio/bancos/quiz-anime/perguntas.json` (vem nas atualizações) e você pode pôr as suas em
  `canais/quiz-anime/perguntas.json`, no mesmo formato. Cada pergunta tem `serie` (o anime) e `hashtag`.
- Não repete pergunta até usar todas. O painel mostra quantos vídeos o banco ainda rende.

## Como criar a conta (você faz isso, o escritório não cria contas)
1. Crie um e-mail só para este canal. Não misture com os outros canais.
2. **TikTok:** conta **pessoal** (conta comercial fica fora do Programa de Recompensas). Nome, bio e foto.
3. **YouTube:** mesmo e-mail, crie o canal com o nome acima e marque **"Não, não é conteúdo para crianças"**.
4. **Instagram:** crie a conta e mude para **conta profissional > Criador de conteúdo**.
5. Para postar sozinho depois: `python autorizar_youtube.py quiz-anime` e os tokens do TikTok e do Instagram
   em `credenciais/quiz-anime/`.

## Rótulo de IA
Não é obrigatório: as imagens são claramente ilustração/animação.

## Cuidados
- Sem spoiler pesado de final de temporada nas perguntas fáceis.
- Nunca poste o mesmo vídeo em dois canais seus.
- Até as plataformas aprovarem a postagem automática, poste à mão: o vídeo, a capa e o texto pronto
  (`descricao.txt`) ficam em `prontos/`.
