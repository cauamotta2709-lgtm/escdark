"""Música de fundo grátis para os canais que ainda não têm nenhuma trilha.

Na primeira vez que o escritório abre com internet, baixa algumas faixas de Kevin MacLeod
(incompetech.com) para canais/<canal>/musica/, escolhidas pelo clima de cada canal. A licença é
Creative Commons BY 4.0: pode usar em vídeo monetizado, desde que o crédito apareça. Por isso cada
faixa ganha um .txt de mesmo nome com o crédito, e o Editor põe esse crédito na descrição do vídeo
(descricao.txt e post.json) sozinho.

Não mexe em nada se o canal já tiver música (a sua escolha vale) ou se a pasta musica/ geral tiver
alguma faixa. Para desligar: "baixar_musica": false no config.json. Para trocar as faixas de um
canal: apague as dele em canais/<canal>/musica/ e ponha as suas, ou liste outras em
"trilhas_incompetech" no canal.json (o título exato do site).
"""
from __future__ import annotations

import os
import time
import urllib.parse
import urllib.request
from pathlib import Path

from . import canais
from .nucleo import RAIZ

BASE = "https://incompetech.com/music/royalty-free/mp3-royaltyfree/"
CAB = {"User-Agent": "EscritorioDark/1.0 (musica de fundo com credito CC BY)"}
AUDIO = {".mp3", ".m4a", ".ogg", ".wav", ".opus"}

# título no site -> arquivo (conferidos no catálogo do incompetech em 11/2026)
TRILHAS = {
    # bichos: curioso e engraçado, pizzicato e marimba
    "animais-sobrevivencia": [("Investigations", "Investigations.mp3"), ("Quirky Dog", "Quirky Dog.mp3"),
                              ("Merry Go", "Merry Go.mp3"), ("Comic Plodding", "Comic Plodding.mp3")],
    # espaço: calmo, misterioso e grandioso
    "espaco-universo": [("Dreams Become Real", "Dreams Become Real.mp3"),
                        ("Floating Cities", "Floating Cities.mp3"), ("Frost Waltz", "Frost Waltz.mp3"),
                        ("Mesmerize", "Mesmerize.mp3")],
    # dia a dia: leve e animado
    "curiosidades-cotidiano": [("Wallpaper", "Wallpaper.mp3"), ("Cheery Monday", "Cheery Monday.mp3"),
                               ("Easy Lemon", "Easy Lemon.mp3"), ("Off to Osaka", "Off to Osaka.mp3")],
    # quiz: clima de programa de auditório
    "quiz-desafios": [("Pixel Peeker Polka - faster", "Pixel Peeker Polka - faster.mp3"),
                      ("Local Forecast - Elevator", "Local Forecast - Elevator.mp3"),
                      ("Bit Shift", "Bit Shift.mp3"), ("Hyperfun", "Hyperfun.mp3")],
    # quiz de anime: animado, de game show e chiptune (os mesmos títulos conferidos do quiz antigo)
    "quiz-anime": [("Hyperfun", "Hyperfun.mp3"), ("Pixel Peeker Polka - faster", "Pixel Peeker Polka - faster.mp3"),
                   ("Bit Shift", "Bit Shift.mp3"), ("Local Forecast - Elevator", "Local Forecast - Elevator.mp3")],
    # Real ou IA: suspense leve e eletrônico
    "real-ou-ia": [("Hidden Agenda", "Hidden Agenda.mp3"), ("Kool Kats", "Kool Kats.mp3"),
                   ("Digital Lemonade", "Digital Lemonade.mp3"), ("Cipher", "Cipher2.mp3")],
}
PADRAO = [("Carefree", "Carefree.mp3"), ("Investigations", "Investigations.mp3")]


def credito(titulo: str) -> str:
    return (f'"{titulo}" Kevin MacLeod (incompetech.com) · Licensed under Creative Commons: '
            "By Attribution 4.0 · https://creativecommons.org/licenses/by/4.0/")


def tem_audio(pasta: Path) -> bool:
    return pasta.exists() and any(a.suffix.lower() in AUDIO for a in pasta.iterdir())


def baixar(arquivo: str, destino: Path) -> None:
    url = BASE + urllib.parse.quote(arquivo)
    with urllib.request.urlopen(urllib.request.Request(url, headers=CAB), timeout=60) as r:
        dados = r.read()
    mp3 = dados[:3] == b"ID3" or (len(dados) > 2 and dados[0] == 0xFF and dados[1] & 0xE0 == 0xE0)
    if len(dados) < 100_000 or not mp3:
        raise ValueError("o arquivo baixado não parece um mp3")
    temp = destino.with_name(destino.name + ".baixando")
    temp.write_bytes(dados)
    os.replace(temp, destino)


def preparar(cfg: dict, log=print) -> int:
    """Baixa as trilhas que faltam; devolve quantas baixou. Nunca levanta erro."""
    if cfg.get("baixar_musica", True) is False or cfg.get("offline"):
        return 0
    if tem_audio(RAIZ / "musica"):
        return 0  # você já escolheu uma trilha geral: ela vale para todos os canais sem música
    baixadas, canais_ok, falhas = 0, [], []
    for canal in canais.carregar():
        pasta = canais.pasta(canal["pasta"]) / "musica"
        if tem_audio(pasta):
            continue
        lista = [(str(t), str(t) + ".mp3") if isinstance(t, str) else tuple(t)
                 for t in canal.get("trilhas_incompetech") or []] or TRILHAS.get(canal["pasta"], PADRAO)
        pasta.mkdir(parents=True, exist_ok=True)
        novas = 0
        for titulo, arquivo in lista[:int(cfg.get("trilhas_por_canal", 4))]:
            destino = pasta / arquivo
            try:
                baixar(arquivo, destino)
                destino.with_suffix(".txt").write_text(credito(titulo) + "\n", encoding="utf-8")
                novas += 1
            except Exception as e:
                falhas.append(f"{titulo} ({str(e)[:50]})")
            time.sleep(1)  # sem pressa: não sobrecarrega o site de quem cede a música
        if novas:
            baixadas += novas
            canais_ok.append(canal["pasta"])
    if baixadas:
        log(f"música: baixei {baixadas} trilha(s) livres para {', '.join(canais_ok)}; "
            "o crédito do autor vai sozinho na descrição")
    if falhas:
        log(f"música: não consegui baixar {len(falhas)} trilha(s): {'; '.join(falhas[:3])}", "aviso")
    return baixadas
