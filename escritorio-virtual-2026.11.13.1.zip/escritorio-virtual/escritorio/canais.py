"""Vários canais dark, um por nicho. Cada canal é uma pasta em canais/ com:

  canal.json           nome, nicho, formatos, voz, estilo das imagens, hashtags... (sobrepõe o config.json)
  PERFIL.md            nome sugerido, bio, como criar a conta, rótulo de IA e cuidados do nicho
  roteiros.json        banco de roteiros checados (formato "roteiro", um por vídeo)
  perguntas.json       banco do quiz de 4 alternativas (formato "perguntas")
  quiz_real_ou_ia.json banco de fotos do desafio Real ou IA (formato "real_ou_ia")
  musica/              trilhas livres de direitos só deste canal (opcional; senão usa a musica/ geral)
  prontos/             os vídeos prontos deste canal, cada um com video.mp4, post.json e descricao.txt

Os bancos também crescem pelas atualizações: escritorio/bancos/<canal>/ traz roteiros, perguntas e
fotos novas no mesmo formato, e eles entram depois dos itens do próprio canal, sem repetir (o que
você escreveu no canal vale primeiro, e os usados continuam valendo).

O Olheiro reveza os canais ativos, então cada rodada produz vídeos para todos eles.

Canais ativos: com "canais_ativos" no config.json (lista de pastas), só esses produzem; os outros
ficam parados, com tudo guardado (bancos, usados, vídeos prontos e credenciais), e voltam a produzir
quando você põe o nome da pasta de volta na lista. Sem a lista, vale o "ativo" de cada canal.json.
Um canal novo que chega pela atualização vem em escritorio/canais_novos/<pasta>/ e é copiado para
canais/ quando ele está na lista de ativos e a pasta ainda não existe.

Um canal de roteiro pode puxar roteiros de outros canais com "bancos_extras": ["outra-pasta", ...]
no canal.json. Entram só os roteiros que o outro canal ainda não usou, revezando com os do próprio
canal (um de cada banco), para o feed não ficar repetitivo.
"""
from __future__ import annotations

import json
import os
import shutil
import threading
import time
from pathlib import Path

from .nucleo import RAIZ, Job

PASTA = RAIZ / "canais"
EXTRAS = Path(__file__).resolve().parent / "bancos"  # itens novos que chegam pelas atualizações
MODELOS = Path(__file__).resolve().parent / "canais_novos"  # canais novos que chegam pelas atualizações
_trava = threading.Lock()
_reservados: dict[str, set] = {}  # escolhidos nesta execução e ainda não empacotados


def ler(arq: Path):
    """JSON escrito pelo usuário (aceita o BOM que o Bloco de Notas às vezes põe)."""
    return json.loads(arq.read_text(encoding="utf-8-sig"))


def usados(arq: Path) -> set:
    """O que já virou vídeo. Só a falta do arquivo conta como "nada usado": se ele existir e não
    der para ler (OneDrive segurando, JSON cortado), o erro sobe e o histórico não é apagado."""
    try:
        return set(ler(arq))
    except FileNotFoundError:
        return set()


def indisponiveis(arq: Path) -> set:
    """Usados mais os reservados por vídeos desta execução que ainda estão na linha."""
    with _trava:
        return usados(arq) | _reservados.get(str(arq), set())


def reservar(job: Job, arq: Path, chaves, novo_ciclo: bool = False) -> None:
    """Marca como em uso agora; o arquivo de usados só é gravado quando o vídeo fica pronto,
    para um job que falhe não gastar o roteiro (veja confirmar)."""
    chaves = set(chaves)
    with _trava:
        _reservados.setdefault(str(arq), set()).update(chaves)
    job.arquivos.setdefault("usar", []).append([str(arq), sorted(chaves), novo_ciclo])


def confirmar(job: Job) -> None:
    """Chamado pelo Postador com o pacote pronto: grava os usados de forma atômica."""
    for arq, chaves, novo_ciclo in job.arquivos.get("usar") or []:
        arq = Path(arq)
        with _trava:
            # novo ciclo: o banco inteiro já foi usado, então recomeça só com os deste vídeo
            atual = set(chaves) if novo_ciclo else usados(arq) | set(chaves)
            arq.parent.mkdir(parents=True, exist_ok=True)
            tmp = arq.with_name(arq.name + ".tmp")
            tmp.write_text(json.dumps(sorted(atual), ensure_ascii=False, indent=1), encoding="utf-8")
            for tentativa in range(5):  # no Windows o OneDrive pode segurar o arquivo por um instante
                try:
                    os.replace(tmp, arq)
                    break
                except PermissionError:
                    if tentativa == 4:
                        raise
                    time.sleep(0.5)
            _reservados.get(str(arq), set()).difference_update(chaves)


def ativos_config(cfg: dict | None = None) -> list[str] | None:
    """A lista "canais_ativos" do config.json (None se não existir ou estiver vazia)."""
    if cfg is None:
        try:
            cfg = ler(RAIZ / "config.json")
        except (OSError, ValueError):
            cfg = {}
    lista = cfg.get("canais_ativos")
    if isinstance(lista, str):
        lista = [lista]
    lista = [str(x).strip() for x in lista or [] if str(x).strip()]
    return lista or None


def carregar(somente: str | None = None, todos: bool = False, cfg: dict | None = None) -> list[dict]:
    """Canais ativos, em ordem alfabética. Ativo = está em "canais_ativos" do config.json (quando a
    lista existe) e não tem "ativo": false no canal.json. Com todos=True devolve também os parados,
    cada um com "ativo" True ou False (o painel usa isso para ainda mostrar os vídeos deles)."""
    lista = ativos_config(cfg)
    escolhidos = {x.lower() for x in lista} if lista else None
    canais = []
    for arq in sorted(PASTA.glob("*/canal.json")) if PASTA.exists() else []:
        try:
            canal = ler(arq)
        except ValueError as e:
            print(f"[canais] {arq} tem um erro e foi ignorado: {e}", flush=True)
            continue
        canal["pasta"] = arq.parent.name
        ativo = canal.get("ativo", True) is not False and (
            escolhidos is None or canal["pasta"].lower() in escolhidos)
        if somente and somente.lower() != canal["pasta"].lower():
            continue
        if ativo or todos:
            canal["ativo"] = ativo
            canais.append(canal)
    return canais


def instalar_novos(cfg: dict | None = None, log=print) -> list[str]:
    """Copia para canais/ os canais novos que vieram na atualização (escritorio/canais_novos/<pasta>)
    e estão na lista de ativos. Nunca mexe numa pasta de canal que já existe."""
    lista = ativos_config(cfg) or []
    novos = []
    for modelo in sorted(MODELOS.iterdir()) if MODELOS.is_dir() else []:
        destino = PASTA / modelo.name
        if not (modelo / "canal.json").is_file() or modelo.name not in lista or (destino / "canal.json").exists():
            continue
        try:
            shutil.copytree(modelo, destino, dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            (destino / "prontos").mkdir(exist_ok=True)
            novos.append(modelo.name)
        except OSError as e:
            log(f"[canais] não consegui criar o canal novo {modelo.name}: {e}")
    if novos:
        log(f"[canais] canal novo criado em canais/: {', '.join(novos)}")
    return novos


def focar_curiosidades(log=print) -> bool:
    """Ajuste único da versão 2026.11.13: o canal curiosidades-cotidiano vira o canal de curiosidades
    GERAIS. Troca nicho, nichos e hashtags pelos do modelo (escritorio/canais_novos/curiosidades-cotidiano),
    acrescenta as chaves novas e guarda o PERFIL.md antigo como PERFIL-antes-2026-11-13.md."""
    modelo = MODELOS / "curiosidades-cotidiano"
    destino = PASTA / "curiosidades-cotidiano"
    if not (modelo / "canal.json").is_file() or not (destino / "canal.json").is_file():
        return False
    novo, atual = ler(modelo / "canal.json"), ler(destino / "canal.json")
    for chave in ("nicho", "nichos", "hashtags"):
        if chave in novo:
            atual[chave] = novo[chave]
    for chave, valor in novo.items():
        atual.setdefault(chave, valor)
    tmp = destino / "canal.json.tmp"
    tmp.write_text(json.dumps(atual, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, destino / "canal.json")
    if (modelo / "PERFIL.md").is_file():
        velho = destino / "PERFIL.md"
        if velho.exists() and not (destino / "PERFIL-antes-2026-11-13.md").exists():
            shutil.copyfile(velho, destino / "PERFIL-antes-2026-11-13.md")
        shutil.copyfile(modelo / "PERFIL.md", velho)
    log("[canais] curiosidades-cotidiano agora é o canal de curiosidades gerais")
    return True


def mesclar(cfg: dict, canal: dict) -> dict:
    """Configuração do vídeo: o config.json geral com o que o canal define por cima."""
    junto = dict(cfg)
    junto.update({k: v for k, v in canal.items() if k not in ("descricao_interna",)})
    return junto


def pasta(canal: str) -> Path:
    return PASTA / canal


def banco(dono: Path, nome: str, chave) -> list[dict]:
    """Itens do arquivo `nome` do canal mais os de escritorio/bancos/<canal>/nome, sem repetir a
    chave (o do canal vem primeiro). Um arquivo com erro é pulado com aviso, sem derrubar o outro."""
    pegar = chave if callable(chave) else (lambda item: item.get(chave))
    itens, vistos = [], set()
    for arq in (dono / nome, EXTRAS / dono.name / nome):
        if not arq.exists():
            continue
        try:
            dados = ler(arq)
        except ValueError as e:
            print(f"[canais] {arq} tem um erro e foi ignorado: {e}", flush=True)
            continue
        for item in dados if isinstance(dados, list) else []:
            k = pegar(item) if isinstance(item, dict) else None
            if k and k not in vistos:
                vistos.add(k)
                itens.append(item)
    return itens


def tem_banco(canal: str, nome: str) -> bool:
    return (pasta(canal) / nome).exists() or (EXTRAS / canal / nome).exists()


def config_canal(canal: str) -> dict:
    try:
        return ler(pasta(canal) / "canal.json")
    except (OSError, ValueError):
        return {}


def _chave_roteiro(r: dict):
    return r.get("id") or r.get("titulo")


def roteiros(canal: str) -> list[dict]:
    """Banco de roteiros do canal (com os extras das atualizações); arquivo com erro vale vazio."""
    return [r for r in banco(pasta(canal), "roteiros.json", _chave_roteiro) if r.get("frases")]


def fontes_roteiro(canal: str) -> list[tuple[str, list[dict]]]:
    """Os bancos que o canal usa: o dele e os de "bancos_extras" (de outro canal, sem os roteiros
    que aquele canal já usou). Cada item: (pasta de onde veio, roteiros ainda não usados lá)."""
    fontes = [(canal, roteiros(canal))]
    for outro in config_canal(canal).get("bancos_extras") or []:
        outro = str(outro).strip()
        if not outro or outro == canal or not (pasta(outro).exists() or (EXTRAS / outro).exists()):
            continue
        try:
            fora = usados(pasta(outro) / "usados.json")
        except (OSError, ValueError):
            continue  # sem saber o que o outro canal já postou, não arrisca repetir vídeo
        fontes.append((outro, [r for r in roteiros(outro) if _chave_roteiro(r) not in fora]))
    return fontes


def fila_roteiros(canal: str) -> list[dict]:
    """Todos os roteiros que o canal pode usar, revezando os bancos: um do próprio canal, um de cada
    banco extra, e de novo. Sem repetir a chave."""
    fontes = [lista for _, lista in fontes_roteiro(canal)]
    fila, vistos = [], set()
    for i in range(max((len(f) for f in fontes), default=0)):
        for lista in fontes:
            if i < len(lista):
                k = _chave_roteiro(lista[i])
                if k and k not in vistos:
                    vistos.add(k)
                    fila.append(lista[i])
    return fila


def proximo_roteiro(job: Job, canal: str) -> dict | None:
    """O primeiro roteiro da fila do canal que ainda não virou vídeo (ou None se acabou)."""
    arq = pasta(canal) / "usados.json"
    fora = indisponiveis(arq)
    for roteiro in fila_roteiros(canal):
        chave = _chave_roteiro(roteiro)
        if chave not in fora:
            reservar(job, arq, [chave])
            return roteiro
    return None


def liberar(job: Job) -> None:
    """Job que falhou ou foi reprovado: devolve ao banco o que ele tinha reservado."""
    for arq, chaves, _ in job.arquivos.get("usar") or []:
        with _trava:
            _reservados.get(str(arq), set()).difference_update(chaves)
    job.arquivos["usar"] = []


def por_video(valor, padrao: int = 8) -> int:
    """quiz_perguntas pode ser um número ou uma lista (ex.: [5, 6, 7], sorteado a cada vídeo)."""
    if isinstance(valor, (list, tuple)):
        nums = [int(v) for v in valor if str(v).strip().isdigit()]
        return max(1, round(sum(nums) / len(nums))) if nums else padrao
    try:
        return max(1, int(valor))
    except (TypeError, ValueError):
        return padrao


def restantes(canal: str, cfg: dict | None = None) -> int:
    """Quantos vídeos o banco do canal ainda rende sem repetir item. No roteiro, um item é um
    vídeo; no quiz e no Real ou IA, cada vídeo gasta quiz_perguntas ou quiz_rodadas itens."""
    cfg = cfg or {}
    p = pasta(canal)
    try:
        if tem_banco(canal, "roteiros.json"):
            fora = indisponiveis(p / "usados.json")
            return sum(1 for r in fila_roteiros(canal) if _chave_roteiro(r) not in fora)
        for nome, arq, chave, gasto in (
                ("perguntas.json", "perguntas_usadas.json", "id", por_video(cfg.get("quiz_perguntas", 8))),
                ("quiz_real_ou_ia.json", "quiz_usados.json", "foto", por_video(cfg.get("quiz_rodadas", 4), 4))):
            if tem_banco(canal, nome):
                fora = indisponiveis(p / arq)
                livres = sum(1 for i in banco(p, nome, chave) if i.get(chave) not in fora)
                return livres // gasto
    except (OSError, ValueError) as e:
        print(f"[canais] não deu para ler o banco ou os usados de {canal}: {e}", flush=True)
    return 0
