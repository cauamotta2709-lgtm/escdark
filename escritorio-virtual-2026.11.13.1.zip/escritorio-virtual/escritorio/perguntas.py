"""Formato "perguntas": quiz de conhecimentos gerais com 4 alternativas na tela.

Cada vídeo tem um gancho, N perguntas da mais fácil para a mais difícil e um final pedindo
comentário. Em cada pergunta a voz lê a pergunta, as alternativas A, B, C e D aparecem em
cartões, vem a contagem 3-2-1 em silêncio (o momento em que quem assiste pensa) e depois a
alternativa certa fica verde e a voz conta uma curiosidade. O banco fica no perguntas.json do
canal e não repete pergunta até usar todas.

Cada canal pode ter o seu jeito (canal.json): "quiz_ganchos", "quiz_finais", "quiz_titulos",
"quiz_legendas" e "quiz_tema" (com {n} = número de perguntas e {serie} = tema do vídeo), e
"quiz_perguntas" pode ser uma lista ([5, 6]) para cada vídeo ter um tamanho. Com "quiz_tematico"
(0 a 1), essa fração dos vídeos usa perguntas de uma "serie" só (ex.: só Naruto), quando o banco
tem perguntas livres suficientes dela; títulos e ganchos temáticos ficam em "quiz_ganchos_serie"
e "quiz_titulos_serie". Assim os vídeos não saem todos iguais (o YouTube não paga conteúdo
repetitivo, feito em série por molde).
"""
from __future__ import annotations

import json
import random
from pathlib import Path

from . import canais
from .nucleo import Job

LETRAS = "ABCD"
GANCHOS = [
    "Duvido você acertar as {n}. A última é quase impossível!",
    "Só gênio acerta as {n}. Valendo!",
    "{n} perguntas, e a última derruba quase todo mundo.",
    "Se você acertar as {n}, pode se gabar nos comentários.",
]
ULTIMA = ["Última, e a mais difícil: ", "Agora a mais difícil: ", "Pergunta final: "]
FINAIS = [
    "Quantas você acertou? Comenta aí!",
    "Comenta quantas você acertou, sem mentir!",
]


def banco(pasta: Path) -> list[dict]:
    """Perguntas do canal mais as que chegam pelas atualizações (escritorio/bancos/<canal>/)."""
    return canais.banco(pasta, "perguntas.json", "id")


def escolher(job: Job, pasta: Path, qtd: int, serie: str | None = None) -> list[dict]:
    """Perguntas ainda não usadas, misturando fáceis, médias e difíceis, em ordem crescente.
    Quando sobram menos que o necessário, usa as que sobraram e completa com outras.
    Com `serie`, só perguntas daquela série (o Olheiro só pede quando há livres suficientes)."""
    todas = [p for p in banco(pasta) if len(p.get("alternativas", [])) == 4]
    if serie:
        todas = [p for p in todas if p.get("serie") == serie]
    arq = pasta / "perguntas_usadas.json"
    fora = canais.indisponiveis(arq)
    livres = [p for p in todas if p["id"] not in fora]
    random.shuffle(livres)
    novo_ciclo = len(livres) < qtd
    # cerca de 40% fáceis, 35% médias e o resto difíceis; completa com o que sobrar
    cotas = {1: round(qtd * 0.4), 2: round(qtd * 0.35)}
    cotas[3] = qtd - cotas[1] - cotas[2]
    itens = []
    if novo_ciclo:
        resto = [p for p in todas if p not in livres]
        extra = random.sample(resto, min(qtd - len(livres), len(resto)))
        itens = livres + extra
    else:
        for nivel, cota in cotas.items():
            itens += [p for p in livres if p.get("dificuldade", 2) == nivel][:cota]
        itens += [p for p in livres if p not in itens][:qtd - len(itens)]
        extra = itens
    itens.sort(key=lambda p: p.get("dificuldade", 2))
    canais.reservar(job, arq, [p["id"] for p in extra], novo_ciclo=novo_ciclo)
    return itens


def series_livres(pasta: Path, qtd: int) -> list[str]:
    """Séries que ainda têm pelo menos `qtd` perguntas sem usar (dá para um vídeo temático)."""
    fora = canais.indisponiveis(pasta / "perguntas_usadas.json")
    conta: dict[str, int] = {}
    for p in banco(pasta):
        if p.get("serie") and p["id"] not in fora and len(p.get("alternativas", [])) == 4:
            conta[p["serie"]] = conta.get(p["serie"], 0) + 1
    return [s for s, n in conta.items() if n >= qtd]


def _formatar(modelos, padrao: list[str], **campos) -> str:
    lista = [m for m in (modelos or []) if isinstance(m, str) and m.strip()] or padrao
    texto = random.choice(lista)
    for k, v in campos.items():
        texto = texto.replace("{" + k + "}", str(v))
    return texto


def montar(job: Job, pasta: Path, qtd=8, cfg: dict | None = None) -> Job:
    cfg = cfg or {}
    if isinstance(qtd, (list, tuple)):  # tamanho sorteado a cada vídeo
        qtd = random.choice([int(x) for x in qtd if str(x).strip().isdigit()] or [8])
    qtd = max(1, int(qtd))
    serie = None
    if random.random() < float(cfg.get("quiz_tematico", 0) or 0):
        opcoes = series_livres(pasta, qtd)
        serie = random.choice(opcoes) if opcoes else None
    itens = [dict(p) for p in escolher(job, pasta, qtd, serie)]
    if serie and len(itens) < qtd:  # não deveria acontecer; se acontecer, vídeo misto
        canais.liberar(job)
        serie, itens = None, [dict(p) for p in escolher(job, pasta, qtd)]
    n_itens = len(itens)
    if serie:
        gancho = _formatar(cfg.get("quiz_ganchos_serie"), GANCHOS, n=n_itens, serie=serie)
    else:
        gancho = _formatar(cfg.get("quiz_ganchos"), GANCHOS, n=n_itens, serie="")
    roteiro = [gancho]
    for n, item in enumerate(itens, 1):
        item["letra"] = LETRAS[item["correta"]]
        item["q"] = len(roteiro)
        prefixo = random.choice(cfg.get("quiz_ultima") or ULTIMA) if n == len(itens) and n > 1 else ""
        roteiro.append(prefixo + item["pergunta"])
        item["r"] = len(roteiro)
        roteiro.append(f"Letra {item['letra']}! {item['curiosidade']}")
    roteiro.append(_formatar(cfg.get("quiz_finais"), FINAIS, n=n_itens, serie=serie or ""))
    job.tema = _formatar([cfg["quiz_tema"]] if cfg.get("quiz_tema") else None, ["quiz de conhecimentos gerais"],
                         serie=serie or "", n=n_itens)
    job.roteiro = roteiro
    job.buscas = []
    job.arquivos["perguntas"] = itens
    # título, legenda e hashtags variados (o Legendador usa estes; sem nada no canal.json, ficam os de sempre)
    titulo = _formatar(cfg.get("quiz_titulos_serie") if serie else cfg.get("quiz_titulos"),
                       ["QUIZ: DUVIDO VOCÊ ACERTAR AS {n}!"], n=n_itens, serie=serie or "",
                       SERIE=(serie or "").upper())
    legenda = _formatar(cfg.get("quiz_legendas"), ["Quantas você acertou? Comenta aí 👇 Sem pesquisar!"],
                        n=n_itens, serie=serie or "")
    tags = list(dict.fromkeys([*(str(h).lstrip("#") for h in cfg.get("quiz_hashtags") or []),
                               *(str(i.get("hashtag", "")).lstrip("#") for i in itens if i.get("hashtag"))]))
    job.arquivos["quiz_meta"] = {"titulo": titulo, "legenda": legenda, "serie": serie,
                                 "hashtags": [t for t in tags if t] or ["quiz", "desafio", "conhecimentosgerais", "perguntas"]}
    return job
