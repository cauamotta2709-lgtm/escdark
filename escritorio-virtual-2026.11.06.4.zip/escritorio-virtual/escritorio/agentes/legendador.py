"""Agente 3: cria as legendas na tela (estilo viral, 2 a 3 palavras por vez) e o texto do post.

Os tempos de cada palavra vêm, do mais exato para o menos: da própria voz (o edge-tts informa
quando fala cada palavra), do faster-whisper ou da duração de cada frase narrada. No formato
"Real ou IA?" também escreve na tela a pergunta, a contagem 3-2-1 e a resposta. Gera um .ass que o Editor queima
no vídeo na mesma passada de render, então o vídeo só é codificado uma vez.
"""
from __future__ import annotations

import importlib.util
import json
import re

from .. import llm
from ..nucleo import Agente, Job

# legenda de baixo: o canal pode mudar fonte, tamanho, cores e altura em "legenda" no canal.json
# (cores no formato do .ass, &HBBGGRR: amarelo &H0000F6FF, branco &H00FFFFFF, verde &H0050E650)
# "altura" é a distância da base da tela: os 22% de baixo ficam atrás do título e dos botões
# do TikTok e do YouTube, então a legenda fica acima disso
LEGENDA = {"fonte": "Arial", "tamanho": 92, "cor": "&H00FFFFFF", "destaque": "&H0000F6FF",
           "altura": None, "karaoke": True, "maiusculas": True, "max_caracteres": 15}

CABECALHO = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Viral,{fonte},{tamanho},{cor},&H00FFFFFF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,7,3,2,60,60,{altura},1
Style: Topo,Arial,100,&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,8,3,8,60,60,210,1
Style: Real,Arial,150,&H0050E650,&H00FFFFFF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,9,4,8,60,60,190,1
Style: IA,Arial,150,&H004040FF,&H00FFFFFF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,9,4,8,60,60,190,1
Style: Contagem,Arial,200,&H0000F6FF,&H00FFFFFF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,10,4,2,60,60,470,1
Style: Pergunta,Arial,62,&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,5,2,8,70,70,0,1
Style: Cartao,Arial,54,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,3,0,4,0,0,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


def ts(s: float) -> str:
    h, s = divmod(s, 3600)
    m, s = divmod(s, 60)
    return f"{int(h)}:{int(m):02d}:{s:05.2f}"


class Legendador(Agente):
    chave = "legendador"
    nome = "Legendador"
    cargo = "Cria legendas animadas, descrição e hashtags"
    emoji = "💬"

    def __init__(self, *a, **kw) -> None:
        super().__init__(*a, **kw)
        self.whisper = importlib.util.find_spec("faster_whisper") is not None
        self.usa_llm = llm.disponivel(self.cfg.get("modelo", "llama3.2:3b"))
        self.motor = "+".join(["whisper" if self.whisper else "tempos-tts",
                               "ollama" if self.usa_llm else "regras"])
        self.tele.atualizar(self.chave, motor=self.motor)

    def palavras_com_tempo(self, job: Job) -> list[tuple[float, float, str]]:
        if job.arquivos.get("palavras"):  # tempos exatos que a própria voz informou
            return job.arquivos["palavras"]
        if self.whisper and job.arquivos.get("voz") != "muda":
            try:
                from faster_whisper import WhisperModel
                self.tarefa(f"transcrevendo a narração com whisper (job {job.id})")
                if not hasattr(self, "modelo"):  # carrega uma vez só
                    self.modelo = WhisperModel(self.cfg.get("whisper_modelo", "base"), compute_type="int8",
                                               cpu_threads=int(self.cfg.get("whisper_threads", 2)))
                with self.vaga_pesada("transcrever"):
                    segs, _ = self.modelo.transcribe(job.arquivos["narracao"], language="pt",
                                                     word_timestamps=True)
                    palavras = [(w.start, w.end, w.word.strip()) for s in segs for w in s.words]
                if palavras:
                    return palavras
            except Exception as e:
                self.log(f"whisper indisponível ({e}), usando tempos da narração", "aviso")
                self.whisper = False
        saida, t = [], 0.0
        pausas = job.arquivos.get("pausas") or [0.0] * len(job.roteiro)
        for frase, dur, pausa in zip(job.roteiro, job.arquivos["tempos"], pausas):
            ps = frase.split()
            passo = max(dur - pausa, 0.3) / max(len(ps), 1)  # a pausa no fim da frase fica sem legenda
            for i, p in enumerate(ps):
                saida.append((t + i * passo, t + (i + 1) * passo, p))
            t += dur
        return saida

    @staticmethod
    def blocos(palavras: list, job: Job, n: int, max_car: int = 15) -> list[list]:
        """Grupos de até n palavras que nunca juntam duas frases (senão a legenda da pergunta
        mostraria o começo da resposta durante a contagem). No desafio, o "É real!"/"É IA!" do
        começo da resposta já aparece grande no topo, então sai da legenda de baixo."""
        fins, t = [], 0.0
        for d in job.arquivos.get("tempos") or []:
            t += d
            fins.append(t)
        rodadas = job.arquivos.get("quiz") or job.arquivos.get("perguntas") or []
        respostas = {i["r"] for i in rodadas}
        # no quiz de perguntas a pergunta já está escrita no cartão: não repete embaixo
        omitir = {i["q"] for i in job.arquivos.get("perguntas") or []}
        grupos: list[list] = []
        frase_atual, posicao = -1, 0
        for p in palavras:
            frase = next((i for i, f in enumerate(fins) if p[0] < f), len(fins))
            posicao = posicao + 1 if frase == frase_atual else 0
            nova_frase = frase != frase_atual
            frase_atual = frase
            if frase in omitir or (frase in respostas and posicao < 2):
                continue
            # grupo novo: frase nova, n palavras ou texto que passaria de uma linha
            largura = sum(len(x[2]) + 1 for x in grupos[-1]) + len(p[2]) if grupos else 0
            if not grupos or nova_frase or grupos[-1][-1][3] != frase or len(grupos[-1]) >= n \
                    or largura > max_car:
                grupos.append([])
            grupos[-1].append((*p[:3], frase))
        # cada bloco fica na tela até o próximo começar (sem piscar entre palavras da mesma frase)
        for atual, prox in zip(grupos, grupos[1:]):
            if prox[0][3] == atual[-1][3] and prox[0][0] - atual[-1][1] < 0.6:
                atual[-1] = (atual[-1][0], prox[0][0], *atual[-1][2:])
        return grupos

    def textos_quiz(self, job: Job) -> list[str]:
        """Pergunta, contagem 3-2-1 durante a pausa e a resposta em verde (real) ou vermelho (IA)."""
        inicios, t = [], 0.0
        for d in job.arquivos["tempos"]:
            inicios.append(t)
            t += d

        def fim(i: int) -> float:
            return inicios[i] + job.arquivos["tempos"][i]

        linhas = [f"Dialogue: 1,{ts(0)},{ts(fim(0))},Topo,,0,0,0,,REAL OU IA?"]
        pausas = job.arquivos.get("pausas") or [0.0] * len(job.roteiro)
        for n, item in enumerate(job.arquivos["quiz"], 1):
            q, r = item["q"], item["r"]
            linhas.append(f"Dialogue: 1,{ts(inicios[q])},{ts(fim(q))},Topo,,0,0,0,,#{n}  REAL OU IA?")
            pausa = pausas[q]
            for k in range(3):  # 3, 2, 1 dividindo a pausa
                a = fim(q) - pausa + k * pausa / 3
                linhas.append(f"Dialogue: 2,{ts(a)},{ts(a + pausa / 3)},Contagem,,0,0,0,,"
                              r"{\fscx60\fscy60\t(0,120,\fscx100\fscy100)}" f"{3 - k}")
            estilo, texto = ("Real", "É REAL!") if item["resposta"] == "real" else ("IA", "É IA!")
            linhas.append(f"Dialogue: 1,{ts(inicios[r])},{ts(fim(r))},{estilo},,0,0,0,,"
                          r"{\fscx70\fscy70\t(0,150,\fscx100\fscy100)}" f"{texto}")
        return linhas

    def textos_perguntas(self, job: Job, cfg: dict) -> list[str]:
        """Quiz de perguntas: número da pergunta no topo, a pergunta e as 4 alternativas em
        cartões, a contagem 3-2-1 sobre a imagem e, na resposta, só o cartão certo em verde."""
        inicios, t = [], 0.0
        for d in job.arquivos["tempos"]:
            inicios.append(t)
            t += d
        def fim(i: int) -> float:
            return inicios[i] + job.arquivos["tempos"][i]
        cor = cfg.get("cor_cartao", "&HB1355E&")  # roxo
        certo = cfg.get("cor_certo", "&H53C800&")  # verde

        def caixa(y: int, alt: int, c: str, a: float, b: float) -> str:
            r, w = 22, 900
            forma = (f"m {r} 0 l {w - r} 0 b {w} 0 {w} 0 {w} {r} l {w} {alt - r} b {w} {alt} {w} {alt} "
                     f"{w - r} {alt} l {r} {alt} b 0 {alt} 0 {alt} 0 {alt - r} l 0 {r} b 0 0 0 0 {r} 0")
            return (f"Dialogue: 1,{ts(a)},{ts(b)},Cartao,,0,0,0,,{{\\an7\\pos(90,{y})\\1c{c}"
                    f"\\bord0\\shad0\\p1}}{forma}")

        def limpa(x: str) -> str:
            return str(x).replace("{", "").replace("}", "").replace("\\", "")

        def tamanho(texto: str, maximo: int, largura: int, fator: float = 0.58) -> int:
            """Maior fonte em que o texto cabe numa linha só (fator: largura média da letra)."""
            return max(30, min(maximo, int(largura / (fator * max(len(texto), 1)))))

        def tamanho_pergunta(texto: str) -> int:
            """A pergunta tem 170 px entre a imagem e o 1º cartão: diminui até caber."""
            for fs in (62, 56, 50, 46, 42, 38, 34):
                linhas = -(-len(texto) * 0.56 * fs // 940)  # arredonda para cima
                if linhas * fs * 1.2 <= 170:
                    return fs
            return 34
        itens = job.arquivos["perguntas"]
        pausas = job.arquivos.get("pausas") or [0.0] * len(job.roteiro)
        linhas = [f"Dialogue: 3,{ts(0)},{ts(fim(0))},Topo,,0,0,0,,{len(itens)} PERGUNTAS"]
        for n, item in enumerate(itens, 1):
            q, r = item["q"], item["r"]
            a, b = inicios[q], fim(q)
            linhas.append(f"Dialogue: 3,{ts(a)},{ts(fim(r))},Topo,,0,0,0,,{{\\fs80}}PERGUNTA {n}/{len(itens)}")
            texto = limpa(item["pergunta"])
            linhas.append(f"Dialogue: 2,{ts(a)},{ts(b)},Pergunta,,70,70,0,,"
                          f"{{\\an8\\pos(540,905)\\fs{tamanho_pergunta(texto)}}}{texto}")
            for k, alt in enumerate(item["alternativas"]):
                y = 1085 + k * 100
                linhas.append(caixa(y, 84, cor, a, b))
                texto = f"{'ABCD'[k]}   {limpa(alt)}"  # numa linha só, dentro do cartão
                linhas.append(f"Dialogue: 2,{ts(a)},{ts(b)},Cartao,,130,110,0,,"
                              f"{{\\an4\\pos(130,{y + 42})\\q2\\fs{tamanho(texto, 54, 830)}}}{texto}")
            pausa = pausas[q]
            for k in range(3):  # 3, 2, 1 sobre a imagem, em silêncio
                c = b - pausa + k * pausa / 3
                linhas.append(f"Dialogue: 4,{ts(c)},{ts(c + pausa / 3)},Contagem,,0,0,0,,"
                              r"{\an5\pos(540,590)\fscx60\fscy60\t(0,120,\fscx100\fscy100)}" f"{3 - k}")
            # resposta: só o cartão certo, grande e verde, onde estava a pergunta
            linhas.append(caixa(910, 130, certo, inicios[r], fim(r)))
            texto = f"{item['letra']}   {limpa(item['alternativas'][item['correta']]).upper()}"
            linhas.append(f"Dialogue: 2,{ts(inicios[r])},{ts(fim(r))},Cartao,,130,110,0,,"
                          f"{{\\an4\\pos(130,975)\\q2\\fs{max(22, min(66, int(830 / (0.7 * len(texto)))))}"
                          f"\\fscx70\\fscy70\\t(0,150,\\fscx100\\fscy100)}}{texto}")
        return linhas

    @staticmethod
    def linhas_bloco(bloco: list, leg: dict) -> list[str]:
        """Um bloco de 2 ou 3 palavras. No modo karaokê, a palavra que está sendo falada fica
        na cor de destaque e um pouco maior, como nos shorts de referência."""
        def limpa(p: str) -> str:
            p = p.replace("{", "").replace("}", "").replace("\\", "")
            return p.upper() if leg.get("maiusculas", True) else p
        pop = r"{\fscx80\fscy80\t(0,90,\fscx100\fscy100)}"
        palavras = [limpa(p[2]) for p in bloco]
        if not leg.get("karaoke", True) or len(bloco) == 1:
            cor = "{\\c" + leg["destaque"] + "}"  # bloco inteiro na cor de destaque
            return [f"Dialogue: 0,{ts(bloco[0][0])},{ts(bloco[-1][1])},Viral,,0,0,0,,{pop}{cor}"
                    + " ".join(palavras)]
        linhas = []
        for k, p in enumerate(bloco):
            fim = bloco[k + 1][0] if k + 1 < len(bloco) else bloco[-1][1]
            texto = " ".join(
                ("{\\c" + leg["destaque"] + "\\fscx108\\fscy108}" + w + "{\\c" + leg["cor"]
                 + "\\fscx100\\fscy100}") if j == k else w for j, w in enumerate(palavras))
            linhas.append(f"Dialogue: 0,{ts(p[0])},{ts(max(fim, p[0] + 0.05))},Viral,,0,0,0,,"
                          f"{pop if k == 0 else ''}{texto}")
        return linhas

    def processar(self, job: Job) -> Job:
        cfg = self.conf(job)
        leg = {**LEGENDA, **(cfg.get("legenda") or {})}
        palavras = self.palavras_com_tempo(job)
        self.tarefa(f"montando legendas animadas (job {job.id})")
        linhas, n = [], cfg.get("palavras_por_tela", 3)
        for bloco in self.blocos(palavras, job, n, leg.get("max_caracteres", 15)):
            linhas += self.linhas_bloco(bloco, leg)
        if job.arquivos.get("quiz"):
            linhas += self.textos_quiz(job)
        if job.arquivos.get("perguntas"):
            linhas += self.textos_perguntas(job, cfg)
        ass = job.pasta / "legendas.ass"
        # no Real ou IA a foto fica no meio da tela, então a legenda desce um pouco
        altura = leg["altura"] or (440 if job.arquivos.get("quiz") else 600)
        cabecalho = CABECALHO.replace("{fonte}", str(leg["fonte"])).replace(
            "{tamanho}", str(leg["tamanho"])).replace("{cor}", leg["cor"]).replace(
            "{altura}", str(altura))
        ass.write_text(cabecalho + "\n".join(linhas) + "\n", encoding="utf-8")
        job.arquivos["legendas"] = str(ass)
        self.log(f"{len(linhas)} blocos de legenda criados")

        self.tarefa(f"escrevendo descrição e hashtags (job {job.id})")
        feito = False
        roteiro = job.arquivos.get("roteiro") or {}
        if job.arquivos.get("quiz"):  # o desafio tem título e descrição próprios, do jeito que viraliza
            n = len(job.arquivos["quiz"])
            job.arquivos["titulo"] = f"REAL OU IA? Duvido você acertar as {n}!"
            job.legenda = "Quantas você acertou? Comenta aí 👇 Sem trapacear!"
            job.hashtags = ["realouia", "inteligenciaartificial", "ia", "desafio", "curiosidades",
                            "shorts", "fyp"]
            feito = True
        elif job.arquivos.get("perguntas"):
            n = len(job.arquivos["perguntas"])
            job.arquivos["titulo"] = f"QUIZ: DUVIDO VOCÊ ACERTAR AS {n}!"
            job.legenda = "Quantas você acertou? Comenta aí 👇 Sem pesquisar!"
            job.hashtags = ["quiz", "desafio", "conhecimentosgerais", "perguntas"]
            feito = True
        elif roteiro:  # roteiro do banco do canal: título, legenda e hashtags já vêm escritos
            job.arquivos["titulo"] = roteiro["titulo"]
            job.legenda = roteiro.get("legenda") or f"{job.roteiro[0]} 👇"
            job.hashtags = [str(h).lstrip("#") for h in roteiro.get("hashtags") or []]
            feito = True
        elif not self.usa_llm and llm.disponivel(self.cfg.get("modelo", "llama3.2:3b")):
            self.usa_llm = True
        if self.usa_llm and not feito:
            try:
                texto, tokens = llm.gerar(
                    "Crie a descrição de um vídeo curto viral em português do Brasil. "
                    f"Tema: {job.tema}. Roteiro: {' '.join(job.roteiro)}. Responda em JSON: "
                    "{\"titulo\": str até 70 caracteres, \"legenda\": str até 150 caracteres, "
                    "\"hashtags\": [5 a 8 hashtags sem #]}",
                    self.cfg.get("modelo", "llama3.2:3b"), json_saida=True)
                self.contar_tokens(tokens)
                d = json.loads(texto)
                job.arquivos["titulo"], job.legenda = str(d["titulo"]), str(d["legenda"])
                job.hashtags = [str(h).lstrip("#").replace(" ", "") for h in d["hashtags"]]
                feito = True
            except Exception as e:
                self.log(f"IA local falhou ({str(e)[:60]}); descrição por regras", "aviso")
        if not feito:
            job.arquivos["titulo"] = (job.referencia.get("titulo") or job.tema)[:70]
            job.legenda = f"{job.roteiro[1] if len(job.roteiro) > 1 else job.roteiro[0]} Você sabia? 👇"
            palavras = [re.sub(r"[^\w]", "", p) for p in job.tema.lower().split()]
            base = max(palavras, key=len, default="")  # a palavra mais longa do tema vira hashtag
            job.hashtags = [h for h in [base, "curiosidades", "voce sabia", "fatos", "shorts",
                                        "fyp", "viral"] if h]
            job.hashtags = [h.replace(" ", "") for h in job.hashtags]
        # hashtags fixas do canal entram primeiro; no máximo 8, sem repetir
        vistas: set[str] = set()
        job.hashtags = [h for h in [*(str(x).lstrip("#") for x in cfg.get("hashtags") or []),
                                    *job.hashtags]
                        if h and not (h.lower() in vistas or vistas.add(h.lower()))][:8]
        self.log(f"descrição: {job.legenda[:60]}…")
        return job
