"""Fontes grátis e legais de FOTO para as cenas, em cadeia: se uma falha, esgota a cota ou não tem chave, passa para a próxima.

Ordem padrão (config.json `fontes_imagem`, dá para reordenar ou tirar):
  nasa      NASA Images: sem chave, domínio público; só entra nos canais de espaço (ou com `nasa: true` no canal.json)
  pexels    fotos verticais; chave grátis (credenciais/chaves.json ou PEXELS_API_KEY)
  pixabay   fotos; chave grátis (credenciais/chaves.json ou PIXABAY_API_KEY)
  commons   Wikimedia Commons: sem chave, só licença livre (o Carregador já cuida)
  openverse sem chave: fotos com licença Creative Commons que permite uso comercial e edição (by, by-sa, cc0, pdm)

Leveza: no máximo `pesquisas_simultaneas` (3) pedidos de rede ao mesmo tempo, intervalo mínimo por fonte, tempo
limite curto, fonte lenta ou com erro sai por alguns minutos (disjuntor) e toda foto baixada vai para um cache em
disco (saida/cache_imagens, limite `cache_imagens_mb`) que serve os próximos vídeos sem nenhum pedido de rede.
Toda foto é conferida: o nome/descrição/tags precisam falar do assunto da cena (`exigir`), senão é descartada.
Não usa busca de imagens do Google/Bing: os termos de uso proíbem robôs e quase tudo ali tem dono (risco de strike).
"""
from __future__ import annotations

import hashlib
import json
import random
import re
import shutil
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from .nucleo import RAIZ

UA = {"User-Agent": "EscritorioDark/1.1 (+https://github.com/cauamotta2709-lgtm/escdark; projeto pessoal) python-urllib"}
PADRAO = ["nasa", "pexels", "pixabay", "commons", "openverse"]
_rede = threading.BoundedSemaphore(3)
_ultimo: dict[str, float] = {}
_INTERVALO = {"nasa": 0.4, "pexels": 0.4, "pixabay": 0.6, "openverse": 1.2}
_falhas: dict[str, int] = {}
CACHE = RAIZ / "saida" / "cache_imagens"
_indice: dict | None = None
_parada: dict[str, float] = {}  # fonte -> até quando está fora (cota do dia, chave recusada, instável)
_avisou: set[str] = set()
_cache: dict = {}
_trava = threading.Lock()


def chave(nome: str) -> str:
    """Chave de API: credenciais/chaves.json ({"pexels": "...", "pixabay": "..."}) ou variável de ambiente."""
    import os
    try:
        d = json.loads((RAIZ / "credenciais" / "chaves.json").read_text(encoding="utf-8-sig"))
        if str(d.get(nome, "")).strip():
            return str(d[nome]).strip()
    except (OSError, ValueError):
        pass
    return os.environ.get(f"{nome.upper()}_API_KEY", "").strip()


def configurar(cfg: dict) -> None:
    global _rede
    _rede = threading.BoundedSemaphore(max(1, int(cfg.get("pesquisas_simultaneas", 3))))


def _espaco(fonte: str) -> None:
    """Intervalo mínimo entre dois pedidos à mesma fonte (não sobrecarrega o servidor nem a cota)."""
    with _trava:
        quando = max(time.time(), _ultimo.get(fonte, 0) + _INTERVALO.get(fonte, 0.5))
        _ultimo[fonte] = quando
    time.sleep(max(0.0, quando - time.time()))


def _json(url: str, cabecalho: dict | None = None, timeout: int = 12, fonte: str = "") -> dict:
    with _trava:
        if url in _cache:
            return _cache[url]
    req = urllib.request.Request(url, headers={**UA, **(cabecalho or {})})
    with _rede:
        _espaco(fonte)
        t0 = time.time()
        with urllib.request.urlopen(req, timeout=timeout) as r:
            dados = json.loads(r.read())
    if time.time() - t0 > 8:  # fonte lenta: conta como falha leve
        _falhas[fonte] = _falhas.get(fonte, 0) + 1
    with _trava:
        _cache[url] = dados
    return dados


# ---------- cache em disco ----------
def _carregar_indice() -> dict:
    global _indice
    with _trava:
        if _indice is None:
            try:
                _indice = json.loads((CACHE / "indice.json").read_text(encoding="utf-8"))
            except (OSError, ValueError):
                _indice = {}
        return _indice


def _guardar(cid: str, origem: Path, credito: str, texto: str, limite_mb: float) -> None:
    try:
        CACHE.mkdir(parents=True, exist_ok=True)
        nome = hashlib.md5(cid.encode()).hexdigest()[:16] + ".jpg"
        shutil.copyfile(origem, CACHE / nome)
        ind = _carregar_indice()
        with _trava:
            ind[cid] = {"arq": nome, "credito": credito, "texto": texto[:400], "t": time.time()}
            total = sum((CACHE / v["arq"]).stat().st_size for v in ind.values() if (CACHE / v["arq"]).exists())
            for k in sorted(ind, key=lambda k: ind[k]["t"]):  # estourou o limite: sai o mais antigo
                if total <= limite_mb * 2**20:
                    break
                f = CACHE / ind[k]["arq"]
                total -= f.stat().st_size if f.exists() else 0
                f.unlink(missing_ok=True)
                del ind[k]
            (CACHE / "indice.json").write_text(json.dumps(ind, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def _do_cache(exigir: set[str] | None, usados: set, destino: Path) -> tuple[str, str] | None:
    if not exigir:
        return None
    ind = _carregar_indice()
    with _trava:
        candidatas = [(k, v) for k, v in ind.items() if k not in usados and (CACHE / v["arq"]).exists()
                      and _combina(exigir, v["texto"])]
        if not candidatas:
            return None
        k, v = random.choice(candidatas)
        usados.add(k)
    shutil.copyfile(CACHE / v["arq"], destino)
    return v["credito"], "cache"


def _fora(fonte: str) -> bool:
    return time.time() < _parada.get(fonte, 0)


def _parar(fonte: str, segundos: float, motivo: str, log) -> None:
    _parada[fonte] = time.time() + segundos
    if fonte not in _avisou:
        _avisou.add(fonte)
        log(f"fonte de imagem '{fonte}' fora por enquanto ({motivo}); as cenas passam para a próxima fonte", "aviso")


def _combina(exigir: set[str] | None, *textos: str) -> bool:
    if not exigir:
        return True
    achado = set(re.findall(r"[a-z0-9]+", " ".join(textos).lower()))
    achado |= {p[:5] for p in achado}
    return any(t in achado or t[:5] in achado for t in exigir)


# ---------- cada fonte devolve uma lista de {"id","url","credito","texto"} ----------
def _nasa(q: str, **_) -> list[dict]:
    d = _json("https://images-api.nasa.gov/search?" + urllib.parse.urlencode({"q": q, "media_type": "image", "page_size": 12}), fonte="nasa")
    saida = []
    for it in d.get("collection", {}).get("items", []):
        info = (it.get("data") or [{}])[0]
        links = [x for x in it.get("links", []) if x.get("render") == "image" and x.get("width", 0) >= 600]
        if not links:
            continue
        melhor = max((x for x in links if x.get("width", 0) <= 2200), key=lambda x: x["width"], default=links[0])
        autor = info.get("secondary_creator") or info.get("photographer") or "NASA"
        saida.append({"id": "nasa:" + str(info.get("nasa_id")), "url": melhor["href"],
                      "credito": (autor if "NASA" in autor else f"{autor}/NASA") + " (domínio público), via NASA Images",
                      "texto": f"{info.get('title', '')} {info.get('description', '')} {' '.join(info.get('keywords') or [])}"})
    return saida


def _pexels(q: str, **_) -> list[dict]:
    k = chave("pexels")
    if not k:
        return []
    d = _json("https://api.pexels.com/v1/search?" + urllib.parse.urlencode(
        {"query": q, "orientation": "portrait", "per_page": 15}), {"Authorization": k}, fonte="pexels")
    return [{"id": f"pexels:{p['id']}", "url": p["src"].get("large2x") or p["src"]["original"],
             "credito": f"Foto de {p.get('photographer', 'autor')} no Pexels", "texto": p.get("alt", "")}
            for p in d.get("photos", [])]


def _pixabay(q: str, **_) -> list[dict]:
    k = chave("pixabay")
    if not k:
        return []
    d = _json("https://pixabay.com/api/?" + urllib.parse.urlencode(
        {"key": k, "q": q[:100], "image_type": "photo", "orientation": "vertical", "per_page": 15,
         "safesearch": "true", "min_width": 800}), fonte="pixabay")
    return [{"id": f"pixabay:{h['id']}", "url": h.get("largeImageURL") or h["webformatURL"],
             "credito": f"Foto de {h.get('user', 'autor')} no Pixabay", "texto": h.get("tags", "")}
            for h in d.get("hits", [])]


def _openverse(q: str, **_) -> list[dict]:
    d = _json("https://api.openverse.org/v1/images/?" + urllib.parse.urlencode(
        {"q": q, "license": "by,by-sa,cc0,pdm", "page_size": 15, "mature": "false"}), fonte="openverse")
    saida = []
    for h in d.get("results", []):
        if not h.get("url") or (h.get("width") or 0) < 600:
            continue
        lic = f"{str(h.get('license', '')).upper()} {h.get('license_version') or ''}".strip()
        saida.append({"id": "openverse:" + str(h.get("id")), "url": h["url"],
                      "credito": f"{h.get('creator') or 'autor desconhecido'} ({lic}), via Openverse",
                      "texto": f"{h.get('title', '')} {' '.join(t.get('name', '') for t in h.get('tags') or [])}"})
    return saida


FONTES = {"nasa": _nasa, "pexels": _pexels, "pixabay": _pixabay, "openverse": _openverse}


def buscar(agente, consultas: list[str], exigir: set[str] | None, usados: set, destino: Path, cfg: dict,
           canal: str = "", ja_commons=None) -> tuple[str, str] | None:
    """Percorre as fontes na ordem. Devolve (crédito, nome da fonte) da primeira foto que combina, ou None.
    `ja_commons(consulta)` é a busca da Commons do próprio Carregador (devolve o crédito ou None)."""
    from .agentes.carregador import e_imagem, pegar  # evita import circular na carga
    if cfg.get("offline"):
        return None
    log = agente.log
    limite_mb = float(cfg.get("cache_imagens_mb", 500))
    achou_cache = _do_cache(exigir, usados, destino)  # 1º: o que já foi baixado antes, sem pedido de rede
    if achou_cache:
        return achou_cache
    for nome in cfg.get("fontes_imagem") or PADRAO:
        if _fora(nome):
            continue
        if nome == "nasa" and not (cfg.get("nasa") or "espaco" in canal or "nasa" in canal):
            continue
        for q in consultas:
            try:
                if nome == "commons":
                    credito = ja_commons(q) if ja_commons else None
                    if credito:
                        _guardar("commons:" + hashlib.md5((credito + q).encode()).hexdigest(), destino, credito, q, limite_mb)
                        return credito, "Commons"
                    continue
                for c in FONTES.get(nome, lambda **_: [])(q=q):
                    if c["id"] in usados or not _combina(exigir, c["texto"]):
                        continue
                    with _trava:
                        if c["id"] in usados:
                            continue
                        usados.add(c["id"])
                    with _rede:
                        destino.write_bytes(pegar(c["url"], 30, 2))  # 2 tentativas, não 4: fonte lenta sai da cadeia
                    if e_imagem(destino):
                        _falhas[nome] = 0
                        _guardar(c["id"], destino, c["credito"], c["texto"], limite_mb)
                        return c["credito"], nome
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    _parar(nome, 3600, "limite de pedidos por hora/dia", log)
                elif e.code in (401, 403):
                    _parar(nome, 86400, "chave recusada: confira credenciais/chaves.json", log)
                else:
                    _parar(nome, 300, f"erro {e.code}", log)
                break
            except Exception as e:  # rede, JSON, timeout: 3 falhas seguidas tiram a fonte por 5 minutos
                _falhas[nome] = _falhas.get(nome, 0) + 1
                if _falhas[nome] >= 3:
                    _falhas[nome] = 0
                    _parar(nome, 300, str(e)[:50], log)
                break
    return None
