"""Roteirista do Laboratório Otaku: transforma um tema pesquisado num episódio pronto para o motor.

O banco de temas (bancos/laboratorio-otaku/temas.json) traz, para cada poder de anime, os fatos já
conferidos e cada fala com a animação dela (tipos do motor/tipos.js). O Roteirista:
  1. escolhe o próximo tema ainda não usado,
  2. monta o roteiro.json do episódio (abertura, explicação, medidor de realidade, chamada final),
  3. escolhe título, descrição e hashtags,
  4. opcional (roteirista_ia: true + credenciais/cloudflare.json): pede a uma IA grátis para deixar as
     falas mais naturais. Só aceita a versão nova se ela mantiver todos os números e as palavras que
     disparam as animações; senão fica a fala original.
A animação não é escrita do zero: cada fala usa uma peça pronta (fato, número, comparação, lista,
analogia, medidor), e é isso que garante que todo vídeo sai sem erro de desenho.
"""
from __future__ import annotations

import json
import random
import re
import unicodedata
from pathlib import Path

ANIMES = ["One Piece", "Jujutsu Kaisen", "Hunter x Hunter", "Fullmetal Alchemist", "Pokémon", "Naruto"]

ABERTURA_ICONE = "atomo"
MODELO_IA = "@cf/meta/llama-3.3-70b-instruct-fp8-fast"
CTAS = [
    "Qual poder de anime você quer ver no laboratório? Comenta aí: {a}, {b} ou {c}?",
    "Próximo experimento: {a}, {b} ou {c}? Comenta qual você quer ver testado.",
    "Comenta o próximo poder pro laboratório testar: {a}, {b} ou {c}?",
]
LINHA_FA = "Explicação de fã sobre {anime}, sem cenas do anime: tudo desenhado por código."


def _norm(s: str) -> str:
    s = unicodedata.normalize("NFD", s.lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", _norm(s)).strip("-")[:40]


# ---------------------------------------------------------------- texto com IA (opcional)
def _palavras_chave(seg: dict) -> set[str]:
    """Palavras que a animação espera ouvir na fala (o motor anima no momento em que são ditas)."""
    achadas: set[str] = set()

    def varrer(x):
        if isinstance(x, dict):
            for k, v in x.items():
                if k.startswith("palavra") and isinstance(v, str):
                    achadas.add(_norm(v))
                elif k == "palavras" and isinstance(v, list):
                    achadas.update(_norm(w) for w in v if isinstance(w, str))
                else:
                    varrer(v)
        elif isinstance(x, list):
            for v in x:
                varrer(v)
    varrer(seg.get("p") or {})
    return achadas


def _valida(original: str, nova: str, chaves: set[str]) -> bool:
    if not nova or len(nova) > len(original) * 1.25 or len(nova) < len(original) * 0.7:
        return False
    n = _norm(nova)
    if any(k and k not in n for k in chaves):
        return False
    numeros = lambda s: sorted(re.findall(r"\d+", s))
    return numeros(original) == numeros(nova)


def _polir(segmentos: list[dict], cfg: dict, log) -> int:
    """Reescreve as falas com a IA da Cloudflare, se ligada. Devolve quantas falas mudaram."""
    if not cfg.get("roteirista_ia"):
        return 0
    arq = Path(__file__).resolve().parent.parent / "credenciais" / "cloudflare.json"
    try:
        cred = json.loads(arq.read_text(encoding="utf-8-sig"))
        conta, token = cred["account_id"], cred["api_token"]
    except (OSError, ValueError, KeyError):
        log("roteirista: sem credenciais/cloudflare.json; usando as falas do banco")
        return 0
    import urllib.request
    url = f"https://api.cloudflare.com/client/v4/accounts/{conta}/ai/run/{cfg.get('roteirista_modelo', MODELO_IA)}"

    def gerar(pedido: str, _cfg) -> str:
        req = urllib.request.Request(url, data=json.dumps({"messages": [{"role": "user", "content": pedido}],
                                                           "max_tokens": 300}).encode(),
                                     headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode())["result"]["response"]

    mudou = 0
    for s in segmentos:
        chaves = _palavras_chave(s)
        pedido = ("Reescreva esta fala de um vídeo curto de ciência sobre anime em português do Brasil, "
                  "mais natural para narração, mesmo sentido, mesmo tamanho, sem emoji. Mantenha todos os "
                  f"números e estas palavras exatamente: {', '.join(sorted(chaves)) or '(nenhuma)'}. "
                  f"Responda só com a fala.\n\nFala: {s['texto']}")
        try:
            nova = (gerar(pedido, cfg) or "").strip().strip('"')
        except Exception as e:  # sem internet, sem credencial, limite: segue com o texto original
            log(f"roteirista: IA indisponível ({e}); usando as falas do banco")
            return mudou
        if _valida(s["texto"], nova, chaves):
            s["texto"] = nova
            mudou += 1
    return mudou


# ---------------------------------------------------------------- montagem
def escrever(tema: dict, numero: int, cfg: dict | None = None, log=print, semente: int | None = None) -> dict:
    """Monta o roteiro.json do episódio a partir de um tema do banco."""
    cfg = cfg or {}
    rnd = random.Random(semente if semente is not None else f"{tema['id']}-{numero}")
    segs: list[dict] = []

    def add(tipo: str, texto: str, p: dict, pausa: float = 0.35, papel: str | None = None):
        n = len(segs) + 1
        seg = {"id": f"s{n:02d}", "cena": f"c{n:02d}", "tipo": tipo, "pausa": pausa, "texto": texto.strip(), "p": p}
        if papel:
            seg["papel"] = papel
        segs.append(seg)

    g = tema["gancho"]
    titulo_tela = tema.get("titulo_tela") or tema["poder"].upper()
    add("abertura", g["texto"], {"titulo": titulo_tela, "sobre": tema["anime"].upper(),
                                  "pergunta": g.get("pergunta") or "É POSSÍVEL?",
                                  "icone": tema.get("icone") or ABERTURA_ICONE,
                                  "carimbo": g.get("carimbo"), "expr_final": g.get("expr_final", "choque")}, 0.45)
    for b in tema["beats"]:
        add(b["tipo"], b["texto"], dict(b.get("p") or {}), b.get("pausa", 0.35), b.get("papel"))
    med = tema["medidor"]
    segs[-1]["pausa"] = 0.5
    add("medidor", med["texto"], {"itens": med["itens"][:2], "carimbo": med.get("carimbo")}, 0.4)
    sug = (tema.get("sugestoes") or ["Gear 5", "Domínio", "Hamon"])[:3]
    while len(sug) < 3:
        sug.append("outro poder")
    cta = rnd.choice(CTAS).format(a=sug[0], b=sug[1], c=sug[2])
    add("cta", cta, {"sugestoes": sug, "palavra": "comenta", "icone": tema.get("icone") or ABERTURA_ICONE}, 0.3)

    polidas = _polir(segs[1:-1], cfg, log)

    # música: muda de seção em pontos fixos da história (sempre em ordem crescente)
    virada = next((i for i, s in enumerate(segs) if s.get("papel") == "virada"), max(3, len(segs) - 4))
    virada = min(max(virada, 3), len(segs) - 3)
    musica = {"grooveA": segs[1]["cena"], "grooveB": segs[min(3, virada - 1)]["cena"],
              "tensao": segs[virada]["cena"], "cheio": segs[virada + 1]["cena"],
              "pausa": segs[-2]["cena"], "fim": segs[-1]["cena"]}
    if segs[virada + 1]["cena"] == musica["pausa"]:
        musica.pop("cheio")

    titulo = rnd.choice(tema.get("titulos") or [f"O {tema['poder']} é possível?"])
    fontes = [f for f in tema.get("fontes") or [] if isinstance(f, str)]
    descricao = tema.get("resumo", "") + "\n\n" + LINHA_FA.format(anime=tema["anime"])
    if fontes:
        descricao += "\n\nFontes: " + " | ".join(fontes[:3])
    tags = []
    for h in [*(tema.get("hashtags") or []), "shorts"]:
        h = "#" + h.lstrip("#").lower()
        if h not in tags:
            tags.append(h)

    roteiro = {
        "numero": numero, "slug": f"{numero:03d}-{tema['id']}", "tema": tema["id"],
        "anime": tema["anime"], "poder": tema["poder"], "titulo": titulo, "descricao": descricao,
        "hashtags": tags[:8], "cor": tema.get("cor", "#3fd0ff"), "cor2": tema.get("cor2", "#ff3fa4"),
        "musica": musica, "fontes_dos_fatos": fontes, "escrito_por": "Roteirista",
        "falas_polidas_pela_ia": polidas, "segmentos": segs,
    }
    log(f"roteirista: EXP. {numero:03d} {tema['anime']} / {tema['poder']}: {len(segs)} falas, "
        f"{sum(len(s['texto'].split()) for s in segs)} palavras")
    return roteiro


def carregar_temas(arquivos: list[Path]) -> list[dict]:
    """Temas de todos os bancos (o do canal ganha do que veio na atualização, pelo id)."""
    vistos, lista = set(), []
    for arq in arquivos:
        if not arq.is_file():
            continue
        try:
            dados = json.loads(arq.read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            print(f"[roteirista] banco {arq} ignorado: {e}", flush=True)
            continue
        for t in dados if isinstance(dados, list) else dados.get("temas", []):
            ok = all(k in t for k in ("id", "anime", "poder", "gancho", "beats", "medidor"))
            if ok and t["id"] not in vistos:
                vistos.add(t["id"])
                lista.append(t)
    return lista
