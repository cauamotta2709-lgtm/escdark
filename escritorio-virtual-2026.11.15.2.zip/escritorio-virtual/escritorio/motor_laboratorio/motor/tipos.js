// Laboratório Otaku: catálogo de cenas genéricas que o Roteirista do escritório combina sozinho.
// Cada segmento do roteiro diz { cena: "<id do bloco>", tipo: "<tipo>", p: { parâmetros } }.
// Os tempos vêm das palavras faladas (b.palavra("chave")), então a animação acompanha a voz.
// Tipos: abertura, fato, numero, comparacao, lista, analogia, medidor, cta.
'use strict';

const TIPOS = {};

// ---------------------------------------------------------------- ícones desenhados por código
// icone(c, nome, x, y, s, t, cor): s = escala (1 = ~120 px de largura)
function icone(c, nome, x, y, s, t, cor = PAL.cor) {
  if (s <= 0.01) return;
  c.save(); c.translate(x, y); c.scale(s, s);
  c.lineCap = 'round'; c.lineJoin = 'round';
  const tr = (lw = 8, col = cor) => { c.strokeStyle = col; c.lineWidth = lw; c.stroke(); };
  const enche = (col = cor) => { c.fillStyle = col; c.fill(); };
  const halo = (r = 70, a = 0.35) => { const g = c.createRadialGradient(0, 0, 0, 0, 0, r * 1.6); g.addColorStop(0, rgba(cor, a)); g.addColorStop(1, rgba(cor, 0)); c.fillStyle = g; c.beginPath(); c.arc(0, 0, r * 1.6, 0, TAU); c.fill(); };
  c.shadowColor = cor; c.shadowBlur = 18;
  switch (nome) {
    case 'esfera': c.shadowBlur = 0; esfera(c, 0, 0, 60, t, { cor, aneis: 9 }); break;
    case 'raio': {
      halo(60, 0.25);
      c.beginPath(); c.moveTo(14, -66); c.lineTo(-30, 8); c.lineTo(-2, 8); c.lineTo(-16, 66); c.lineTo(32, -12); c.lineTo(4, -12); c.closePath();
      enche(mistura(cor, '#ffffff', 0.35)); tr(5, '#ffffff');
      break;
    }
    case 'chama': {
      halo(60, 0.3);
      const f = Math.sin(t * 9) * 4;
      c.beginPath(); c.moveTo(0, 64); c.bezierCurveTo(-52, 60, -54, 4, -22, -20); c.bezierCurveTo(-24, 6, -8, 10, -6, 0);
      c.bezierCurveTo(-10, -30, 4, -52, 8 + f, -70); c.bezierCurveTo(12, -40, 54, -24, 46, 24); c.bezierCurveTo(42, 54, 20, 64, 0, 64); c.closePath();
      enche(cor);
      c.beginPath(); c.moveTo(0, 60); c.bezierCurveTo(-24, 58, -24, 26, -6, 12); c.bezierCurveTo(-2, 26, 10, 22, 10, 10 + f * 0.5); c.bezierCurveTo(26, 26, 22, 58, 0, 60); enche('#fff6d8');
      break;
    }
    case 'gota': {
      halo(55, 0.25);
      c.beginPath(); c.moveTo(0, -66); c.bezierCurveTo(30, -24, 48, 0, 48, 24); c.arc(0, 24, 48, 0, Math.PI); c.bezierCurveTo(-48, 0, -30, -24, 0, -66); c.closePath();
      enche(rgba(cor, 0.35)); tr(7);
      c.beginPath(); c.arc(-16, 22, 12, Math.PI * 0.9, Math.PI * 1.5); tr(6, '#ffffff');
      break;
    }
    case 'corrente': {
      for (let i = 0; i < 3; i++) {
        c.save(); c.translate(-56 + i * 56, Math.sin(t * 3 + i) * 3); c.rotate(i % 2 ? 0 : 0);
        c.beginPath(); c.ellipse(0, 0, 34, i % 2 ? 12 : 20, 0, 0, TAU); tr(11, mistura(cor, '#ffffff', 0.2)); c.restore();
      }
      break;
    }
    case 'olho': {
      halo(60, 0.2);
      c.beginPath(); c.moveTo(-70, 0); c.quadraticCurveTo(0, -62, 70, 0); c.quadraticCurveTo(0, 62, -70, 0); c.closePath(); enche('#0b1020'); tr(7);
      c.beginPath(); c.arc(0, 0, 26, 0, TAU); enche(cor); c.beginPath(); c.arc(0, 0, 11, 0, TAU); enche('#05070d');
      c.beginPath(); c.arc(-8, -9, 6, 0, TAU); enche('#ffffff');
      break;
    }
    case 'punho': {
      halo(60, 0.22);
      retRed(c, -46, -40, 92, 80, 26); enche(mistura(cor, '#0b1020', 0.55)); tr(7);
      for (let i = 0; i < 3; i++) linha(c, -22 + i * 22, -40, -22 + i * 22, -10, cor, 6);
      retRed(c, -62, -18, 30, 44, 14); enche(mistura(cor, '#0b1020', 0.4)); tr(6);
      break;
    }
    case 'coracao': {
      const p = 1 + 0.08 * Math.max(0, Math.sin(t * 7.5)) ** 8;
      c.scale(p, p); halo(55, 0.3);
      c.beginPath(); c.moveTo(0, 56); c.bezierCurveTo(-70, 6, -54, -56, 0, -24); c.bezierCurveTo(54, -56, 70, 6, 0, 56); c.closePath();
      enche(cor); c.beginPath(); c.arc(-24, -18, 9, 0, TAU); enche('rgba(255,255,255,0.6)');
      break;
    }
    case 'atomo': {
      halo(55, 0.25);
      for (let i = 0; i < 3; i++) { c.save(); c.rotate(i * TAU / 3 + t * 0.6); c.beginPath(); c.ellipse(0, 0, 66, 22, 0, 0, TAU); tr(5); c.restore(); }
      for (let i = 0; i < 3; i++) { const a = t * 3 + i * TAU / 3, ang = i * TAU / 3 + t * 0.6; const ex = Math.cos(a) * 66, ey = Math.sin(a) * 22; c.beginPath(); c.arc(ex * Math.cos(ang) - ey * Math.sin(ang), ex * Math.sin(ang) + ey * Math.cos(ang), 7, 0, TAU); enche('#ffffff'); }
      c.beginPath(); c.arc(0, 0, 13, 0, TAU); enche(cor);
      break;
    }
    case 'ouro': {
      halo(60, 0.3);
      c.beginPath(); c.moveTo(-66, 30); c.lineTo(66, 30); c.lineTo(44, -24); c.lineTo(-44, -24); c.closePath(); enche('#f5c542'); tr(5, '#fff1b0');
      c.beginPath(); c.moveTo(-44, -24); c.lineTo(44, -24); c.lineTo(36, -14); c.lineTo(-36, -14); c.closePath(); enche('#fff1b0');
      const br = (t * 0.8) % 2; if (br < 1) { c.save(); c.globalCompositeOperation = 'lighter'; c.globalAlpha = Math.sin(br * Math.PI) * 0.8; linha(c, -60 + br * 120, -24, -80 + br * 120, 30, '#ffffff', 8); c.restore(); }
      break;
    }
    case 'cerebro': {
      halo(60, 0.25);
      c.beginPath(); c.ellipse(-18, -4, 44, 50, 0, 0, TAU); c.ellipse(18, -4, 44, 50, 0, 0, TAU); enche(rgba(cor, 0.25));
      c.beginPath(); c.ellipse(-18, -4, 44, 50, 0, 0, TAU); tr(6); c.beginPath(); c.ellipse(18, -4, 44, 50, 0, 0, TAU); tr(6);
      for (const [a, b2, cc, d] of [[-40, -20, -10, -30], [-44, 16, -14, 6], [12, -28, 42, -12], [10, 14, 44, 24]]) { c.beginPath(); c.moveTo(a, b2); c.quadraticCurveTo((a + cc) / 2, b2 - 14, cc, d); tr(5); }
      const k = (t * 1.4) % 1; c.beginPath(); c.arc(lerp(-50, 50, k), -4 + Math.sin(k * 9) * 20, 6, 0, TAU); enche('#ffffff');
      break;
    }
    case 'escudo': {
      halo(60, 0.25);
      c.beginPath(); c.moveTo(0, -66); c.lineTo(56, -44); c.quadraticCurveTo(56, 34, 0, 66); c.quadraticCurveTo(-56, 34, -56, -44); c.closePath();
      enche(rgba(cor, 0.25)); tr(8);
      c.beginPath(); c.moveTo(0, -42); c.lineTo(0, 42); c.moveTo(-30, -6); c.lineTo(30, -6); tr(6, '#ffffff');
      break;
    }
    case 'tigela': {
      halo(55, 0.2);
      for (let i = 0; i < 3; i++) { const yy = -40 - ((t * 30 + i * 14) % 36); c.save(); c.globalAlpha *= 0.7; c.beginPath(); c.moveTo(-20 + i * 20, yy + 16); c.quadraticCurveTo(-28 + i * 20, yy + 6, -20 + i * 20, yy - 4); tr(4, '#ffffff'); c.restore(); }
      c.beginPath(); c.ellipse(0, -6, 56, 22, 0, Math.PI, TAU); enche('#f6e2b8');
      c.beginPath(); c.moveTo(-66, -6); c.quadraticCurveTo(-60, 52, 0, 54); c.quadraticCurveTo(60, 52, 66, -6); c.closePath(); enche(cor); tr(5, '#ffffff');
      break;
    }
    case 'velocidade': {
      for (let i = 0; i < 5; i++) { const k = (t * 2.2 + i * 0.21) % 1; linha(c, 70 - k * 150, -48 + i * 24, 70 - k * 150 - 40 - i * 6, -48 + i * 24, cor, 7, 1 - k); }
      c.beginPath(); c.arc(42, 0, 24, 0, TAU); enche('#ffffff');
      break;
    }
    case 'circulo': { // círculo geométrico de alquimia genérico (hexagrama), girando
      halo(64, 0.25);
      c.rotate(t * 0.4);
      c.beginPath(); c.arc(0, 0, 64, 0, TAU); tr(5); c.beginPath(); c.arc(0, 0, 52, 0, TAU); tr(3);
      for (const off of [0, Math.PI]) { c.beginPath(); for (let i = 0; i < 3; i++) { const a = off + i * TAU / 3 - Math.PI / 2; c.lineTo(Math.cos(a) * 52, Math.sin(a) * 52); } c.closePath(); tr(4); }
      c.beginPath(); c.arc(0, 0, 12, 0, TAU); tr(4, '#ffffff');
      break;
    }
    case 'onda': {
      for (let k = 0; k < 2; k++) { c.beginPath(); for (let i = 0; i <= 40; i++) { const xx = -70 + i * 3.5; c.lineTo(xx, Math.sin(i * 0.45 + t * 5 + k * Math.PI) * 26 * (k ? -1 : 1)); } tr(6, k ? PAL.cor2 : cor); }
      break;
    }
    case 'relogio': {
      halo(55, 0.2);
      c.beginPath(); c.arc(0, 0, 58, 0, TAU); enche('#0b1020'); tr(7);
      for (let i = 0; i < 12; i++) { const a = i * TAU / 12; linha(c, Math.cos(a) * 46, Math.sin(a) * 46, Math.cos(a) * 52, Math.sin(a) * 52, cor, 4); }
      const a1 = t * 2.4, a2 = t * 0.2; linha(c, 0, 0, Math.cos(a1 - Math.PI / 2) * 40, Math.sin(a1 - Math.PI / 2) * 40, '#ffffff', 5); linha(c, 0, 0, Math.cos(a2 - Math.PI / 2) * 26, Math.sin(a2 - Math.PI / 2) * 26, '#ffffff', 7);
      break;
    }
    case 'planeta': {
      halo(55, 0.25);
      c.beginPath(); c.arc(0, 0, 40, 0, TAU); enche(mistura(cor, '#0b1020', 0.3));
      c.save(); c.rotate(-0.35); c.beginPath(); c.ellipse(0, 0, 72, 18, 0, 0, TAU); tr(6, '#ffffff'); c.restore();
      break;
    }
    case 'agulha': {
      halo(50, 0.2);
      c.rotate(-0.6);
      c.beginPath(); c.moveTo(-8, -70); c.lineTo(8, -70); c.lineTo(5, 40); c.lineTo(0, 72); c.lineTo(-5, 40); c.closePath(); enche('#dfe6f5'); tr(3, '#ffffff');
      c.beginPath(); c.ellipse(0, -54, 3, 10, 0, 0, TAU); enche('#0b1020');
      const k = (t * 1.5) % 1; c.beginPath(); c.arc(0, 72, 6 + k * 30, 0, TAU); c.globalAlpha *= 1 - k; tr(3);
      break;
    }
    default: { c.beginPath(); c.arc(0, 0, 50, 0, TAU); tr(8); }
  }
  c.restore();
}

// ---------------------------------------------------------------- utilidades das cenas
const quando = (b, chave, padrao) => (chave ? b.palavra(chave, 0, padrao) : padrao);
// texto que quebra em linhas até caber na largura, devolve as linhas
function quebrar(c, s, fonte, largMax) {
  c.save(); c.font = fonte;
  const out = []; let atual = '';
  for (const w of String(s).split(/\s+/)) {
    const teste = atual ? atual + ' ' + w : w;
    if (c.measureText(teste).width > largMax && atual) { out.push(atual); atual = w; } else atual = teste;
  }
  if (atual) out.push(atual);
  c.restore(); return out;
}
function formatar(v, casas = 0) {
  const [i, d] = Math.abs(v).toFixed(casas).split('.');
  return (v < 0 ? '-' : '') + i.replace(/\B(?=(\d{3})+(?!\d))/g, '.') + (d ? ',' + d : '');
}
const corP = (nome) => ({ cor: PAL.cor, cor2: PAL.cor2, verde: PAL.verde, vermelho: PAL.vermelho, laranja: PAL.laranja, tinta: PAL.tinta }[nome] || nome || PAL.cor);

// mascote pequeno num canto, reagindo
function mascoteCanto(c, t, b, p, { x = 905, y = 520, s = 0.4, pose = 'aponta' } = {}) {
  const aM = entra(t, b.t0 + 0.25, 0.4, E.back);
  if (aM <= 0) return;
  let expr = p.expr || 'feliz';
  if (p.reacao && t >= quando(b, p.reacao.palavra, 1e9)) expr = p.reacao.expr || 'choque';
  mascote(c, x, y, s * clamp(aM), t, { expr, pose, olhar: x > CX ? -1 : 1 });
}

// ---------------------------------------------------------------- abertura (gancho)
TIPOS.abertura = {
  desenhar(c, t, b) {
    const p = b.p;
    const aR = entra(t, b.t0 + 0.05, 0.45);
    const aT = entra(t, b.t0 + 0.15, 0.55, E.back);
    const tit = String(p.titulo || '').toUpperCase();
    // título longo vai em duas linhas; cada linha cabe em 860 px contando o espaçamento das letras
    let linhasT = [tit];
    const pal = tit.split(' ');
    if (tit.length > 11 && pal.length > 1) {
      let melhor = 1, dif = 1e9;
      for (let i = 1; i < pal.length; i++) { const d = Math.abs(pal.slice(0, i).join(' ').length - pal.slice(i).join(' ').length); if (d < dif) { dif = d; melhor = i; } }
      linhasT = [pal.slice(0, melhor).join(' '), pal.slice(melhor).join(' ')];
    }
    const base = linhasT.length > 1 ? 128 : 150;
    c.save(); c.font = F.titulo(base);
    const wT = Math.max(...linhasT.map(l => c.measureText(l).width + 4 * l.length)); c.restore();
    const px = Math.min(base, Math.floor(base * 860 / Math.max(1, wT)));
    const yT = linhasT.length > 1 ? 405 : 420, passoT = px * 0.98;
    linhasT.forEach((l, i) => texto(c, l, CX, yT + i * passoT, { fonte: F.titulo(px), alpha: clamp(aT), espaco: 4, glow: 34, corGlow: PAL.cor }));
    rotulo(c, (p.pergunta || 'É POSSÍVEL NA VIDA REAL?').toUpperCase(), CX, linhasT.length > 1 ? 262 : 300, { alinha: 'center', px: 30, alpha: aR, cor: PAL.cor, peso: 700 });
    const ySobre = yT + (linhasT.length - 1) * passoT + 100;
    if (p.sobre) rotulo(c, String(p.sobre).toUpperCase(), CX, ySobre, { alinha: 'center', px: 28, alpha: entra(t, b.t0 + 0.35, 0.4), cor: PAL.apagado, peso: 700 });
    // mascote segurando o ícone do poder
    const aM = entra(t, b.t0 + 0.1, 0.6, E.back);
    const mx = CX - 70, my = 950, hx = CX + 150, hy = 760;
    const pulso = 1 + 0.04 * Math.sin(t * 5);
    const tC = p.carimbo ? quando(b, p.carimbo.palavra, b.falaFim - 0.6) : 1e9;
    mascote(c, mx, my, 0.8 * clamp(aM), t, { expr: t >= tC ? (p.expr_final || 'choque') : 'confiante', pose: 'segura', mao: [hx - 30, hy + 50], olhar: 1 });
    icone(c, p.icone || 'esfera', hx, hy, 1.45 * clamp(aM) * pulso, t, PAL.cor);
    if (p.carimbo) carimbo(c, t, tC, String(p.carimbo.texto).toUpperCase(), CX + 60, 1225, { cor: corP(p.carimbo.cor || 'vermelho'), px: 84, rot: -0.12 });
  },
  sons(b) {
    const p = b.p, out = [{ t: b.t0 + 0.15, tipo: 'boom', ganho: 0.8 }, { t: b.t0 + 0.2, tipo: 'zumbido', dur: Math.min(4, b.dur), ganho: 0.35 }];
    if (p.carimbo) out.push({ t: quando(b, p.carimbo.palavra, b.falaFim - 0.6) - 0.02, tipo: 'carimbo' });
    return out;
  }
};

// ---------------------------------------------------------------- fato: frase grande com destaque
TIPOS.fato = {
  desenhar(c, t, b) {
    const p = b.p;
    if (p.rotulo) etiqueta(c, t, b.t0 + 0.05, String(p.rotulo).toUpperCase());
    const linhas = (p.linhas || []).map(s => String(s).toUpperCase());
    const temIcone = !!p.icone;
    const y0 = temIcone ? 760 : 620, passo = 128;
    if (temIcone) {
      const aI = entra(t, b.t0 + 0.15, 0.55, E.back);
      icone(c, p.icone, CX, 520, 1.6 * clamp(aI), t, corP(p.cor_icone));
    }
    const ts = p.palavras || [];
    linhas.forEach((s, i) => {
      const tI = quando(b, ts[i], b.fala0 + i * 0.7);
      const a = entra(t, tI - 0.15, 0.4, E.back);
      const cor = i === (p.destaque ?? -1) ? PAL.cor : (i === p.destaque2 ? PAL.cor2 : PAL.tinta);
      c.save(); c.font = F.titulo(112); const w = c.measureText(s).width; c.restore();
      const px = Math.min(112, Math.floor(112 * 920 / Math.max(1, w)));
      c.save(); c.translate(CX, y0 + i * passo); c.scale(lerp(0.7, 1, clamp(a)), lerp(0.7, 1, clamp(a)));
      texto(c, s, 0, 0, { fonte: F.titulo(px), alpha: clamp(a), cor, espaco: 3, glow: cor === PAL.tinta ? 0 : 26 });
      c.restore();
    });
    if (p.carimbo) carimbo(c, t, quando(b, p.carimbo.palavra, b.falaFim - 0.5), String(p.carimbo.texto).toUpperCase(), CX + 120, y0 + linhas.length * passo + 30, { cor: corP(p.carimbo.cor || 'laranja'), px: 64, rot: -0.1 });
    mascoteCanto(c, t, b, p, { x: 160, y: 1010, s: 0.4 });
  },
  sons(b) {
    const p = b.p, ts = p.palavras || [];
    const out = (p.linhas || []).map((_, i) => ({ t: quando(b, ts[i], b.fala0 + i * 0.7) - 0.12, tipo: 'pop', nota: i * 4, ganho: 0.55 }));
    if (p.carimbo) out.push({ t: quando(b, p.carimbo.palavra, b.falaFim - 0.5) - 0.02, tipo: 'carimbo' });
    if (p.impacto) out.push({ t: b.t0 + 0.1, tipo: 'boom', ganho: 0.7 });
    return out;
  }
};

// ---------------------------------------------------------------- número contando
TIPOS.numero = {
  desenhar(c, t, b) {
    const p = b.p;
    if (p.rotulo) etiqueta(c, t, b.t0 + 0.05, String(p.rotulo).toUpperCase());
    const tA = quando(b, p.palavra_inicio, b.fala0 + 0.1), tB = quando(b, p.palavra, b.fala0 + 1.4) + 0.25;
    const k = E.out5(prog(t, tA, Math.max(tA + 0.4, tB)));
    const v = lerp(p.de || 0, p.valor, k);
    const s = (p.prefixo || '') + formatar(v, p.casas || 0);
    const aN = entra(t, tA - 0.2, 0.35);
    c.save(); c.font = F.titulo(230); const w = c.measureText(s).width; c.restore();
    const px = Math.min(230, Math.floor(230 * 900 / Math.max(1, w)));
    if (p.icone) icone(c, p.icone, CX, 500, 1.2 * entra(t, b.t0 + 0.1, 0.5, E.back), t, PAL.cor);
    texto(c, s, CX, 760, { fonte: F.titulo(px), alpha: aN, cor: k >= 0.999 ? PAL.cor : PAL.tinta, glow: k >= 0.999 ? 34 : 8, corGlow: PAL.cor, espaco: 2 });
    if (p.unidade) texto(c, String(p.unidade).toUpperCase(), CX, 760 + px * 0.62, { fonte: F.titulo(72), alpha: aN, cor: PAL.tinta, espaco: 4 });
    if (p.nota) {
      const aT = entra(t, quando(b, p.palavra_nota, tB + 0.3), 0.4);
      const ls = quebrar(c, String(p.nota).toUpperCase(), F.mono(34, 700), 860);
      ls.forEach((l, i) => rotulo(c, l, CX, 1000 + px * 0.3 + i * 46, { alinha: 'center', px: 34, alpha: aT, peso: 700, cor: PAL.apagado }));
    }
    // marcador técnico em volta
    cantos(c, 110, 600, 860, 360 + (p.unidade ? 70 : 0), rgba(PAL.cor, 0.5), aN);
    mascoteCanto(c, t, b, p, { x: 905, y: 380, s: 0.36 });
  },
  sons(b) {
    const p = b.p;
    const tA = quando(b, p.palavra_inicio, b.fala0 + 0.1), tB = quando(b, p.palavra, b.fala0 + 1.4) + 0.25;
    const out = [];
    for (let x = tA; x < tB - 0.05; x += 0.09) out.push({ t: x, tipo: 'tick', ganho: 0.25 });
    out.push({ t: tB, tipo: 'ding', ganho: 0.7 });
    return out;
  }
};

// ---------------------------------------------------------------- comparação em barras
TIPOS.comparacao = {
  desenhar(c, t, b) {
    const p = b.p, itens = p.itens || [];
    if (p.rotulo) etiqueta(c, t, b.t0 + 0.05, String(p.rotulo).toUpperCase());
    const log = p.escala === 'log';
    const vals = itens.map(i => Math.max(1e-9, Number(i.valor) || 0));
    const mx = Math.max(...vals), mn = Math.min(...vals);
    const frac = v => log ? (mx === mn ? 1 : 0.08 + 0.92 * (Math.log10(v) - Math.log10(mn)) / (Math.log10(mx) - Math.log10(mn))) : v / mx;
    const n = itens.length, alto = Math.min(230, 860 / Math.max(1, n)), y0 = 480 + (860 - alto * n) / 2;
    itens.forEach((it, i) => {
      const tI = quando(b, it.palavra, b.fala0 + 0.3 + i * 0.9);
      const a = entra(t, tI - 0.25, 0.35);
      if (a <= 0) return;
      const y = y0 + i * alto, cor = corP(it.cor || (i === n - 1 ? 'cor' : i === 0 ? 'cor2' : 'laranja'));
      texto(c, String(it.nome).toUpperCase(), 110, y + 10, { fonte: F.titulo(64), alinha: 'left', alpha: a, cor, espaco: 2 });
      const k = E.out(prog(t, tI - 0.1, tI + 0.7)) * frac(vals[i]);
      barra(c, 110, y + 62, 860, 30, k, cor);
      texto(c, String(it.texto || formatar(vals[i])).toUpperCase(), 110 + Math.max(30, 860 * k) - 4, y + 132, { fonte: F.mono(32, 700), alinha: k > 0.4 ? 'right' : 'left', alpha: a, cor: PAL.tinta, espaco: 1 });
    });
    if (log) rotulo(c, 'ESCALA LOGARÍTMICA', 970, y0 + n * alto + 10, { alinha: 'right', px: 22, alpha: entra(t, b.t0 + 1, 0.4) });
    mascoteCanto(c, t, b, p, { x: 905, y: 390, s: 0.34 });
  },
  sons(b) {
    return (b.p.itens || []).map((it, i) => ({ t: quando(b, it.palavra, b.fala0 + 0.3 + i * 0.9) - 0.1, tipo: 'subida', dur: 0.6, ganho: 0.4 }));
  }
};

// ---------------------------------------------------------------- lista com checks
TIPOS.lista = {
  desenhar(c, t, b) {
    const p = b.p, itens = p.itens || [];
    if (p.rotulo) etiqueta(c, t, b.t0 + 0.05, String(p.rotulo).toUpperCase());
    const n = itens.length, passo = Math.min(200, 760 / Math.max(1, n)), y0 = 520 + (760 - passo * n) / 2;
    itens.forEach((it, i) => {
      const tI = quando(b, it.palavra, b.fala0 + 0.3 + i * 1.1);
      const a = entra(t, tI - 0.2, 0.35, E.back);
      if (a <= 0) return;
      const y = y0 + i * passo;
      c.save(); c.globalAlpha *= clamp(a); c.translate((1 - clamp(a)) * -60, 0);
      retRed(c, 100, y - 70, 880, 140, 28); c.fillStyle = 'rgba(255,255,255,0.05)'; c.fill(); c.strokeStyle = rgba(PAL.cor, 0.35); c.lineWidth = 2; c.stroke();
      if (it.icone) icone(c, it.icone, 180, y, 0.62, t, PAL.cor);
      else texto(c, String(i + 1).padStart(2, '0'), 180, y + 2, { fonte: F.titulo(72), cor: PAL.cor, glow: 18 });
      const ls = quebrar(c, String(it.texto).toUpperCase(), F.texto(44, 900), 600);
      ls.slice(0, 2).forEach((l, j) => texto(c, l, 260, y + (j - (Math.min(2, ls.length) - 1) / 2) * 52, { fonte: F.texto(44, 900), alinha: 'left', cor: PAL.tinta }));
      check(c, 920, y, 0.8, prog(t, tI + 0.15, tI + 0.5), corP(it.cor || 'verde'));
      c.restore();
    });
    mascoteCanto(c, t, b, p, { x: 905, y: 360, s: 0.32 });
  },
  sons(b) {
    return (b.p.itens || []).map((it, i) => ({ t: quando(b, it.palavra, b.fala0 + 0.3 + i * 1.1) - 0.15, tipo: 'pop', nota: 3 + i * 3, ganho: 0.55 }));
  }
};

// ---------------------------------------------------------------- analogia: anime x vida real
TIPOS.analogia = {
  desenhar(c, t, b) {
    const p = b.p;
    if (p.rotulo) etiqueta(c, t, b.t0 + 0.05, String(p.rotulo).toUpperCase());
    const cartao = (lado, x, cor, tI) => {
      const a = entra(t, tI - 0.2, 0.45, E.back);
      if (a <= 0 || !lado) return;
      c.save(); c.globalAlpha *= clamp(a); c.translate(x + 200, 800); c.scale(lerp(0.8, 1, clamp(a)), lerp(0.8, 1, clamp(a))); c.translate(-(x + 200), -800);
      retRed(c, x, 470, 400, 680, 36); c.fillStyle = rgba(cor, 0.08); c.fill(); c.strokeStyle = rgba(cor, 0.7); c.lineWidth = 3; c.stroke();
      rotulo(c, String(lado.titulo || '').toUpperCase(), x + 200, 530, { alinha: 'center', px: 30, peso: 700, cor });
      icone(c, lado.icone || 'esfera', x + 200, 720, 1.25, t, cor);
      const ls = quebrar(c, String(lado.texto || '').toUpperCase(), F.titulo(56), 340);
      ls.slice(0, 4).forEach((l, i) => texto(c, l, x + 200, 920 + i * 66, { fonte: F.titulo(56), cor: PAL.tinta, espaco: 2 }));
      c.restore();
    };
    const tE = quando(b, p.esquerda?.palavra, b.fala0 + 0.2), tD = quando(b, p.direita?.palavra, b.fala0 + 1.5);
    cartao(p.esquerda, 80, PAL.cor2, tE);
    cartao(p.direita, 600, PAL.cor, tD);
    const aS = entra(t, tD - 0.1, 0.4, E.back);
    if (aS > 0) {
      c.save(); c.translate(CX, 800); c.scale(clamp(aS), clamp(aS));
      c.beginPath(); c.arc(0, 0, 54, 0, TAU); c.fillStyle = '#05070d'; c.fill(); c.strokeStyle = PAL.tinta; c.lineWidth = 4; c.stroke();
      texto(c, p.simbolo || '=', 0, 4, { fonte: F.titulo(64), cor: PAL.tinta });
      c.restore();
    }
  },
  sons(b) {
    const p = b.p;
    return [{ t: quando(b, p.esquerda?.palavra, b.fala0 + 0.2) - 0.15, tipo: 'whoosh', ganho: 0.4 }, { t: quando(b, p.direita?.palavra, b.fala0 + 1.5) - 0.15, tipo: 'impacto', ganho: 0.6 }];
  }
};

// ---------------------------------------------------------------- medidor de realidade (fixo no fim)
TIPOS.medidor = {
  desenhar(c, t, b) {
    const p = b.p, itens = (p.itens || []).slice(0, 2);
    const aT = entra(t, b.t0, 0.45, E.back);
    texto(c, 'MEDIDOR DE', CX, 360, { fonte: F.titulo(92), alpha: clamp(aT), espaco: 6 });
    texto(c, 'REALIDADE', CX, 470, { fonte: F.titulo(132), alpha: clamp(aT), cor: PAL.cor, espaco: 8, glow: 30 });
    const tUlt = itens.length ? quando(b, itens[itens.length - 1].palavra, b.falaFim - 1) : 1e9;
    const baixo = itens.length && Number(itens[itens.length - 1].pct) < 30;
    mascote(c, 150, 1010, 0.42 * entra(t, b.t0 + 0.3, 0.4, E.back), t, { expr: t < tUlt + 0.3 ? 'serio' : (baixo ? 'choque' : 'feliz'), pose: 'aponta', olhar: 1 });
    const gauge = (cx, cy, R, k, rot, aa) => {
      if (aa <= 0) return;
      c.save(); c.globalAlpha *= aa; c.lineCap = 'round';
      c.strokeStyle = 'rgba(255,255,255,0.09)'; c.lineWidth = 30; c.beginPath(); c.arc(cx, cy, R, Math.PI, TAU); c.stroke();
      for (let i = 0; i < 40; i++) {
        const a0 = Math.PI + i / 40 * Math.PI, a1 = a0 + Math.PI / 40 * 0.7;
        c.strokeStyle = mistura(PAL.vermelho, PAL.verde, i / 39); c.globalAlpha = aa * (i / 40 <= k ? 1 : 0.18); c.lineWidth = 30; c.lineCap = 'butt';
        c.beginPath(); c.arc(cx, cy, R, a0, a1); c.stroke();
      }
      c.globalAlpha = aa;
      const an = Math.PI + k * Math.PI;
      c.strokeStyle = PAL.tinta; c.lineWidth = 8; c.lineCap = 'round';
      c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.cos(an) * (R - 40), cy + Math.sin(an) * (R - 40)); c.stroke();
      c.fillStyle = PAL.tinta; c.beginPath(); c.arc(cx, cy, 16, 0, TAU); c.fill();
      texto(c, Math.round(100 * k) + '%', cx, cy - 70, { fonte: F.titulo(76), cor: mistura(PAL.vermelho, PAL.verde, k), glow: 20 });
      const ls = quebrar(c, String(rot).toUpperCase(), F.mono(28, 700), 520);
      ls.slice(0, 2).forEach((l, i) => rotulo(c, l, cx, cy + 52 + i * 36, { alinha: 'center', px: 28, peso: 700, cor: PAL.tinta }));
      c.restore();
    };
    const ys = itens.length === 1 ? [880] : [760, 1110];
    itens.forEach((it, i) => {
      const tI = quando(b, it.palavra, b.fala0 + 0.5 + i * 1.6);
      const k = E.out(prog(t, tI - 0.3, tI + 0.5)) * clamp((Number(it.pct) || 0) / 100);
      gauge(CX, ys[i], 220, k, it.rotulo, entra(t, tI - 0.6, 0.4));
    });
    if (p.carimbo) carimbo(c, t, quando(b, p.carimbo.palavra, b.falaFim - 0.4), String(p.carimbo.texto).toUpperCase(), CX + 170, 1205, { cor: corP(p.carimbo.cor || 'laranja'), px: 52, rot: -0.1 });
  },
  sons(b) {
    const p = b.p, out = [];
    (p.itens || []).slice(0, 2).forEach((it, i) => out.push({ t: quando(b, it.palavra, b.fala0 + 0.5 + i * 1.6) + 0.3, tipo: Number(it.pct) < 30 ? 'erro' : 'ding', ganho: 0.75 }));
    if (p.carimbo) out.push({ t: quando(b, p.carimbo.palavra, b.falaFim - 0.4) - 0.02, tipo: 'carimbo' });
    return out;
  }
};

// ---------------------------------------------------------------- chamada final (fixa)
TIPOS.cta = {
  desenhar(c, t, b) {
    const p = b.p;
    const a = entra(t, b.t0, 0.5, E.back);
    mascote(c, CX + 40, 470, 0.6 * clamp(a), t, { expr: 'feliz', pose: 'acena' });
    icone(c, p.icone || 'esfera', CX - 170, 450, 0.75 * clamp(a), t, PAL.cor);
    texto(c, 'QUAL PODER', CX, 790, { fonte: F.titulo(118), alpha: clamp(a), espaco: 5 });
    texto(c, 'VEM AGORA?', CX, 905, { fonte: F.titulo(118), alpha: clamp(entra(t, b.t0 + 0.15, 0.5, E.back)), cor: PAL.cor, espaco: 5, glow: 26 });
    const tCm = quando(b, p.palavra || 'comenta', b.fala0 + 0.3);
    const aB = entra(t, tCm + 0.3, 0.4, E.back);
    if (aB > 0) {
      const sug = p.sugestoes && p.sugestoes.length ? p.sugestoes : ['Kamehameha', 'Gear 5', 'Bankai'];
      const tt = t - (tCm + 0.6);
      const i = Math.max(0, Math.floor(tt / 1.1)) % sug.length, kk = tt < 0 ? 0 : (tt % 1.1) / 0.6;
      const txt = sug[i].slice(0, Math.floor(sug[i].length * clamp(kk)));
      const x = 190, y = 990, w = 700, h = 104;
      c.save(); c.globalAlpha *= clamp(aB);
      retRed(c, x, y, w, h, 30); c.fillStyle = 'rgba(255,255,255,0.07)'; c.fill(); c.strokeStyle = 'rgba(255,255,255,0.35)'; c.lineWidth = 2.5; c.stroke();
      c.fillStyle = 'rgba(255,255,255,0.07)'; c.beginPath(); c.moveTo(x + 60, y + h); c.lineTo(x + 40, y + h + 34); c.lineTo(x + 100, y + h); c.fill();
      pessoa(c, x + 60, y + h / 2 + 6, 0.62, PAL.apagado);
      texto(c, txt + (Math.floor(t * 3) % 2 ? '|' : ''), x + 120, y + h / 2 + 2, { fonte: F.texto(44, 700), alinha: 'left', cor: PAL.tinta });
      c.restore();
    }
    logo(c, CX - 205, 1200, 1.1, t, entra(t, b.t0 + 0.4, 0.5));
    texto(c, 'LABORATÓRIO OTAKU', CX + 25, 1201, { fonte: F.mono(32, 700), alpha: entra(t, b.t0 + 0.4, 0.5), espaco: 3 });
  },
  sons(b) {
    return [{ t: b.t0 + 0.05, tipo: 'boom', ganho: 0.6 }, { t: quando(b, b.p.palavra || 'comenta', b.fala0 + 0.3) + 0.3, tipo: 'pop', nota: 7, ganho: 0.6 }];
  }
};
