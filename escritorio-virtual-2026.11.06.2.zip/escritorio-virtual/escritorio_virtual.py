#!/usr/bin/env python3
"""Liga o escritório virtual: os 5 agentes e o painel ao vivo.

  python3 escritorio_virtual.py                 # roda com config.json e abre o painel na porta 8765
  python3 escritorio_virtual.py --videos 1      # produz só 1 vídeo
  python3 escritorio_virtual.py --canal quiz-desafios  # só um canal da pasta canais/
  python3 escritorio_virtual.py --sempre        # não para: um lote por dia (para rodar 24h)
"""
import argparse
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import time
import webbrowser

from escritorio import canais, limpeza
from escritorio.agentes import LINHA
from escritorio.agentes.editor import escolher_codificador
from escritorio.nucleo import RAIZ, Telemetria, baixar_prioridade, configurar_pesado, preparar_ffmpeg
from escritorio.servidor import iniciar


def abrir_painel(url: str) -> None:
    """Abre o painel numa janela própria, como aplicativo (Edge ou Chrome no modo --app).
    Sem nenhum dos dois, abre numa aba comum do navegador padrão."""
    locais = [os.path.expandvars(p) for p in (
        r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe",
        r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe",
        r"%ProgramFiles%\Google\Chrome\Application\chrome.exe",
        r"%LocalAppData%\Google\Chrome\Application\chrome.exe")]
    locais += [shutil.which(n) or "" for n in ("msedge", "google-chrome", "chromium", "chrome")]
    for exe in locais:
        if exe and os.path.isfile(exe):
            subprocess.Popen([exe, f"--app={url}", "--window-size=1320,920"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
    webbrowser.open(url)


def limpar_sobras() -> None:
    """Apaga pastas de vídeos que ficaram pela metade quando o programa foi fechado no meio."""
    for pasta in (RAIZ / "saida").glob("*"):
        if pasta.is_dir() and re.fullmatch(r"[0-9a-f]{8}", pasta.name) \
                and time.time() - pasta.stat().st_mtime > 3600:
            shutil.rmtree(pasta, ignore_errors=True)


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # console do Windows
    ap = argparse.ArgumentParser()
    ap.add_argument("--videos", type=int, help="quantos vídeos produzir nesta rodada")
    ap.add_argument("--canal", help="produz só para este canal (nome da pasta em canais/)")
    ap.add_argument("--porta", type=int, default=8765)
    ap.add_argument("--offline", action="store_true", help="não usa internet")
    ap.add_argument("--sempre", action="store_true", help="repete a rodada a cada 24h")
    ap.add_argument("--sem-navegador", action="store_true", help="não abre o painel sozinho")
    ap.add_argument("--aba", action="store_true", help="abre o painel numa aba em vez de janela própria")
    args = ap.parse_args()

    if not preparar_ffmpeg():
        print("O ffmpeg (programa que edita os vídeos) não foi encontrado.")
        if os.name == "nt" and shutil.which("winget"):
            print("Instalando agora pelo winget. Aceite se o Windows pedir...")
            subprocess.run(["winget", "install", "-e", "--id", "Gyan.FFmpeg",
                            "--accept-source-agreements", "--accept-package-agreements"])
        if not preparar_ffmpeg():
            print("Ainda não achei o ffmpeg. Feche esta janela, rode instalar.bat de novo e "
                  "depois abra o escritório outra vez.")
            sys.exit(1)
    cfg = json.loads((RAIZ / "config.json").read_text(encoding="utf-8-sig"))
    if cfg.get("ajuste_leveza", 0) < 1:  # versão 2026.11.06: 2 vídeos por nicho, fila curta, render com mais qualidade
        cfg.update({"videos_por_canal": 2, "fila_max": 2, "preset": "medium", "ajuste_leveza": 1})
        try:
            (RAIZ / "config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass
    if args.videos:
        cfg["videos_por_rodada"] = cfg["limite_rodada"] = args.videos
    if args.canal:
        achados = canais.carregar(args.canal)
        if not achados:
            print(f"Não achei o canal '{args.canal}' entre os ativos (confira o nome da pasta, "
                  "\"ativo\" no canal.json e se o canal.json abre sem erro). Canais: "
                  + ", ".join(p.parent.name for p in sorted((RAIZ / "canais").glob("*/canal.json"))))
            sys.exit(1)
        cfg["so_canal"] = achados[0]["pasta"]  # o nome exato da pasta, mesmo digitado diferente
    if args.offline:
        cfg["offline"] = True
    if not cfg.get("manter_intermediarios"):
        limpar_sobras()
    try:  # vídeos velhos saem sozinhos (config.json: dias_apos_publicar, limite_gb)
        limpeza.limpar(cfg, lambda m: print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True))
    except Exception as e:
        print(f"limpeza não rodou ({e})")

    if cfg.get("prioridade_baixa", True):
        baixar_prioridade()  # o PC continua leve para você usar enquanto os vídeos são feitos
    configurar_pesado(cfg.get("pesados_simultaneos", 2))
    tele = Telemetria()
    filas = [queue.Queue(maxsize=cfg.get("fila_max", 2)) for _ in LINHA[1:]]
    copias = dict(cfg.get("copias", {}))
    if copias.get("editor") == "auto":  # 2 editores se o PC tem chip de vídeo, senão 1
        copias["editor"] = 1 if escolher_codificador(cfg.get("codificador", "auto")) == "libx264" else 2
    agentes = [cls(tele, cfg, filas[i - 1] if i else None, filas[i] if i < len(filas) else None, n)
               for i, cls in enumerate(LINHA)
               for n in range(1, (copias.get(cls.chave, 1) if i else 1) + 1)]
    porta = iniciar(tele, args.porta).server_address[1]
    print(f"Painel ao vivo: http://127.0.0.1:{porta}")
    if not args.sem_navegador:
        url = f"http://127.0.0.1:{porta}"  # 127.0.0.1 e não localhost: evita cair em outro programa
        webbrowser.open(url) if args.aba else abrir_painel(url)
    for a in agentes:
        a.start()

    try:
        while True:
            time.sleep(1)
            olheiro = agentes[0]
            if tele.videos_prontos + sum(tele.agentes[a.chave]["erros"] for a in agentes) >= olheiro.limite \
                    and olheiro.gerados >= olheiro.limite:
                tele.salvar()
                if not args.sempre:
                    onde = "canais/<canal>/prontos/" if olheiro.canais else "saida/prontos/"
                    print(f"Rodada concluída: {tele.videos_prontos} vídeo(s) em {onde}. "
                          "Painel continua aberto; Ctrl+C para sair.")
                    while True:
                        time.sleep(3600)
                print("Rodada concluída; próxima em 24h.")
                try:
                    limpeza.limpar(cfg, lambda m: print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True))
                except Exception as e:
                    print(f"limpeza não rodou ({e})")
                time.sleep(24 * 3600)
                agentes[0].gerados = 0
                tele.zerar_rodada()
    except KeyboardInterrupt:
        tele.salvar()


if __name__ == "__main__":
    main()
