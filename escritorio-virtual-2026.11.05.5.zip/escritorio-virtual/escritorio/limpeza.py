"""Limpeza automática dos vídeos prontos, para não lotar o computador.

Roda sozinha ao abrir o escritório (e a cada rodada diária com --sempre). Mexe SÓ em pastas de vídeo
com nome de 8 letras/números (o id do vídeo) dentro de:
  canais/<canal>/prontos/   saida/prontos/   e a pasta_para_postar (a cópia que vai para o Drive).
Nunca toca em roteiros, bancos, usados.json, credenciais, config.json, canal.json, música, fundos, clipes.

Regras (config.json):
  limpeza_ativa   true/false (padrão true)
  dias_para_manter  apaga vídeos com mais de N dias (padrão 7)
  limite_gb         se os vídeos passarem disso, apaga os mais antigos até caber; 0 = sem limite (padrão 15)
  manter_ultimos    os N vídeos mais novos nunca entram na regra do limite (padrão 5)
Com postar_de_verdade ligado, vídeo que ainda não foi publicado (ou que falhou) nunca é apagado.
Tudo que for removido fica registrado em saida/limpeza.log.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import stat
import time
from pathlib import Path

from . import canais
from .nucleo import RAIZ

ID = re.compile(r"^[0-9a-f]{8}$")
ARQUIVOS_DO_VIDEO = {"video.mp4", "post.json", "descricao.txt"}
REGISTRO = RAIZ / "saida" / "limpeza.log"
ESTADO = RAIZ / "saida" / "limpeza.json"


def _tamanho(pasta: Path) -> int:
    total = 0
    for dirpath, _, nomes in os.walk(pasta):
        for n in nomes:
            try:
                total += os.path.getsize(os.path.join(dirpath, n))
            except OSError:
                pass
    return total


def _apagar(pasta: Path) -> bool:
    def forcar(func, caminho, _info):
        try:
            os.chmod(caminho, stat.S_IWRITE | stat.S_IREAD)
            func(caminho)
        except OSError:
            pass
    shutil.rmtree(pasta, onerror=forcar)
    return not pasta.exists()


def _publicado(pasta: Path) -> bool:
    """Mesma regra do painel: link/id do YouTube, TikTok, Instagram ou Postiz = publicado."""
    try:
        post = json.loads((pasta / "post.json").read_text(encoding="utf-8-sig")).get("postagens") or {}
    except (OSError, ValueError):
        return False
    return any(not str(v).startswith(("pronto", "falhou", "sem credenciais")) for v in post.values())


def _videos(cfg: dict) -> list[dict]:
    """Todas as pastas de vídeo pronto (e as cópias na pasta_para_postar), com id, idade e tamanho."""
    itens: list[dict] = []
    bases = [(p.parent.name, p, "prontos") for p in sorted((RAIZ / "canais").glob("*/prontos"))]
    bases.append(("geral", RAIZ / "saida" / "prontos", "prontos"))
    extra = str(cfg.get("pasta_para_postar") or "").strip()
    if extra:
        raiz_extra = Path(extra).expanduser()
        if raiz_extra.is_dir() and raiz_extra.resolve() not in (RAIZ.resolve(), Path(raiz_extra.anchor)):
            bases += [(c.name, c, "para_postar") for c in sorted(raiz_extra.iterdir()) if c.is_dir()]
    for canal, base, tipo in bases:
        if not base.is_dir():
            continue
        for pasta in base.iterdir():
            if not (pasta.is_dir() and ID.match(pasta.name)):
                continue
            arquivos = {a.name for a in pasta.iterdir()}
            if not arquivos or not arquivos <= ARQUIVOS_DO_VIDEO:  # tem algo estranho dentro: não mexe
                continue
            video = pasta / "video.mp4"
            try:
                quando = (video if video.exists() else pasta).stat().st_mtime
            except OSError:
                continue
            itens.append({"pasta": pasta, "id": pasta.name, "canal": canal, "tipo": tipo,
                          "quando": quando, "bytes": _tamanho(pasta)})
    return itens


def resumo(cfg: dict | None = None) -> dict:
    """Espaço usado pelos vídeos e o que a última limpeza fez (para o painel)."""
    if cfg is None:
        try:
            cfg = json.loads((RAIZ / "config.json").read_text(encoding="utf-8-sig"))
        except (OSError, ValueError):
            cfg = {}
    itens = _videos(cfg)
    try:
        ultima = json.loads(ESTADO.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        ultima = {}
    return {"ativa": cfg.get("limpeza_ativa", True) is not False,
            "dias_para_manter": cfg.get("dias_para_manter", 7), "limite_gb": cfg.get("limite_gb", 15),
            "videos": len({i["id"] for i in itens}),
            "usado_gb": round(sum(i["bytes"] for i in itens) / 2**30, 2), "ultima": ultima}


def limpar(cfg: dict, log=print) -> dict:
    if cfg.get("limpeza_ativa", True) is False:
        return {}
    dias = float(cfg.get("dias_para_manter", 7) or 0)
    limite = float(cfg.get("limite_gb", 15) or 0) * 2**30
    minimo = int(cfg.get("manter_ultimos", 5) or 0)
    real = bool(cfg.get("postar_de_verdade"))
    itens = _videos(cfg)
    if not itens:
        return {}
    # com postagem automática ligada, o que não foi publicado fica (o Postador ainda precisa dele)
    protegidos = {i["id"] for i in itens if real and i["tipo"] == "prontos" and not _publicado(i["pasta"])}
    agora = time.time()
    removidos: list[dict] = []

    def remover(item: dict, motivo: str) -> None:
        idade = (agora - item["quando"]) / 86400
        if _apagar(item["pasta"]):
            removidos.append(item)
            log(f"limpeza | removi {item['canal']}/{item['id']} ({item['tipo']}, "
                f"{item['bytes'] / 2**20:.0f} MB, {idade:.1f} dias): {motivo}")
        else:
            log(f"limpeza | não consegui remover {item['pasta']} (arquivo em uso?)")

    if dias > 0:  # 1) vídeos mais velhos que dias_para_manter
        for item in itens:
            if item["id"] not in protegidos and agora - item["quando"] > dias * 86400:
                remover(item, f"mais de {dias:g} dias")
    if limite > 0:  # 2) ainda acima do limite: do mais antigo para o mais novo
        restantes = [i for i in itens if i not in removidos]
        usado = sum(i["bytes"] for i in restantes)
        novos = {i["id"] for i in sorted({i["id"]: i for i in restantes}.values(),
                                         key=lambda x: x["quando"], reverse=True)[:minimo]}
        for item in sorted(restantes, key=lambda x: x["quando"]):
            if usado <= limite:
                break
            if item["id"] in protegidos or item["id"] in novos:
                continue
            remover(item, f"passou do limite de {limite / 2**30:g} GB")
            usado -= item["bytes"] if item in removidos else 0
    liberado = sum(i["bytes"] for i in removidos)
    resultado = {"quando": time.strftime("%Y-%m-%d %H:%M"), "removidos": len({i["id"] for i in removidos}),
                 "liberado_mb": round(liberado / 2**20)}
    try:
        REGISTRO.parent.mkdir(parents=True, exist_ok=True)
        ESTADO.write_text(json.dumps(resultado, ensure_ascii=False), encoding="utf-8")
        if removidos:
            with open(REGISTRO, "a", encoding="utf-8") as f:
                for i in removidos:
                    f.write(f"{resultado['quando']} {i['canal']}/{i['id']} {i['tipo']} "
                            f"{i['bytes'] / 2**20:.0f}MB\n")
    except OSError:
        pass
    if removidos:
        log(f"limpeza | {resultado['removidos']} vídeo(s) removido(s), {resultado['liberado_mb']} MB liberados")
    return resultado
