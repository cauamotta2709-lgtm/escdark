"""Agente 2: carrega a matéria-prima do vídeo: narração (TTS) e clipes de fundo.

Narração, do melhor para o mais simples, tudo grátis. Se uma voz falha, tenta a próxima:
  edge-tts (vozes neurais da Microsoft, naturais, precisa de internet)  ->  piper (offline)
  ->  espeak-ng  ->  trilha muda com tempo de leitura
O edge-tts também diz em que momento cada palavra é falada, e a legenda usa isso.
Imagens: uma para cada frase, buscada pelo que a frase fala. Primeiro na pasta clipes/
(seus clipes, ex.: gerados à mão em sites de IA; o nome do arquivo diz o assunto, como
"polvo-nadando.mp4"), depois no Pexels (chave grátis em PEXELS_API_KEY), no Pixabay (chave
grátis em PIXABAY_API_KEY), na Wikimedia Commons (fotos livres, sem chave; o crédito vai na
descrição) e, por último, um fundo animado gerado no ffmpeg.
No formato "Real ou IA?", as fotos reais vêm da Commons e as de IA do Cloudflare Workers AI (grátis;
sem credenciais/cloudflare.json cai no Pollinations, que hoje costuma pedir pagamento).
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import random
import re
import shutil
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .. import canais, quiz
from ..nucleo import RAIZ, Agente, Job, py, tem, tem_modulo

VIDEO = {".mp4", ".mov", ".webm", ".mkv", ".m4v"}
COMMONS = "https://commons.wikimedia.org/w/api.php?"
POLLINATIONS = "https://image.pollinations.ai/prompt/"
CABECALHO = {"User-Agent": "EscritorioDark/1.1 (+https://github.com/cauamotta2709-lgtm/escdark; projeto pessoal de videos curtos) python-urllib"}
# A Wikimedia responde 429 a quem pede demais ou sem identificação: um pedido por vez, com intervalo
_TRAVA_WIKI = threading.Lock()
_ULTIMO_WIKI = [0.0]
INTERVALO_WIKI = 1.3
_trava_piper = threading.Lock()  # o piper trava no Windows se rodar várias vezes ao mesmo tempo
PALETAS = [("0x0f0c29", "0x302b63"), ("0x000000", "0x434343"), ("0x200122", "0x6f0000"),
           ("0x141e30", "0x243b55"), ("0x0b0b0b", "0x3a1c71")]


def termos(texto: str) -> set[str]:
    """Palavras sem acento e em minúsculas, para casar 'corações' com 'coracoes.mp4'."""
    sem_acento = unicodedata.normalize("NFKD", texto.lower()).encode("ascii", "ignore").decode()
    return set(re.findall(r"[a-z0-9]+", sem_acento))


def sem_html(texto: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", texto or "")).strip()


def licenca_livre(licenca: str) -> bool:
    """A Commons só aceita licenças livres, mas por garantia recusa uso não comercial (NC),
    sem derivações (ND) e "fair use": vídeo monetizado precisa de licença que permita isso."""
    sigla = licenca.upper()
    return not (re.search(r"\b(NC|ND)\b", sigla) or "FAIR USE" in sigla or "NON-FREE" in sigla)


def pegar(url: str, timeout: int = 120, tentativas: int = 4, cabecalho: dict | None = None) -> bytes:
    """Baixa uma URL. Na Wikimedia espera entre os pedidos; em 429/502/503/504 tenta de novo,
    respeitando o Retry-After e aumentando a pausa (2, 4, 8 s)."""
    cab = cabecalho or CABECALHO
    wiki = "wikimedia.org" in url or "wikipedia.org" in url
    for n in range(tentativas):
        if wiki:
            with _TRAVA_WIKI:
                time.sleep(max(0.0, _ULTIMO_WIKI[0] + INTERVALO_WIKI - time.time()))
                _ULTIMO_WIKI[0] = time.time()
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=cab), timeout=timeout) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code not in (429, 502, 503, 504) or n == tentativas - 1:
                raise
            try:
                espera = float(e.headers.get("Retry-After") or 0)
            except ValueError:
                espera = 0.0
            time.sleep(min(30.0, max(espera, 2.0 * 2 ** n)))
        except (urllib.error.URLError, TimeoutError, ConnectionError):
            if n == tentativas - 1:
                raise
            time.sleep(2.0 * 2 ** n)
    raise RuntimeError("sem resposta")


def baixar(url: str, destino: Path, timeout: int = 120) -> None:
    destino.write_bytes(pegar(url, timeout))


def e_imagem(arquivo: Path) -> bool:
    """Confere pelo começo do arquivo que veio mesmo uma imagem (e não uma página de erro)."""
    with open(arquivo, "rb") as f:
        cab = f.read(12)
    return arquivo.stat().st_size > 5000 and (cab[:3] == b"\xff\xd8\xff" or cab[:4] == b"\x89PNG"
                                              or cab[8:12] == b"WEBP")


class Carregador(Agente):
    chave = "carregador"
    nome = "Carregador"
    cargo = "Gera a narração e baixa os clipes de fundo"
    emoji = "📦"

    def __init__(self, *a, **kw) -> None:
        super().__init__(*a, **kw)
        self.modelo_piper = RAIZ / "vozes" / self.cfg.get("piper_modelo", "pt_BR-faber-medium.onnx")
        opcoes = [v for v, ok in (("edge-tts", tem_modulo("edge_tts") and not self.cfg.get("offline")),
                                  ("piper", tem_modulo("piper") and self.modelo_piper.exists()),
                                  ("espeak-ng", tem("espeak-ng"))) if ok]
        escolhida = self.cfg.get("voz", "auto")  # "auto", "edge-tts", "piper" ou "espeak-ng"
        if escolhida in opcoes:
            opcoes.remove(escolhida)
            opcoes.insert(0, escolhida)
        self.vozes = opcoes  # ordem de tentativa; a trilha muda é o último recurso
        self.voz = opcoes[0] if opcoes else "muda"
        self.motor = self.voz
        self.tele.atualizar(self.chave, motor=self.voz)
        self._cache: dict[str, list] = {}
        self._trava_cache = threading.RLock()

    def duracao(self, arquivo) -> float:
        r = self.rodar(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "csv=p=0", str(arquivo)])
        return float(r.stdout.strip() or 0)

    def narrar(self, frase: str, destino: Path, pausa: float = 0.0, cfg: dict | None = None
               ) -> tuple[str, list]:
        """Narra a frase e devolve (voz usada, [(início, fim, palavra)] quando a voz informa)."""
        for voz in self.vozes:
            try:
                return voz, self._narrar(frase, destino, voz, pausa, cfg or self.cfg)
            except Exception as e:  # ex.: sem internet para o edge-tts: tenta a próxima voz
                self.log(f"voz {voz} falhou ({str(e)[:80]}), tentando a próxima", "aviso")
        return "muda", self._narrar(frase, destino, "muda", pausa, cfg or self.cfg)

    def edge(self, frase: str, destino: Path, cfg: dict) -> list:
        """Voz neural da Microsoft pelo edge-tts, guardando o tempo exato de cada palavra."""
        import edge_tts
        opcoes = {"rate": cfg.get("voz_edge_velocidade", "+10%"),
                  "pitch": cfg.get("voz_edge_tom", "+0Hz")}
        vozes = list(dict.fromkeys([cfg.get("voz_edge", "pt-BR-AntonioNeural"), "pt-BR-AntonioNeural"]))

        async def falar(voz: str) -> list:
            try:  # edge-tts 7+ só manda as palavras se pedir; versões antigas mandam sempre
                com = edge_tts.Communicate(frase, voz, boundary="WordBoundary", **opcoes)
            except TypeError:
                com = edge_tts.Communicate(frase, voz, **opcoes)
            palavras = []
            with open(destino, "wb") as f:
                async for parte in com.stream():
                    if parte["type"] == "audio":
                        f.write(parte["data"])
                    elif parte["type"] == "WordBoundary":
                        ini = parte["offset"] / 1e7  # o edge-tts conta em unidades de 100 ns
                        palavras.append((ini, ini + parte["duration"] / 1e7, parte["text"]))
            return palavras
        for n, voz in enumerate(vozes):  # se a voz do canal sumir do edge-tts, usa o Antonio
            for tentativa in range(3):  # falha de rede passa sozinha: tenta a mesma voz de novo
                try:
                    palavras = asyncio.run(falar(voz))
                    if destino.stat().st_size >= 1000:
                        return palavras
                    raise RuntimeError("o edge-tts não devolveu áudio")
                except Exception as e:
                    erro = e
                    time.sleep(1 + tentativa)
            if n + 1 == len(vozes):
                raise erro
            self.log(f"voz {voz} falhou 3 vezes ({str(erro)[:60]}); esta frase vai com {vozes[n + 1]}",
                     "aviso")
        return []

    def _narrar(self, frase: str, destino: Path, voz: str, pausa: float, cfg: dict) -> list:
        wav, palavras = destino.with_suffix(".wav"), []
        if voz == "piper":
            with _trava_piper:
                self.rodar(py("piper", "-m", str(self.modelo_piper), "-f", str(wav)),
                           entrada=frase.encode("utf-8"))
        elif voz == "edge-tts":
            wav = destino.with_suffix(".mp3")
            palavras = self.edge(frase, wav, cfg)
        elif voz == "espeak-ng":
            self.rodar(["espeak-ng", "-v", "pt-br", "-s", "165", "-w", str(wav), frase])
        else:  # sem TTS instalado: silêncio no tempo de leitura (~2,6 palavras/s)
            seg = max(1.2, len(frase.split()) / 2.6)
            self.rodar(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i",
                        "anullsrc=r=44100:cl=mono", "-t", f"{seg:.2f}", str(wav)])
        pad = ["-af", f"apad=pad_dur={pausa:.2f}"] if pausa > 0 else []  # silêncio para pensar
        self.rodar(["ffmpeg", "-y", "-v", "error", "-i", str(wav), *pad, "-ar", "44100", "-ac", "1",
                    str(destino)])
        return palavras

    # ---------- imagens: um clipe por frase ----------
    def clipes_locais(self) -> list[Path]:
        pasta = RAIZ / "clipes"
        return sorted(p for p in pasta.glob("*") if p.suffix.lower() in VIDEO) if pasta.exists() else []

    def clipe_local(self, palavras: set[str], usados: set, combinar: bool) -> Path | None:
        """Um clipe da pasta clipes/ cujo nome tenha palavra da frase (ou qualquer um, se combinar=False)."""
        todos = self.clipes_locais()
        livres = [p for p in todos if str(p) not in usados]
        if combinar:
            livres = [p for p in livres if palavras & termos(p.stem)]
        elif not livres:
            livres = todos  # acabaram os inéditos: repetir um clipe ainda é melhor que fundo liso
        return random.choice(livres) if livres else None

    def pexels(self, busca: str, pt: bool = False) -> list[dict]:
        """Vídeos verticais do Pexels para a busca (guarda em memória para gastar menos cota)."""
        chave = os.environ.get("PEXELS_API_KEY")
        if not chave or self.cfg.get("offline"):
            return []
        with self._trava_cache:
            if (busca, pt) in self._cache:
                return self._cache[(busca, pt)]
        req = urllib.request.Request(
            "https://api.pexels.com/videos/search?" + urllib.parse.urlencode(
                {"query": busca, "orientation": "portrait", "per_page": 15, "size": "medium",
                 **({"locale": "pt-BR"} if pt else {})}),
            headers={"Authorization": chave, "User-Agent": "escritorio-virtual"})
        with urllib.request.urlopen(req, timeout=30) as r:
            videos = json.loads(r.read()).get("videos", [])
        with self._trava_cache:
            self._cache[(busca, pt)] = videos
        return videos

    def clipe_banco(self, fonte, busca: str, usados: set, destino: Path, vertical: bool,
                    pt: bool = False) -> bool:
        """Baixa o primeiro vídeo ainda não usado do banco grátis (Pexels ou Pixabay)."""
        for v in fonte(busca, pt):
            arqs = [f for f in v.get("video_files", []) if f.get("height", 0) >= (1280 if vertical else 720)
                    and (f.get("width", 0) < f.get("height", 0) or not vertical)]
            if not arqs or f"pexels:{v['id']}" in usados:
                continue
            usados.add(f"pexels:{v['id']}")
            req = urllib.request.Request(min(arqs, key=lambda f: f["height"])["link"],
                                         headers={"User-Agent": "escritorio-virtual"})
            with urllib.request.urlopen(req, timeout=120) as r, open(destino, "wb") as f:
                shutil.copyfileobj(r, f)
            return True
        return False

    def pixabay(self, busca: str, pt: bool = False) -> list[dict]:
        """Vídeos do Pixabay (chave grátis em PIXABAY_API_KEY), no mesmo formato usado pelo Pexels."""
        chave = os.environ.get("PIXABAY_API_KEY")
        if not chave or self.cfg.get("offline"):
            return []
        with self._trava_cache:
            if ("pixabay", busca, pt) in self._cache:
                return self._cache[("pixabay", busca, pt)]
        url = "https://pixabay.com/api/videos/?" + urllib.parse.urlencode(
            {"key": chave, "q": busca[:100], "per_page": 20, "safesearch": "true",
             "lang": "pt" if pt else "en"})
        with urllib.request.urlopen(urllib.request.Request(
                url, headers={"User-Agent": "escritorio-virtual"}), timeout=30) as r:
            hits = json.loads(r.read()).get("hits", [])
        videos = [{"id": f"pixabay{h['id']}", "video_files": [
            {"width": v.get("width", 0), "height": v.get("height", 0), "link": v["url"]}
            for v in h.get("videos", {}).values() if v.get("url")]} for h in hits]
        with self._trava_cache:
            self._cache[("pixabay", busca, pt)] = videos
        return videos

    def commons(self, busca: str, usados: set, destino: Path) -> str | None:
        """Foto livre da Wikimedia Commons. Devolve o crédito (autor e licença) para a descrição."""
        if self.cfg.get("offline"):
            return None
        # "File:Nome.jpg" pega exatamente aquele arquivo; qualquer outro texto vira busca
        alvo = {"titles": busca} if busca.startswith("File:") else {
            "generator": "search", "gsrsearch": f"{busca} filetype:bitmap", "gsrnamespace": 6,
            "gsrlimit": 12}
        url = COMMONS + urllib.parse.urlencode({
            "action": "query", "format": "json", "formatversion": 2, **alvo,
            "prop": "imageinfo", "iiprop": "url|size|mime|extmetadata", "iiurlheight": 1920,
            "iiextmetadatafilter": "Artist|LicenseShortName"})
        with self._trava_cache:
            paginas = self._cache.get(("commons", url))
        if paginas is None:
            paginas = json.loads(pegar(url, 30)).get("query", {}).get("pages", [])
            with self._trava_cache:
                self._cache[("commons", url)] = paginas
        for pag in sorted(paginas, key=lambda x: x.get("index", 0)):
            info = (pag.get("imageinfo") or [{}])[0]
            if info.get("mime") not in ("image/jpeg", "image/png") or info.get("width", 0) < 600 \
                    or info.get("height", 0) < 500:
                continue
            meta = info.get("extmetadata", {})
            autor = sem_html(meta.get("Artist", {}).get("value", "")) or "autor desconhecido"
            licenca = sem_html(meta.get("LicenseShortName", {}).get("value", ""))
            if not licenca_livre(licenca):
                self.log(f"pulei {pag['title'][5:45]}: licença {licenca}", "aviso")
                continue
            with self._trava_cache:
                if pag["title"] in usados:
                    continue
                usados.add(pag["title"])
            baixar(info.get("thumburl") or info["url"], destino)
            if not e_imagem(destino):
                continue
            return f"{autor} ({licenca}), via Wikimedia Commons" if licenca else f"{autor}, via Wikimedia Commons"
        return None

    def cloudflare(self, prompt: str, destino: Path, w: int, h: int, semente: int | None) -> bool:
        """Imagem no Cloudflare Workers AI, cota grátis de ~150 imagens por dia.
        Só roda se existir credenciais/cloudflare.json com {"account_id": "...", "api_token": "..."}.
        Tenta o flux-1-schnell (JSON com a imagem em base64) e, se ele recusar, o
        stable-diffusion-xl-lightning (devolve a imagem direto). Falha devolve False."""
        arq = RAIZ / "credenciais" / "cloudflare.json"
        if not arq.exists() or getattr(self, "_cf_parou", False):
            return False
        try:
            cred = json.loads(arq.read_text(encoding="utf-8-sig"))
            conta, token = cred["account_id"].strip(), cred["api_token"].strip()
        except Exception as e:
            self._cf_parou = True
            self.log(f"credenciais/cloudflare.json ilegível ({str(e)[:60]}); sem Cloudflare", "aviso")
            return False
        escala = 1024 / max(w, h)
        lw, lh = max(256, round(w * escala / 8) * 8), max(256, round(h * escala / 8) * 8)
        modelos = [
            ("@cf/black-forest-labs/flux-1-schnell", {"prompt": prompt[:2000], "steps": 6}),
            ("@cf/bytedance/stable-diffusion-xl-lightning",
             {"prompt": prompt[:2000], "width": lw, "height": lh, "num_steps": 8,
              "seed": semente or random.randint(1, 10**6)}),
        ]
        ultimo = ""
        for modelo, corpo in modelos:
            url = f"https://api.cloudflare.com/client/v4/accounts/{conta}/ai/run/{modelo}"
            req = urllib.request.Request(url, data=json.dumps(corpo).encode(), headers={
                **CABECALHO, "Authorization": f"Bearer {token}", "Content-Type": "application/json"})
            for n in range(3):
                try:
                    with urllib.request.urlopen(req, timeout=120) as r:
                        tipo = r.headers.get("Content-Type", "")
                        dados = r.read()
                    bruto = destino.with_suffix(".cf.jpg")
                    if tipo.startswith("image/"):
                        bruto.write_bytes(dados)
                    else:
                        bruto.write_bytes(base64.b64decode(json.loads(dados)["result"]["image"]))
                    # o modelo devolve quadrado ou menor: corta e ajusta para a proporção pedida
                    self.rodar(["ffmpeg", "-y", "-v", "error", "-i", str(bruto), "-vf",
                                f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h}",
                                "-q:v", "2", str(destino)])
                    bruto.unlink(missing_ok=True)
                    if e_imagem(destino):
                        self._ia_usada = "Cloudflare Workers AI"
                        return True
                    ultimo = f"{modelo}: resposta sem imagem"
                    break
                except urllib.error.HTTPError as e:
                    try:
                        detalhe = e.read().decode("utf-8", "replace")[:240].replace("\n", " ")
                    except Exception:
                        detalhe = ""
                    ultimo = f"{modelo.split('/')[-1]}: HTTP {e.code} {detalhe}"
                    if e.code in (401, 403):  # token errado ou sem permissão: não adianta insistir
                        self._cf_parou = True
                        self.log(f"Cloudflare recusou o token ({ultimo}); sem Cloudflare neste vídeo", "aviso")
                        return False
                    if e.code == 429 or e.code >= 500:  # muitos pedidos juntos ou cota: espera e repete
                        if "limit" in detalhe.lower() and "neuron" in detalhe.lower():
                            self._cf_parou = True
                            self.log("cota diária de imagens do Cloudflare acabou", "aviso")
                            return False
                        time.sleep(2.5 * (n + 1))
                        continue
                    break  # 400/404: o modelo recusou o pedido; tenta o próximo modelo
                except Exception as e:
                    ultimo = f"{modelo.split('/')[-1]}: {str(e)[:120]}"
                    time.sleep(1.5)
        self.log(f"Cloudflare falhou ({ultimo})", "aviso")
        return False

    def credito_ia(self) -> str:
        return f"Imagens de IA: {getattr(self, '_ia_usada', 'Cloudflare Workers AI')}"

    def imagem_ia(self, prompt: str, destino: Path, tamanho: tuple[int, int] | None = None,
                  estilo: str = "realistic photo, natural light", semente: int | None = None) -> bool:
        """Imagem criada por IA: Cloudflare Workers AI e, só se `usar_pollinations` estiver ligado no
        config.json, o Pollinations como reserva (hoje ele costuma responder 402 Pagamento exigido)."""
        if self.cfg.get("offline"):
            return False
        # no quiz, o mesmo formato de uma foto comum (deitada ou quadrada): se a imagem de IA
        # ocupasse a tela inteira e a real não, daria para adivinhar a resposta pelo formato
        w, h = tamanho or random.choice([(1500, 1000), (1440, 1080), (1200, 1200)])
        if self.cloudflare(prompt if not estilo else f"{prompt}, {estilo}", destino, w, h, semente):
            return True
        if not self.cfg.get("usar_pollinations") or getattr(self, "_poli_parou", False):
            return False
        url = POLLINATIONS + urllib.parse.quote(f"{prompt}, {estilo}" if estilo else prompt) + "?" + \
            urllib.parse.urlencode({"width": w, "height": h, "nologo": "true", "model": "flux",
                                    "seed": semente or random.randint(1, 10**6)})
        try:
            baixar(url, destino, timeout=180)
        except urllib.error.HTTPError as e:
            if e.code == 402:
                self._poli_parou = True
                self.log("Pollinations passou a cobrar (402); desligado até fechar o escritório", "aviso")
                return False
            raise
        if e_imagem(destino):
            self._ia_usada = "Pollinations.ai"
            return True
        return False

    def imagens_roteiro(self, job: Job, cfg: dict) -> list[tuple[str, str]]:
        """Uma imagem de IA em pé (tela cheia) para cada frase do roteiro, no estilo do canal.
        Se o Pollinations falhar, tenta foto livre da Commons e depois o caminho normal."""
        roteiro = job.arquivos["roteiro"]
        pedidos = list(job.arquivos.get("imagens") or roteiro.get("imagens") or [])  # já alinhadas
        pedidos = [p or {"ia": f, "busca": job.tema} for p, f in zip(pedidos, job.roteiro)]
        pedidos += [{"ia": f, "busca": job.tema} for f in job.roteiro[len(pedidos):]]
        w, h = cfg.get("resolucao", [1080, 1920])
        estilo = cfg.get("estilo_imagem", "cinematic, highly detailed, dramatic lighting, vertical composition")
        semente = random.randint(1, 10**6)  # a mesma em todas as cenas: o vídeo fica com um visual só
        usados: set = set()

        def buscar(i: int) -> tuple[str, str]:
            pedido = pedidos[i] if isinstance(pedidos[i], dict) else {"ia": pedidos[i]}
            destino = job.pasta / f"cena_{i:02d}.jpg"
            if pedido.get("ia"):
                try:
                    if self.imagem_ia(pedido["ia"], destino, (w, h), estilo, semente):
                        return str(destino), "IA"
                    alt = pedido.get("busca") or job.tema  # outro pedido: o assunto do vídeo, mais simples
                    if alt and alt != pedido["ia"] and self.imagem_ia(
                            f"{alt}", destino, (w, h), estilo, semente):
                        return str(destino), "IA"
                except Exception as e:
                    self.log(f"imagem de IA falhou na cena {i + 1} ({str(e)[:60]})", "aviso")
            busca = pedido.get("busca") or " ".join(str(pedido.get("ia", "")).split()[:3]) or job.tema
            try:
                credito = self.commons(busca, usados, destino)
            except Exception as e:
                credito = None
                self.log(f"Commons falhou para '{busca}' ({str(e)[:60]})", "aviso")
            if credito:
                with self._trava_cache:
                    job.arquivos.setdefault("creditos", []).append(credito)
                return str(destino), "Commons"
            return self.cena(i, job.roteiro[i], busca, job, usados)

        self.tarefa(f"criando {len(job.roteiro)} imagens de IA no estilo do canal (job {job.id})")
        with ThreadPoolExecutor(max_workers=4) as ex:
            cenas = list(ex.map(buscar, range(len(job.roteiro))))
        if any(o == "IA" for _, o in cenas):
            job.arquivos.setdefault("creditos", []).append(self.credito_ia())
        return cenas

    def imagens_quiz(self, job: Job) -> list[tuple[str, str]]:
        """Uma imagem por rodada do Real ou IA. Se a fonte certa falhar, usa a outra e troca a
        resposta (e a frase da revelação), para o vídeo nunca mentir para quem assiste."""
        itens, usados = job.arquivos["quiz"], set()
        creditos = job.arquivos.setdefault("creditos", [])

        def real(item: dict, destino: Path) -> bool:
            credito = None
            for busca in [b for b in (item.get("arquivo"), item["foto"]) if b]:
                try:
                    credito = self.commons(busca, usados, destino)
                except Exception as e:
                    self.log(f"Commons falhou para '{busca}' ({str(e)[:60]})", "aviso")
                if credito:
                    break
            if credito:
                creditos.append(f"{item['foto']}: {credito}")
            return bool(credito)

        def ia(item: dict, destino: Path) -> bool:
            try:
                return self.imagem_ia(item["ia"], destino)
            except Exception as e:
                self.log(f"imagem de IA falhou ({str(e)[:60]})", "aviso")
                return False

        def buscar(n: int) -> tuple[str, str]:
            item = itens[n]
            fontes = [("real", real), ("ia", ia)]
            if item["resposta"] == "ia":
                fontes.reverse()
            for resposta, fonte in fontes:
                destino = job.pasta / f"quiz_{n}_{resposta}.jpg"
                if fonte(item, destino):
                    if resposta != item["resposta"]:
                        self.log(f"rodada {n + 1}: sem imagem {item['resposta']}, virou {resposta}", "aviso")
                        item["resposta"] = resposta
                        job.roteiro[item["r"]] = quiz.revelacao(item)
                    return str(destino), "Commons" if resposta == "real" else "IA"
            return self.fundo_gerado(job), "gerado"

        self.tarefa(f"buscando fotos reais e criando fotos de IA (job {job.id})")
        with ThreadPoolExecutor(max_workers=4) as ex:
            por_rodada = list(ex.map(buscar, range(len(itens))))
        # rodada sem foto nenhuma (Commons e IA falharam) sai do vídeo: perguntar
        # "real ou IA?" sobre um fundo genérico e revelar uma resposta seria mentir
        boas = [(item, img) for item, img in zip(itens, por_rodada) if img[1] != "gerado"]
        if not boas:
            raise RuntimeError("nenhuma foto do desafio chegou (Commons e IA falharam)")
        if len(boas) < len(itens):
            self.log(f"{len(itens) - len(boas)} rodada(s) sem foto saíram do vídeo (job {job.id})", "aviso")
            roteiro = [job.roteiro[0]]
            for item, _ in boas:
                frases = job.roteiro[item["q"]], job.roteiro[item["r"]]
                item["q"], item["r"] = len(roteiro), len(roteiro) + 1
                roteiro += frases
            job.roteiro = roteiro + [job.roteiro[-1]]
            fora = {item["foto"] for item in itens} - {item["foto"] for item, _ in boas}
            for reserva in job.arquivos.get("usar") or []:  # o que não apareceu não conta como usado
                reserva[1] = [k for k in reserva[1] if k not in fora]
            itens = job.arquivos["quiz"] = [item for item, _ in boas]
            por_rodada = [img for _, img in boas]
        # cada frase mostra a imagem da sua rodada; o gancho mostra a 1ª e o final, a última
        cenas = [por_rodada[0]] * len(job.roteiro)
        for item, img in zip(itens, por_rodada):
            cenas[item["q"]] = cenas[item["r"]] = img
        cenas[-1] = por_rodada[-1]
        if any(o == "IA" for _, o in por_rodada):
            creditos.append(self.credito_ia())
        return cenas

    def mascote(self, job: Job, cfg: dict) -> str | None:
        """Mascote do canal: criado uma vez no Pollinations (mesma semente) e guardado em
        canais/<canal>/mascote.jpg. Pode trocar o arquivo por um desenho seu."""
        if not job.canal or not cfg.get("mascote_prompt"):
            return None
        arq = canais.pasta(job.canal) / "mascote.jpg"
        with self._trava_cache:
            if not arq.exists():
                w, h = cfg.get("resolucao", [1080, 1920])
                try:
                    if not self.imagem_ia(cfg["mascote_prompt"], arq, (w, h), "",
                                          cfg.get("mascote_semente", 7)):
                        arq.unlink(missing_ok=True)
                except Exception as e:
                    self.log(f"não deu para criar o mascote ({str(e)[:60]})", "aviso")
                    arq.unlink(missing_ok=True)
        return str(arq) if arq.exists() else None

    def imagens_perguntas(self, job: Job, cfg: dict) -> list[tuple[str, str]]:
        """Quiz de perguntas: o mascote do canal no gancho e no final, e uma ilustração do tema
        de cada pergunta (que não entrega a resposta) na parte de cima da tela."""
        itens = job.arquivos["perguntas"]
        estilo = cfg.get("estilo_imagem", "")
        semente = random.randint(1, 10**6)

        def buscar(n: int) -> tuple[str, str]:
            destino = job.pasta / f"pergunta_{n}.jpg"
            try:
                if self.imagem_ia(itens[n]["ia"], destino, (1080, 640), estilo, semente):
                    return str(destino), "IA"
            except Exception as e:
                self.log(f"imagem de IA falhou na pergunta {n + 1} ({str(e)[:60]})", "aviso")
            # sem a ilustração, o mascote cobre a cena (e o Editor usa a tela dividida)
            return (mascote, "mascote_reserva") if mascote else (self.fundo_gerado(job), "gerado")

        self.tarefa(f"criando o mascote e {len(itens)} ilustrações (job {job.id})")
        mascote = self.mascote(job, cfg)
        with ThreadPoolExecutor(max_workers=4) as ex:
            por_pergunta = list(ex.map(buscar, range(len(itens))))
        abertura = (mascote, "mascote") if mascote else por_pergunta[0]
        cenas = [abertura] * len(job.roteiro)
        for item, img in zip(itens, por_pergunta):
            cenas[item["q"]] = cenas[item["r"]] = img
        if any(o == "IA" for _, o in cenas) or mascote:
            job.arquivos.setdefault("creditos", []).append(self.credito_ia())
        return cenas

    def reaproveitar(self, cenas: list[tuple[str, str]], job: Job) -> list[tuple[str, str]]:
        """Cena que ficou sem imagem usa a imagem da cena mais próxima do mesmo vídeo. A tela dividida
        com o vídeo de fundo só sobra para quando NENHUMA cena do vídeo conseguiu imagem."""
        boas = [i for i, (_, o) in enumerate(cenas) if o not in ("gerado", "mascote_reserva", "mascote")]
        faltam = [i for i, (_, o) in enumerate(cenas) if o in ("gerado", "mascote_reserva")]
        if not boas or not faltam:
            return cenas
        cenas = list(cenas)
        for i in faltam:
            cenas[i] = cenas[min(boas, key=lambda k: (abs(k - i), k))]
        self.log(f"{len(faltam)} cena(s) sem imagem reaproveitaram a imagem de outra cena (job {job.id})", "aviso")
        return cenas

    def fundo_gerado(self, job: Job) -> str:
        fundo = job.pasta / "fundo.mp4"
        with self._trava_cache:  # um fundo gerado por vídeo, criado uma vez só
            if not fundo.exists():
                c0, c1 = random.choice(PALETAS)
                self.rodar(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i",
                            f"gradients=s=720x1280:c0={c0}:c1={c1}:speed=0.015:r=30", "-t", "12",
                            "-c:v", "libx264", "-preset", "veryfast", "-crf", "14", "-pix_fmt", "yuv420p",
                            str(fundo)])
        return str(fundo)

    def cena(self, i: int, frase: str, busca: str, job: Job, usados: set) -> tuple[str, str]:
        pts = job.arquivos.get("buscas_pt") or []
        pt = pts[i] if i < len(pts) else False
        """Clipe da frase i. Ordem: sua pasta (nome combina) > Pexels > Pixabay > sua pasta > gerado."""
        palavras = termos(f"{busca} {frase}") - {"para", "como", "mais"}
        with self._trava_cache:
            local = self.clipe_local(palavras, usados, combinar=True)
            if local:
                usados.add(str(local))
        if local:
            return str(local), "sua pasta"
        destino = job.pasta / f"cena_{i:02d}.mp4"
        # Pexels tem vídeo vertical; o Pixabay tem mais variedade, quase tudo horizontal (o Editor recorta)
        for nome, fonte, vertical in (("pexels", self.pexels, True), ("pixabay", self.pixabay, False)):
            for b in dict.fromkeys([busca, job.tema]):  # tenta a busca da frase, depois o tema
                try:
                    if b and self.clipe_banco(fonte, b, usados, destino, vertical,
                                              pt if b == busca else True):
                        return str(destino), nome
                except Exception as e:
                    self.log(f"{nome} falhou para '{b}' ({str(e)[:60]})", "aviso")
                    break
        foto = job.pasta / f"cena_{i:02d}.jpg"
        for b in dict.fromkeys([busca, job.tema]):  # foto livre da Commons, com crédito na descrição
            try:
                credito = b and self.commons(b, usados, foto)
            except Exception as e:
                self.log(f"Commons falhou para '{b}' ({str(e)[:60]})", "aviso")
                break
            if credito:
                with self._trava_cache:
                    job.arquivos.setdefault("creditos", []).append(credito)
                return str(foto), "Commons"
        with self._trava_cache:
            local = self.clipe_local(palavras, usados, combinar=False)
            if local:
                usados.add(str(local))
        if local:
            return str(local), "sua pasta"
        return self.fundo_gerado(job), "gerado"

    def efeitos(self, job: Job, narracao: Path, tempos: list, pausas: list, cfg: dict) -> Path:
        """Efeitos sonoros sintetizados no ffmpeg (sem arquivo, sem direito autoral): no desafio,
        um tique em cada número da contagem e um 'ding' na resposta; nos outros vídeos, um
        'whoosh' baixinho em cada troca de imagem, que dá ritmo como nos canais de referência."""
        inicios = [sum(tempos[:i]) for i in range(len(tempos))]
        tique = "0.45*sin(2*PI*1500*t)*exp(-60*t)"
        ding = "0.35*sin(2*PI*1046*t)*exp(-7*t)+0.25*sin(2*PI*1568*t)*exp(-7*t)"
        whoosh = "0.22*(2*random(0)-1)*sin(PI*t/0.32)*sin(PI*t/0.32)"
        eventos = []
        for item in job.arquivos.get("quiz") or job.arquivos.get("perguntas") or []:
            q, pausa = item["q"], pausas[item["q"]]
            fim_fala = inicios[q] + tempos[q] - pausa
            eventos += [(tique, 0.12, fim_fala + k * pausa / 3) for k in range(3)]
            eventos.append((ding, 0.6, inicios[item["r"]]))
        if not (job.arquivos.get("quiz") or job.arquivos.get("perguntas")) \
                and cfg.get("efeito_transicao", True):
            eventos += [(whoosh, 0.32, max(0.0, t - 0.12)) for t in inicios[1:]]
        if not eventos:
            return narracao
        filtro = {whoosh: ",highpass=f=700,lowpass=f=7000"}
        grafo = [f"aevalsrc='{expr}':s=44100:d={d}{filtro.get(expr, '')},adelay={int(t * 1000)}[e{i}]"
                 for i, (expr, d, t) in enumerate(eventos)]
        grafo.append("[0:a]" + "".join(f"[e{i}]" for i in range(len(eventos)))
                     + f"amix=inputs={len(eventos) + 1}:duration=first:normalize=0[a]")
        saida = job.pasta / "narracao_efeitos.m4a"
        self.rodar(["ffmpeg", "-y", "-v", "error", "-i", str(narracao), "-filter_complex", ";".join(grafo),
                    "-map", "[a]", "-c:a", "aac", "-b:a", "128k", str(saida)])
        return saida

    def narrar_e_medir(self, i: int, frase: str, job: Job, pausa: float) -> tuple:
        arq = job.pasta / f"voz_{i:02d}.m4a"
        voz, palavras = self.narrar(frase, arq, pausa, self.conf(job))
        return arq, self.duracao(arq), voz, palavras

    def completar_duracao(self, partes: list, cfg: dict) -> list:
        """O Programa de Recompensas do TikTok só conta vídeos com mais de 1 minuto. Se a fala
        ficou um pouco curta, espalha pausas pequenas entre as frases (até 0,45 s cada)."""
        minimo = cfg.get("duracao_minima_s", 0)
        total = sum(p[1] for p in partes)
        if not minimo or total >= minimo or len(partes) < 2:
            return partes
        extra = min((minimo - total) / (len(partes) - 1), 0.45)
        novas = []
        for i, (arq, dur, voz, palavras) in enumerate(partes):
            if i < len(partes) - 1:
                saida = arq.with_name(arq.stem + "_p.m4a")
                self.rodar(["ffmpeg", "-y", "-v", "error", "-i", str(arq), "-af",
                            f"apad=pad_dur={extra:.3f}", str(saida)])
                arq, dur = saida, self.duracao(saida)
            novas.append((arq, dur, voz, palavras))
        total2 = sum(p[1] for p in novas)
        aviso = "" if total2 >= minimo else f"; ainda abaixo de {minimo:.0f}s: o roteiro precisa de mais frases"
        self.log(f"fala com {total:.1f}s; pausas entre frases levaram a {total2:.1f}s{aviso}",
                 "aviso" if aviso else "info")
        return novas

    def processar(self, job: Job) -> Job:
        cfg = self.conf(job)
        pausas = [0.0] * len(job.roteiro)
        if job.arquivos.get("perguntas"):
            cenas = self.imagens_perguntas(job, cfg)
            for item in job.arquivos["perguntas"]:
                pausas[item["q"]] = cfg.get("quiz_pausa_s", 3.0)
            self.tarefa(f"narrando {len(job.roteiro)} frases (job {job.id})")
            with ThreadPoolExecutor(max_workers=self.cfg.get("paralelo_carregador", 4)) as ex:
                partes = list(ex.map(lambda f: self.narrar_e_medir(f[0], f[1], job, pausas[f[0]]),
                                     enumerate(job.roteiro)))
        elif job.arquivos.get("quiz"):
            # as imagens vêm antes da narração: se uma resposta mudar, a frase muda junto
            cenas = self.imagens_quiz(job)
            pausas = [0.0] * len(job.roteiro)  # a lista de frases pode ter encolhido
            for item in job.arquivos["quiz"]:
                pausas[item["q"]] = cfg.get("quiz_pausa_s", 1.8)
            self.tarefa(f"narrando {len(job.roteiro)} frases (job {job.id})")
            with ThreadPoolExecutor(max_workers=self.cfg.get("paralelo_carregador", 4)) as ex:
                partes = list(ex.map(lambda f: self.narrar_e_medir(f[0], f[1], job, pausas[f[0]]),
                                     enumerate(job.roteiro)))
        elif job.arquivos.get("roteiro"):
            # roteiro do banco do canal: imagens de IA e narração ao mesmo tempo; um respiro
            # curto entre as frases (pausa_frases_s), maior no estilo documentário
            pausa = cfg.get("pausa_frases_s", 0.12)
            pausas = [pausa] * (len(job.roteiro) - 1) + [0.0]
            with ThreadPoolExecutor(max_workers=2) as ex:
                cenas_f = ex.submit(self.imagens_roteiro, job, cfg)
                self.tarefa(f"narrando {len(job.roteiro)} frases e criando as imagens (job {job.id})")
                with ThreadPoolExecutor(max_workers=self.cfg.get("paralelo_carregador", 4)) as ex2:
                    partes = list(ex2.map(lambda f: self.narrar_e_medir(f[0], f[1], job, pausas[f[0]]),
                                          enumerate(job.roteiro)))
                cenas = cenas_f.result()
        else:
            # narração e imagens de todas as frases ao mesmo tempo: espera só a tarefa mais lenta
            buscas = job.buscas or [job.tema] * len(job.roteiro)
            self.tarefa(f"narrando {len(job.roteiro)} frases e buscando uma imagem para cada (job {job.id})")
            usados: set = set()
            with ThreadPoolExecutor(max_workers=self.cfg.get("paralelo_carregador", 4)) as ex:
                cenas_f = [ex.submit(self.cena, i, f, b, job, usados)
                           for i, (f, b) in enumerate(zip(job.roteiro, buscas))]
                partes = list(ex.map(lambda f: self.narrar_e_medir(f[0], f[1], job, 0.0),
                                     enumerate(job.roteiro)))
                cenas = [c.result() for c in cenas_f]
        cenas = self.reaproveitar(cenas, job)
        partes = self.completar_duracao(partes, cfg)
        lista = job.pasta / "vozes.txt"
        lista.write_text("".join(f"file '{p[0].name}'\n" for p in partes), encoding="utf-8")
        narracao = job.pasta / "narracao.m4a"
        self.rodar(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lista),
                    "-c:a", "aac", "-b:a", "128k", str(narracao)])
        tempos, vozes = [p[1] for p in partes], {p[2] for p in partes}
        total = sum(tempos)
        narracao = self.efeitos(job, narracao, tempos, pausas, cfg)
        voz = self.voz if vozes == {self.voz} else "muda" if vozes == {"muda"} else "mista"
        origens = {o: sum(1 for _, x in cenas if x == o) for o in dict.fromkeys(x for _, x in cenas)}
        self.log(f"narração ({voz}) com {total:.1f}s; imagens: "
                 + ", ".join(f"{n} {o}" for o, n in origens.items()))
        # tempo de cada palavra no vídeo inteiro (só quando todas as frases vieram do edge-tts)
        palavras, inicio = [], 0.0
        for _, dur, _, ps in partes:
            palavras += [(inicio + a, inicio + b, w) for a, b, w in ps]
            inicio += dur
        completo = all(p[3] for p in partes)
        # como o Editor mostra cada cena: imagem de IA em pé ocupa a tela com zoom lento; foto
        # comum fica inteira sobre ela mesma desfocada; vídeo é recortado para vertical
        perguntas_idx = {i for p in job.arquivos.get("perguntas") or [] for i in (p["q"], p["r"])}
        modos = ["clipe" if Path(c).suffix.lower() in VIDEO else  # inclusive o fundo gerado
                 "topo" if i in perguntas_idx and o not in ("mascote", "mascote_reserva") else
                 "cheia" if o in ("mascote", "mascote_reserva") or (o == "IA" and job.arquivos.get("roteiro"))
                 else "foto"
                 for i, (c, o) in enumerate(cenas)]
        job.arquivos.update(narracao=str(narracao), cenas=[c for c, _ in cenas], duracao=total,
                            voz=voz, tempos=tempos, pausas=pausas, cenas_modo=modos,
                            cenas_origem=[o for _, o in cenas],
                            palavras=palavras if completo else [])
        return job
