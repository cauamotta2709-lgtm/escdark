# Escritório virtual dos agentes

Cinco agentes trabalham em linha para produzir vídeos curtos verticais para cinco canais dark,
cada um com o seu nicho, e um painel no navegador mostra cada um trabalhando em tempo real com o
consumo de CPU, RAM, tokens e custo. Tudo usa ferramentas gratuitas e locais, então o custo é R$ 0,00.

> **Desde a versão 2026.11.15.1 o escritório produz um canal só: Laboratório Otaku** (veja a seção
> "Laboratório Otaku" no fim). Os canais antigos continuam guardados em `canais/` e podem ser religados
> pondo o nome da pasta em `canais_ativos` no config.json.

| Agente | O que faz | Ferramenta grátis |
|---|---|---|
| Olheiro | Reveza os canais e monta o roteiro de cada um (roteiro checado, quiz ou "Real ou IA?") | bancos dos canais, yt-dlp, Wikipédia, Ollama |
| Carregador | Gera a narração, os efeitos sonoros e busca uma imagem para cada frase | edge-tts (voz neural), Wikimedia Commons, Pollinations, Pexels |
| Legendador | Legendas palavra por palavra no tempo da fala, textos do desafio, descrição e hashtags | tempos do edge-tts, faster-whisper, Ollama |
| Editor | Monta o vídeo 1080x1920 com zoom, trilha e legendas numa única passada | ffmpeg |
| Postador | Publica no YouTube Shorts, TikTok e Instagram Reels | APIs oficiais e gratuitas |

O Editor usa o chip de vídeo do PC quando existe (Intel, NVIDIA ou AMD), que codifica bem mais
rápido que o processador, e nesse caso trabalham dois Editores em paralelo (`"copias": {"editor": "auto"}`).
O Carregador narra todas as frases e busca o fundo ao mesmo tempo.

O Legendador vem antes do Editor de propósito: assim o vídeo é renderizado uma vez só, já
com legenda, o que corta o tempo de render pela metade. Cada agente roda em paralelo na sua
thread, então enquanto o Editor renderiza o vídeo 1, o Carregador já narra o vídeo 2.

## Passo a passo no Windows

1. Baixe `escritorio-virtual.zip` e extraia numa pasta, por exemplo `Documentos\escritorio-virtual`.
2. Dê dois cliques em `instalar.bat`. Ele instala Python, ffmpeg e Ollama pelo winget, as
   bibliotecas grátis e a voz em português. Se ele avisar que instalou programas novos, feche a
   janela e rode `instalar.bat` de novo uma vez.
3. Dê dois cliques em `criar_atalho.bat` (uma vez só). Aparece o atalho "Escritorio Dark" na
   área de trabalho. Abra por ele: o painel abre numa janela própria, como um aplicativo, e você
   vê os agentes trabalhando. Prefere numa aba do navegador? Rode `iniciar.bat --aba` ou abra
   http://127.0.0.1:8765 (se essa porta estiver ocupada por outro programa, ele usa a próxima livre e mostra o endereço na janela preta). Fechar o painel não para os agentes; para parar, feche a janela preta
   minimizada na barra de tarefas. Os vídeos ficam em
   `canais\<canal>\prontos\`, cada um com `video.mp4`, `descricao.txt` (o texto para colar ao
   postar) e `post.json`.
4. Assista aos primeiros vídeos. Cada canal se ajusta no seu `canais\<canal>\canal.json`
   (bloco de notas serve); o `config.json` vale para todos.
5. Para ligar a postagem, siga "Ligar a postagem automática" abaixo. Até lá nada é publicado.
6. Para rodar sozinho todo dia: abra um terminal na pasta e rode
   `python escritorio_virtual.py --sempre`, deixando o PC ligado.

No Linux ou macOS, troque os passos 2 e 3 por `./instalar.sh` e `python3 escritorio_virtual.py`.

Outros comandos úteis:

```
python escritorio_virtual.py --canal quiz-desafios  # só um canal
python escritorio_virtual.py --canal espaco-universo --videos 3
python escritorio_virtual.py --videos 1 --offline   # teste rápido sem internet
python escritorio_virtual.py --porta 9000           # outra porta para o painel
```

Sem nada instalado além do Python e do ffmpeg, ele já funciona: usa um banco local de
referências (`referencias.json`), narração muda no tempo de leitura e fundo animado gerado.
Cada ferramenta instalada liga um recurso a mais sozinha, e se uma falhar (sem internet, por
exemplo) o agente usa a próxima opção em vez de parar. O painel mostra o "motor" de cada agente.

## Os canais (um por nicho)

Cada pasta em `canais\` é um canal. A cada rodada o Olheiro faz um vídeo para cada canal
ativo (`videos_por_canal` no `config.json`). O painel mostra quantos roteiros cada canal ainda
tem e quantos vídeos já saíram.

| Pasta | Nome sugerido | Formato | Voz |
|---|---|---|---|
| `animais-sobrevivencia` | Bicho Extremo | roteiro: "você não duraria 1 dia sendo um..." | Thalita, animada |
| `espaco-universo` | Órbita Curiosa | roteiro: segredos do espaço, tom de documentário | Antonio, grave e lenta |
| `curiosidades-cotidiano` | Ninguém Te Explicou | roteiro: o porquê das coisas do dia a dia | Francisca, de conversa |
| `quiz-desafios` | Miau Quiz | perguntas: quiz de 4 alternativas com o gato apresentador | Francisca, de game show |
| `real-ou-ia` | Olho de Pixel | real_ou_ia: foto real ou de IA? | Antonio, provocador |

Cada pasta tem:

- `PERFIL.md`: nome e @ sugeridos, bio, hashtags, como criar a conta, rótulo de IA e os
  cuidados do nicho. **As contas você cria**: um e-mail por canal e, no TikTok, conta pessoal
  (conta comercial fica fora do Programa de Recompensas).
- `canal.json`: voz, velocidade, tom, estilo das imagens, cores da legenda, hashtags, duração
  mínima. Tudo que estiver aqui vale por cima do `config.json`. `"ativo": false` pausa o canal.
- O banco do canal, escrito e checado à mão: `roteiros.json` (um roteiro por vídeo, com as
  fontes), `perguntas.json` (quiz) ou `quiz_real_ou_ia.json`. Nada se repete até o banco acabar.
  Quando um banco de roteiros acaba, o Olheiro passa a escrever com o Ollama e a Wikipédia.
- `musica\`: as trilhas do canal (o `LEIA-ME.txt` de lá diz o estilo e onde pegar de graça).
- `prontos\`: os vídeos prontos.

Para criar um canal novo, copie uma pasta, troque o nome dela e edite o `canal.json` e o banco.

## Formatos

**roteiro**: narração de 61 a 85 segundos, sem "oi pessoal": a primeira frase já é o gancho, e
as frases são curtas e em "você". A legenda aparece palavra por palavra, com a palavra falada
em destaque, e a imagem troca a cada 2 a 4 segundos com zoom. Cada vídeo usa uma semente fixa
nas imagens de IA, então o personagem mantém a mesma cara do começo ao fim.

**perguntas** (quiz): gancho, 6 perguntas da mais fácil para a mais difícil e um final pedindo
comentário. A voz lê a pergunta, as alternativas A, B, C e D aparecem em cartões, vem a
contagem 3-2-1 em silêncio e a certa fica verde enquanto a voz conta uma curiosidade. O mascote
do canal é gerado uma vez (`mascote_prompt` e `mascote_semente`) e reaparece em todo vídeo.

**real_ou_ia**: inspirado no vídeo de referência (youtube.com/shorts/fMsUjdQztRQ). Cada vídeo
tem um gancho curto, as rodadas do canal (metade real, metade IA) e um final pedindo comentário. Em cada rodada aparece uma imagem com
"#1 REAL OU IA?", a narração pergunta, vem uma contagem 3-2-1 com tique e a resposta
aparece em verde (real) ou vermelho (IA) com um "ding", junto com o fato curioso.

- As coisas do banco (`quiz_real_ou_ia.json`) existem de verdade mas parecem falsas, o que deixa
  o desafio difícil. Dá para adicionar itens novos no mesmo formato. O programa não repete itens
  até usar o banco todo.
- Foto real: Wikimedia Commons (livre, sem chave). O crédito do autor vai sozinho na descrição.
- Foto de IA: Pollinations.ai (grátis, sem conta), no mesmo formato de uma foto comum, para a
  resposta não ficar óbvia. Se uma das fontes falhar, aquela rodada usa a outra e a resposta
  muda junto, então o vídeo nunca mente.
- Sem nenhum canal em `canais\`, o escritório usa o `formatos` do `config.json`
  (`["real_ou_ia"]`, `["curiosidades"]` ou os dois para alternar).

## Monetização e regras das plataformas

- **TikTok, Programa de Recompensas para Criadores**: 10 mil seguidores, 100 mil views em 30
  dias, 18 anos ou mais, conta pessoal e vídeos originais com mais de 1 minuto. Por isso todo
  canal tem `duracao_minima_s: 61`: se a narração ficar curta, o Carregador estica as pausas
  entre as frases até passar de 61 segundos. Vídeo só de fotos ou só de texto não conta.
- **YouTube, Programa de Parcerias**: 1.000 inscritos e 10 milhões de views no Shorts em 90
  dias para receber dos anúncios. Com 500 inscritos e 3 milhões de views já libera Super
  Thanks e membros.
- **Conteúdo repetitivo**: o YouTube não paga canal com "conteúdo em massa" ou "em template".
  Os bancos variam a estrutura, o gancho e o desfecho de cada vídeo; mantenha essa variedade
  ao acrescentar roteiros.
- **Rótulo de IA**: obrigatório só quando a cena parece real. Os canais de desenho e pintura
  não precisam; o `real-ou-ia` tem `"rotulo_ia": true` e precisa sempre (no TikTok, "Conteúdo
  gerado por IA"; no YouTube, "Conteúdo alterado ou sintético"). Quando o escritório posta
  sozinho, ele marca isso pelo `rotulo_ia`; ao postar à mão, o `post.json` lembra.

## Ajustes (`config.json`)

- `formatos`, `quiz_rodadas`, `quiz_pausa_s`: formato dos vídeos, número de rodadas e o tempo
  da contagem para quem assiste pensar.
- `nichos`: os temas que o Olheiro pesquisa, em rodízio (um por vídeo). `nicho` vale quando a lista está vazia.
- `fonte_fatos`: com `wikipedia`, cada roteiro usa fatos de um artigo da Wikipédia, e o link vai
  em `post.json` (campo `fonte`) para você conferir. Isso evita espalhar informação errada.
- `videos_por_canal`: quantos vídeos cada canal ganha por rodada (`videos_por_rodada` vale
  quando não há canais).
- `duracao_minima_s`, `pausa_frases_s`, `musica_volume`: duração mínima, pausa entre frases e
  volume da trilha (0.12 = 12%). Cada canal pode ter os seus.
- `voz`: `auto` usa o edge-tts (vozes neurais da Microsoft, naturais, grátis, precisa de internet)
  e, se ele falhar, o Piper (offline). `voz_edge` escolhe a voz: pt-BR-AntonioNeural (padrão,
  masculina), pt-BR-FranciscaNeural ou pt-BR-ThalitaMultilingualNeural. `voz_edge_velocidade`
  (ex.: `+10%`) e `voz_edge_tom` (ex.: `-2Hz` deixa mais grave) ajustam o jeito de falar.
  `piper_modelo` escolhe a voz offline do Piper (baixe outras em huggingface.co/rhasspy/piper-voices para a pasta `vozes`).
- `postar_de_verdade`: começa em `false`. Nesse modo nada é publicado, só empacotado.
- `resolucao`, `preset`: qualidade e velocidade do render.
- Música: na primeira vez com internet, o escritório baixa sozinho 4 trilhas do Kevin MacLeod
  (incompetech.com, licença Creative Commons BY 4.0) para cada canal que não tem música, com o
  crédito do autor na descrição (veja "Refinamento geral", abaixo). Cada canal usa a pasta
  `canais\<canal>\musica\` e, se ela estiver vazia, a
  `musica\` geral. Só faixas livres para uso comercial (Pixabay Música, Biblioteca de áudio do
  YouTube sem atribuição obrigatória). Faixa que pede crédito: um `.txt` de mesmo nome com o
  crédito na primeira linha, e ele vai sozinho para a descrição. A trilha fica baixa, abaixa
  mais quando a voz fala e o áudio final sai no volume padrão das plataformas (-14 LUFS).
- Imagens que combinam com cada frase: o Olheiro escolhe uma busca para cada frase e o
  Carregador procura um clipe nesta ordem:
  1. Pasta `clipes\`: seus próprios vídeos, como os feitos à mão com créditos grátis de sites de IA.
     O nome do arquivo diz o assunto (`polvo-nadando.mp4`, `coracao.mp4`). Clipes cujo nome
     combina com a frase vêm primeiro.
  2. Pexels: chave grátis em pexels.com/api, depois `setx PEXELS_API_KEY sua_chave`.
  3. Pixabay: chave grátis em pixabay.com/api/docs, depois `setx PIXABAY_API_KEY sua_chave`.
  4. Wikimedia Commons: fotos livres, sem chave. O crédito vai sozinho na descrição do post.
     Foto com licença não comercial (NC) ou sem derivações (ND) é pulada, porque o vídeo é monetizado.
  5. Se nada acima achar, a cena usa um vídeo da pasta `fundos\` na tela inteira, sem som,
     um pouco escurecido, com a legenda e os cartões por cima. Ponha na `fundos\` vídeos verticais
     sem logo de outro app, de preferência seus ou de banco grátis (Pexels, Pixabay): vídeo de
     outro criador pode derrubar a monetização. Para desligar: `"video_sem_imagem": false` no
     config.json (aí volta o fundo degradê gerado).
     A leitura é automática: todo vídeo salvo em `fundos\` ou solto na pasta principal entra no
     sorteio do próximo vídeo, e a vinheta final do TikTok ou do CapCut é cortada sozinha.
  Pexels e Pixabay liberam uso comercial sem dar crédito e têm vídeo em movimento, então
  deixam os vídeos de curiosidades melhores. Depois do `setx`, abra o programa de novo.

## Ligar a postagem automática

Cada plataforma exige uma autorização feita por você uma vez por conta. Os arquivos ficam em
`credenciais\` e nunca devem ser compartilhados. Cada canal posta na própria conta, com os
arquivos dele em `credenciais\<pasta do canal>\` (por exemplo
`credenciais\quiz-desafios\tiktok.json`). Canal sem essa pasta fica "sem credenciais" e não
posta, para nunca publicar na conta de outro canal.

**YouTube Shorts** (o mais simples, recomendo começar por ele)
1. Em console.cloud.google.com, crie um projeto e ative a "YouTube Data API v3".
2. Em "Tela de permissão OAuth", escolha Externo, adicione os e-mails dos canais como usuários
   de teste e, depois de testar, clique em "Publicar app" (Em produção). Para uso próprio não
   precisa de verificação do Google; aparece só um aviso de app não verificado. Sem publicar,
   o Google derruba a autorização a cada 7 dias.
3. Em "Credenciais", crie um "ID do cliente OAuth" do tipo "App para computador" e baixe o JSON.
4. Salve como `credenciais\client_secret.json` e rode `python autorizar_youtube.py <pasta do canal>`
   (por exemplo `python autorizar_youtube.py espaco-universo`). O navegador abre, você entra na
   conta daquele canal, aceita, e ele cria `credenciais\espaco-universo\youtube_token.json`.
   A cota grátis dá cerca de 6 envios por dia.

**TikTok**: crie um app em developers.tiktok.com com o produto "Content Posting API", autorize
a conta do canal e salve em `credenciais\<canal>\tiktok.json`:
`{"client_key": "...", "client_secret": "...", "access_token": "...", "refresh_token": "..."}`.
O access token vale 24 horas; com o refresh token (que vale um ano) o Postador renova sozinho.
Até o TikTok aprovar o app numa auditoria, os vídeos saem como privados (`tiktok_privacidade`
em `config.json`).

**Instagram Reels**: precisa de conta profissional ligada a uma página do Facebook e de um app
em developers.facebook.com. Salve `{"ig_user_id": "...", "token": "..."}` em
`credenciais\<canal>\instagram.json`.

Depois mude `postar_de_verdade` para `true` em `config.json` (ou só no `canal.json` de um canal,
para ligar um de cada vez). Em `plataformas`, deixe só as que você já configurou.

**Atalho pelo Postiz** (opcional e pago): o Postiz (postiz.com) já tem os apps aprovados nas
redes, então publica em público sem você passar pela auditoria do TikTok. O plano de nuvem é
pago (tem teste grátis de 7 dias); instalar o Postiz no próprio PC é grátis, mas aí ele usa os
seus apps e cai na mesma auditoria. Para usar: conecte as contas de todos os canais no Postiz,
crie a chave da API (Configurações > Public API), salve `{"api_key": "..."}` em
`credenciais\postiz.json`, mude `"postador": "postiz"` no `config.json` e, no `canal.json` de
cada canal, diga qual conta é dele:
`"postiz_contas": {"tiktok": "<id>", "youtube": "<id>", "instagram": "<id>"}`.

## Imagens de IA no Cloudflare e cópia para postar pelo celular

- **Cloudflare Workers AI** (grátis, cerca de 150 imagens por dia): o Pollinations passou a
  responder 402 em 31/10. Crie uma conta grátis em dash.cloudflare.com, anote o "Account ID" e
  crie um token de API com a permissão "Workers AI". Salve `{"account_id": "...", "api_token": "..."}`
  em `credenciais\cloudflare.json`. Com o arquivo, o Carregador tenta o Cloudflare primeiro e cai
  no Pollinations se falhar; sem o arquivo, tudo segue como antes.
- **`pasta_para_postar`** (no `config.json` ou no `canal.json`): caminho de uma pasta sincronizada,
  por exemplo `G:\Meu Drive\Para postar` (Google Drive para desktop). Cada vídeo pronto é copiado
  para `<pasta>\<canal>\<id>\` com `video.mp4` e `descricao.txt`, para abrir no celular e postar.
  Vazio = desligado. Para o OneDrive não lotar, o ideal é essa pasta ficar fora dele.

## Atualização automática

Toda vez que você abre o Escritório Dark (`iniciar.bat` ou o atalho), o `atualizar.py` roda antes.
Ele só age se `fonte_atualizacao` (no `config.json`) tiver o endereço de um `manifesto.json`
(`{"versao": ..., "zip": ..., "sha256": ...}`) e a versão for diferente da do `versao.txt`.
Ele guarda um backup em `backup-auto\`, troca só o código e acrescenta as chaves novas do
`config.json`/`canal.json` sem apagar as suas. Nunca mexe em `credenciais\`, `saida\`,
`prontos\`, `usados` e bancos de roteiros. Se o código novo não compilar, volta sozinho para o
anterior. Sem internet ou sem fonte, abre normalmente. Tudo fica em `atualizacao.log`; para
desligar: `"atualizar_sozinho": false`. Para publicar uma versão nova: `python
empacotar_atualizacao.py 2026.11.06.1 "o que mudou" https://endereco-base`.

## Estrutura

```
escritorio_virtual.py     liga tudo
instalar.bat, iniciar.bat, criar_atalho.bat  atalhos para Windows
autorizar_youtube.py      autoriza o envio para um canal do YouTube (uma vez por canal)
escritorio/nucleo.py      agentes em threads, filas e medição de consumo
escritorio/servidor.py    painel ao vivo (SSE, só biblioteca padrão)
escritorio/agentes/       os cinco agentes
escritorio/canais.py      os canais de canais/ e os bancos de roteiros
escritorio/quiz.py        roteiro do desafio "Real ou IA?"
escritorio/perguntas.py   roteiro do quiz de 4 alternativas
canais/<canal>/           um canal por nicho (PERFIL.md, canal.json, banco, musica, prontos)
quiz_real_ou_ia.json      banco geral do desafio (sem canais)
painel/index.html         o escritório em 3D (three.js em painel/vendor, funciona sem internet)
painel/classico.html      o painel antigo, mais leve: http://127.0.0.1:8765/classico
escritorio/painel_dados.py  vídeos prontos, canais e uso do PC para o painel (/extras)
```

## Diagnóstico da internet (diagnostico.bat)

Se as imagens de IA, as fotos da Commons ou a atualização falharem, dê dois cliques em `diagnostico.bat`.
Ele testa o GitHub (atualização), o Cloudflare (token e geração de uma imagem), a Wikimedia Commons e o
Pollinations, e grava o resultado em `diagnostico.txt` (sem mostrar token). Cole o texto no chat.
O Pollinations só é usado se `usar_pollinations` for `true` no `config.json` (hoje ele cobra, então fica desligado).

## Biblioteca de vídeos e limpeza automática

No painel, a **Biblioteca de vídeos** lista todos os vídeos prontos (miniatura, canal, tamanho, data), com filtros
"a publicar" / "já publicados" e por canal. Em cada vídeo há "Assistir e copiar" (player, título e descrição) e o
botão **Marcar já publicado** (e **Desfazer**, que volta para "a publicar"). O estado fica em `saida/biblioteca.json`
(a pasta `saida/` a atualização nunca mexe).

`escritorio/limpeza.py` roda ao abrir o escritório (e a cada rodada diária com `--sempre`):
- vídeo "já publicado" é apagado do PC `dias_apos_publicar` dias (padrão 3) depois da marcação, inclusive a cópia da
  `pasta_para_postar`; o painel mostra "apaga em N dias";
- vídeo "a publicar" nunca é apagado por idade;
- proteção de espaço `limite_gb` (15, 0 = sem limite): se passar, adianta a remoção dos já publicados, do mais antigo;
  se só sobrarem "a publicar", não apaga nada e o painel avisa;
- com `postar_de_verdade`, vídeo publicado pela API conta como "já publicado" sozinho;
- só mexe em pastas de vídeo (id de 8 letras/números) em `canais/<canal>/prontos/`, `saida/prontos/` e na pasta para
  postar; nunca em roteiros, bancos, credenciais ou configurações. Tudo que sai fica em `saida/limpeza.log`.

## Leveza, Lixeira e 2 vídeos por nicho (versão 2026.11.06)

- **2 vídeos por nicho ao abrir:** `videos_por_canal` passou a 2 (5 canais = 10 vídeos por rodada). Na primeira abertura
  depois da atualização o sistema ajusta o `config.json` sozinho (`ajuste_leveza`), inclusive `fila_max` 2 e `preset` medium
  (render mais caprichado, um pouco mais lento).
- **Ninguém no gargalo / PC mais leve, sem perder qualidade:**
  - `pesados_simultaneos` (2): no máximo 2 renderizações/transcrições pesadas ao mesmo tempo, somando todos os agentes.
    Quem não consegue vaga mostra "esperando vaga para renderizar" no painel, em vez de brigar pelo processador.
  - `prioridade_baixa` (true): o escritório roda com prioridade abaixo do normal; o PC continua fluido para você usar.
  - ffmpeg deixa 2 núcleos livres (`threads_ffmpeg` 0 = automático) e o whisper usa `whisper_threads` (2).
  - `fila_max` 2: o Olheiro não adianta roteiros demais; menos imagens e arquivos parados esperando a vez.
  - painel: a soma do espaço em disco é recalculada no máximo 1 vez por minuto.
- **Apagar para a Lixeira:** cada vídeo da biblioteca (e o player) tem o botão **Apagar**, com confirmação. O vídeo, e a
  cópia da pasta para postar, vão para a Lixeira do Windows (dá para restaurar de lá). `escritorio/lixeira.py`.

## Fontes de imagem em cadeia (2026.11.06.4)

Cada cena tenta, em ordem, e passa para a próxima quando uma falha, esgota a cota ou não tem chave:
1. **IA (Cloudflare)**, em até `ia_por_video` cenas por vídeo (cota grátis ~150 imagens/dia);
2. **NASA Images** (sem chave, domínio público; só nos canais de espaço, ou `"nasa": true` no canal.json);
3. **Pexels** e 4. **Pixabay** (fotos verticais; chave grátis, veja abaixo);
5. **Wikimedia Commons** (sem chave, só licença livre);
6. **Openverse** (sem chave; só Creative Commons que permite uso comercial e edição);
7. clipe de vídeo do Pexels/Pixabay, imagem da cena vizinha e, por último, o fundo animado.
Toda foto só vale se o nome/descrição/tags falarem do assunto da cena. A ordem se muda em `fontes_imagem` no `config.json`.
Fonte que dá erro de cota (429) ou de chave (401/403) fica de fora por um tempo e o mural avisa uma vez.

**Leveza (nada disso sobrecarrega o Carregador):** a busca é só rede, sem CPU. No máximo 3 pedidos ao mesmo tempo
(`pesquisas_simultaneas`), com intervalo mínimo por fonte e tempo limite curto (12 s buscando, 30 s baixando); fonte lenta ou
com 3 erros seguidos sai da cadeia por 5 minutos; as buscas rodam durante a narração. Toda foto baixada vai para o cache em
disco `saida\cache_imagens` (limite `cache_imagens_mb`, 500): vídeos seguintes do mesmo assunto reaproveitam sem nenhum pedido.

**Chaves grátis (Pexels e Pixabay):** crie a conta, peça a chave (pexels.com/api e pixabay.com/api/docs) e salve em
`credenciais\chaves.json`: `{"pexels": "SUA_CHAVE", "pixabay": "SUA_CHAVE"}` (ou use `setx PEXELS_API_KEY ...`).
Não usamos busca de imagens do Google/Bing: os termos proíbem robôs e a maioria das imagens tem dono (risco de strike).

## Banco de imagens por nicho e relatório de cenas sem imagem (2026.11.06.5)

**Banco próprio:** ponha fotos em `canais/<canal>/imagens/` (subpastas valem). O nome do arquivo diz o assunto:
`gato-dormindo.jpg`, `leao-cacando.png`. Quando uma cena fala desse assunto, o sistema usa essa imagem ANTES de
qualquer fonte online (e antes do cache). Vence o arquivo que casa mais palavras; sem acento, maiúscula ou plural
exato não faz diferença. Use só imagens suas ou com licença que você tenha, pois não entra crédito no vídeo.

**Relatório:** a cada vídeo, o Carregador anota as cenas que ficaram sem imagem boa (frase da cena e o motivo de
cada origem descartada: IA sem cota/limite, fonte sem chave, fora do ar, "nenhuma foto falava do assunto") em
`saida/relatorio_imagens.md` (resumo por canal, motivos mais comuns e vídeo a vídeo) e `saida/relatorio_imagens.jsonl`
(dados, últimos 500 vídeos). O log avisa: "N cena(s) sem imagem boa neste vídeo: veja saida/relatorio_imagens.md".
Como decidir: se o motivo dominante for "sem chave", crie as chaves do Pexels/Pixabay; se for "nenhuma foto falava
do assunto" num nicho só, monte o banco desse nicho.

## Botão de pausar a produção

No topo do painel, **Pausar produção / Retomar produção** funciona com o sistema aberto: cada agente termina o vídeo
que já está fazendo e não pega outro (o Olheiro para de criar roteiros). O painel e o telão mostram PRODUZINDO ou
PAUSADA, e os agentes ociosos passeiam pela sala. A escolha fica em `saida/producao.json`: se você fechar e abrir de
novo, continua pausado até apertar Retomar. O botão só aceita pedidos feitos pela própria página em 127.0.0.1.

## Imagens: tela dividida só como último recurso

Cada cena tenta, em ordem: IA (Cloudflare) com o pedido da cena, IA com um pedido mais simples (o assunto do vídeo),
foto da Commons, clipes e, se ainda faltar, reaproveita a imagem da cena mais próxima do mesmo vídeo. A tela dividida
com o vídeo de `fundos/` só aparece se nenhuma cena do vídeo conseguiu imagem.

## Referências de cultura pop, transição suave e áudio

- **Referências (filmes, séries, memes, jogos e assuntos virais):** o agente **Referências** (`escritorio/agentes/referencias.py`, usa `escritorio/cultura.py` e
  `escritorio/referencias_cultura.json`, ~50 entradas) procura uma obra ou assunto viral que combine com o roteiro
  e insere UMA frase citando o nome e um fato verdadeiro, por exemplo "Quem viu Interestelar lembra: perto de um
  buraco negro, o tempo passa mais devagar". A legenda acompanha a fala e a descrição ganha "Referência citada".
  Nunca usa trechos, pôsteres, capturas nem imagens originais (evita bloqueio e strike): a imagem da frase é
  genérica, de IA ou da Commons, sem o nome da obra no pedido. Desligue com `referencias_filmes: false`; a mesma obra
  só repete depois de `referencias_filmes_pausa` vídeos. Para acrescentar referências, edite o JSON (`chaves` = palavras
  do roteiro que ativam a referência).
- **Transição:** as cenas se dissolvem em vez de cortar seco (`transicao_s`, 0.2 s; 0 = corte seco), com 30 quadros por
  segundo fixos. No quiz o corte seco continua.
- **Áudio:** NÃO há mais som a cada troca de imagem (o "whoosh" foi desligado em todos os canais; para religar,
  `som_transicao: true` no `config.json`). As frases da narração são unidas com micro-fade para não haver estalo na
  emenda. No quiz continuam só o tique da contagem e o "ding" da resposta.

- **Cota do Cloudflare (causa dos "muitos erros de imagem"):** a conta grátis dá ~10 mil "neurons" por dia, algo como 150
  imagens. Com 10 vídeos de ~20 cenas, a cota acabava no meio da rodada e cada cena ainda insistia 6 vezes
  (HTTP 429). Agora: o sistema lembra que a cota acabou (`saida/ia_uso.json`, renova à meia-noite UTC = 21h no Brasil)
  e para de insistir; cada vídeo usa IA em até `ia_por_video` (12) cenas espalhadas do começo ao fim, e as outras usam
  foto que combine ou a imagem da cena vizinha. Para mais imagens de IA por dia, só o plano pago do Cloudflare.
- **Imagens que combinam com a história:** cada cena usa o pedido de imagem dela; se a IA falhar, tenta de novo e depois
  com a frase + tema. Sem IA, só entra foto da Commons cujo nome/descrição fale do assunto da cena (antes pegava a
  primeira que a busca devolvia). Se o vídeo inteiro ficar sem IA, o mural avisa para conferir `credenciais/cloudflare.json`.

## Refinamento geral (2026.11.11.1)

- **Bancos novos pelas atualizações:** `escritorio\bancos\<canal>\` traz itens no mesmo formato dos bancos do canal
  (`roteiros.json`, `perguntas.json`, `quiz_real_ou_ia.json`). Eles entram depois dos itens da pasta do canal, sem repetir
  `id` (ou `foto`), e os que já viraram vídeo continuam marcados como usados. Esta versão traz 18 roteiros (6 por canal de
  roteiro), 32 perguntas do quiz e 15 fotos do Real ou IA, todos conferidos em fontes (links em `fontes`). Para escrever os
  seus, continue usando os arquivos dentro de `canais\<canal>\`.
- **Música grátis automática (`escritorio\trilhas.py`):** se um canal não tem nenhuma trilha e a `musica\` geral também está
  vazia, o escritório baixa 4 faixas do Kevin MacLeod para `canais\<canal>\musica\`, escolhidas pelo clima do canal.
  A licença é Creative Commons BY 4.0: pode ser usada em vídeo monetizado se o crédito aparecer, e por isso cada faixa ganha
  um `.txt` de mesmo nome, e o Editor põe o crédito na descrição (`descricao.txt` e `post.json`) sozinho. Ajustes:
  `baixar_musica: false` desliga; `trilhas_por_canal` muda a quantidade; `trilhas_incompetech` no `canal.json` troca as faixas
  (o título exato do site). Quem põe música própria no canal não recebe nada. O YouTube às vezes manda um aviso de direitos
  autorais automático em faixas dele: é só contestar, citando a licença CC BY 4.0.
- **Rodada diária:** com o escritório aberto, uma rodada nova começa todo dia em `rodada_diaria_utc` (padrão `00:10`, que é 21h10
  em Brasília, logo depois de a cota grátis de imagens do Cloudflare renovar). `""` volta ao jeito antigo.
- **Canal sem roteiro novo é pulado:** canal de roteiro cujo banco acabou não faz vídeo fora do nicho; o painel avisa e as vagas
  dele saem da rodada (`pular_canal_sem_banco`, padrão `true`). Quiz e Real ou IA recomeçam o rodízio.
- **Título na tela:** nos canais de roteiro, o título do vídeo aparece numa tarja no alto da tela no começo (`titulo_na_tela`:
  `"inicio"`, `"sempre"` ou `false`; `titulo_na_tela_s`, 3.5 s). Quem rola o feed sem som entende o assunto logo.
- **Capa:** o Postador salva `capa.jpg` (quadro em `capa_segundo`, 1.2 s) junto do vídeo, para escolher como capa ao postar
  (`capa: false` desliga). Ela também vai na cópia de `pasta_para_postar`.
- **Música com começo variado:** cada vídeo começa a trilha num ponto sorteado da faixa, com fade de entrada.

## Foco em dois canais e qualidade por vídeo (2026.11.13.1)

- **Só dois canais curtos ligados:** `canais_ativos` no `config.json` diz quais canais produzem (padrão
  `["curiosidades-cotidiano", "quiz-anime"]`). Os outros ficam pausados, com pasta, banco e vídeos guardados; para religar
  um, ponha o nome da pasta na lista (a lista vazia `[]` volta a usar todos com `"ativo": true`). O painel, a rodada
  diária e o Postador só veem os ativos; a Biblioteca continua mostrando os vídeos de todos.
- **Canal novo Quiz de Anime (`canais\quiz-anime`, "Desafio Otaku"):** criado sozinho na primeira vez que o escritório abre
  (o modelo vem em `escritorio\canais_novos\`). 122 perguntas de 27 animes em `escritorio\bancos\quiz-anime\perguntas.json`,
  5 ou 6 por vídeo, metade dos vídeos só de um anime (`quiz_tematico`), ganchos, títulos e finais sorteados. Mascote: raposinha
  branca (`mascote_semente` 73914). Nenhuma imagem é oficial: a IA desenha o clima da pergunta, nunca o personagem.
- **Curiosidades gerais:** `curiosidades-cotidiano` passa a ser de curiosidades gerais (nicho, hashtags e `PERFIL.md` novos; o
  antigo fica em `PERFIL-antes-2026-11-13.md`) e usa também os roteiros ainda não usados de animais e espaço
  (`bancos_extras`). Mais 8 roteiros novos.
- **3 imagens por pergunta:** no quiz, cada pergunta mostra até `imagens_por_pergunta` imagens que entram uma depois da outra
  em fade (`quiz_fade_s`), sem som de transição; a do meio vem da web (licença livre) quando a pergunta tem `busca`. Com
  `quiz_resposta_grande`, a resposta aparece numa imagem maior, com o cartão verde logo abaixo.
- **Vídeo real da web sem marca d'água:** cenas de roteiro com o campo `"video"` (busca em inglês) tentam um vídeo do Pexels ou
  do Pixabay (até `videos_web_por_roteiro` por vídeo). Precisa das chaves grátis em `credenciais\chaves.json`:
  `{"pexels": "...", "pixabay": "..."}`. O som do vídeo nunca entra.
- **IA melhor e sem cair de qualidade:** `modelos_imagem` tenta o FLUX.2 klein primeiro, depois o FLUX.1 schnell (`ia_passos` 8)
  e o SDXL. Com `esperar_cota_ia`, quando a cota grátis do Cloudflare acaba, o vídeo espera a cota do dia seguinte (00:00 UTC)
  em vez de sair com imagem pior. `ia_por_video` subiu para 40 (toda cena com IA).
- **Render e controle de qualidade:** `codificador` libx264, `preset` slow, `crf` 17. Antes de empacotar, o Postador confere
  tamanho, áudio, duração mínima, voz (muda ou misturada) e cenas sem imagem (`qc_max_sem_imagem`, 15%). Reprovado não vai
  para `prontos\`: o motivo fica em `saida\controle_qualidade.log` e o roteiro ou as perguntas voltam para o banco.
  `controle_qualidade: false` desliga.

## Laboratório Otaku: um canal só, 100% feito por código (2026.11.15.1)

Pedido do Cauã em 15/11/2026: um canal só de anime, com vídeos feitos só com código (sem imagem de IA nem
foto da internet), no formato "poder de anime testado com física de verdade". O canal é `canais/laboratorio-otaku`
(perfil em `PERFIL.md`) e é o único em `canais_ativos`.

**Como a linha trabalha neste formato (`"formatos": ["laboratorio"]`):**
| Agente | O que faz |
|---|---|
| Olheiro | Pega o próximo episódio que ainda não virou vídeo (`usados.json` do canal); se não houver, chama o Roteirista |
| Roteirista | Escreve o episódio a partir do banco de temas pesquisados: falas, animação de cada fala, título, descrição, hashtags e trilha |
| Referências | Pula: o episódio já vem pronto |
| Carregador | Narra cada fala com o edge-tts (Antonio, +8%) e guarda o tempo de cada palavra |
| Legendador | Copia título, descrição e hashtags do roteiro; a legenda é desenhada pelo motor |
| Editor | Roda o motor: desenha os quadros no navegador, compõe trilha e efeitos, mixa a voz e codifica (60 qps, CRF 17, -14 LUFS) |
| Postador | Controle de qualidade e pacote em `prontos/` com `video.mp4`, `capa.jpg` e `descricao.txt` |

**Episódios:** cada um é uma pasta `NNN-slug` com `roteiro.json` (falas, título, descrição, hashtags, cores)
e `cenas.js` (as animações daquele episódio). Os que o Claude faz chegam pelas atualizações em
`escritorio/bancos/laboratorio-otaku/episodios/`; você também pode pôr uma pasta em
`canais/laboratorio-otaku/episodios/`. Quando a fila acaba, o canal espera e o painel avisa para pedir mais.

**Motor:** `escritorio/motor_laboratorio/` (base.js, mascote.js, blocos.js, motor.js, som.mjs, renderizar.mjs).
Precisa do Node.js e do pacote playwright-core: o escritório instala os dois sozinho na primeira vez (Node pelo
winget, playwright-core pelo npm) e usa o Microsoft Edge do próprio Windows para desenhar, sem baixar navegador.
O render é pesado (um episódio de 90 s tem 5.400 quadros): no PC pode levar de 20 a 60 minutos. Para ir mais
rápido, ponha `"lab_fps": 30` no canal.json (o vídeo fica um pouco menos fluido).

Testar à mão, sem voz: `cd escritorio\motor_laboratorio` e
`node renderizar.mjs ..\bancos\laboratorio-otaku\episodios\001-rasengan\roteiro.json --simular`.

**Direitos autorais:** nunca desenhamos personagens de anime; quem atua é o mascote original do canal.

### Roteirista e banco de temas (2026.11.15.2)

Pedido do Cauã: focar em 6 animes (Hunter x Hunter, Jujutsu Kaisen, Fullmetal Alchemist, Pokémon, Naruto e One
Piece; no Naruto, coisas pouco explicadas no anime mas com explicação na internet) e deixar os agentes fazerem
tudo. Agora o escritório escreve os episódios sozinho:

- `escritorio/bancos/laboratorio-otaku/temas.json`: o banco de pesquisa. Cada tema traz o poder, os fatos já
  conferidos (com fontes), a fala de cada parte e qual animação ela usa. São 12 temas, cerca de 12 dias de vídeo.
  Quando acabarem, o painel avisa: peça mais temas ao Claude. Você também pode pôr um `temas.json` seu em
  `canais/laboratorio-otaku/`.
- `escritorio/roteirista.py`: monta o episódio (abertura, explicação, medidor de realidade e chamada para
  comentar), escolhe título, descrição e hashtags e grava em `canais/laboratorio-otaku/episodios/NNN-tema/`.
- `escritorio/motor_laboratorio/motor/tipos.js`: as animações genéricas (abertura, fato, número, comparação,
  lista, analogia, medidor, chamada final), que reagem à palavra que está sendo falada. Episódio do Roteirista
  não precisa de `cenas.js`.
- Opcional: `"roteirista_ia": true` no canal.json + `credenciais/cloudflare.json` faz uma IA grátis da
  Cloudflare deixar as falas mais naturais. A fala nova só entra se mantiver todos os números e as palavras que
  disparam as animações.

Depois de postar, pode apagar a pasta do vídeo em `prontos/`: o `usados.json` guarda o que já saiu, então o
tema não repete e a numeração (EXP. 002, 003...) continua.

### Elenco próprio (2026.11.15.3)

Cada anime tem um personagem inventado do canal, que atua nas cenas no lugar do cientista (`motor/elenco.js`):
Ren (ninja, Naruto), Nina (pirata, One Piece), Sora (feiticeiro, Jujutsu Kaisen), Teo (alquimista, Fullmetal),
Bia (caçadora, Hunter x Hunter) e Lu com a criatura Fofo (treinadora, Pokémon). O Roteirista escolhe pelo anime
do tema (campo `elenco` no roteiro). Personagens oficiais dos animes nunca são desenhados, nem "parecidos".
