"""Agente 4: edita o vídeo final 9:16 numa única passada do ffmpeg.

Usa o chip de vídeo do PC quando existe (Intel Quick Sync, NVIDIA NVENC, AMD AMF ou Apple
VideoToolbox), que codifica várias vezes mais rápido que o processador e o deixa livre para os
outros agentes. Sem chip compatível, usa o libx264. Dá para ligar mais de um Editor em
paralelo com "copias": {"editor": 2} no config.json.

Cada cena dura o tempo exato da sua frase: imagem de IA em pé ocupa a tela inteira com zoom
lento (entrando e saindo, alternado), foto comum fica inteira sobre ela mesma desfocada e
vídeo é recortado para vertical. Cena que ficou sem imagem mostra, na tela inteira, um vídeo
seu da pasta fundos/ rodando sem som, com a legenda e os cartões por cima. Por baixo da narração, uma trilha da pasta musica/ do canal
(ou da musica/ geral; use só músicas livres de direitos) que abaixa sozinha quando a voz fala.
As legendas do Legendador são queimadas na mesma passada.
"""
from __future__ import annotations

import os
import random
import subprocess
import threading

from pathlib import Path

from .. import canais, laboratorio
from ..nucleo import RAIZ, Agente, Job

FOTO = {".jpg", ".jpeg", ".png", ".webp"}
MUSICA = {".mp3", ".m4a", ".ogg", ".wav", ".opus"}
VIDEO = {".mp4", ".mov", ".webm", ".mkv", ".m4v"}

# codificador -> opções de qualidade parecidas com o libx264 crf 18 (as plataformas recomprimem
# tudo o que recebem, então vale mandar o arquivo com sobra de qualidade)
CODIFICADORES = {
    "h264_nvenc": ["-preset", "p5", "-rc", "vbr", "-cq", "19", "-b:v", "0", "-maxrate", "20M",
                   "-bufsize", "40M"],
    "h264_qsv": ["-preset", "medium", "-global_quality", "19"],
    "h264_amf": ["-quality", "balanced", "-rc", "cqp", "-qp_i", "18", "-qp_p", "20"],
    "h264_videotoolbox": ["-b:v", "14M"],
}
_escolha: dict = {}
_trava = threading.Lock()


def escolher_codificador(preferido: str) -> str:
    """Testa uma vez quais codificadores de hardware funcionam neste PC e escolhe o primeiro."""
    with _trava:
        if "c" not in _escolha:
            opcoes = [preferido] if preferido in CODIFICADORES else list(CODIFICADORES)
            _escolha["c"] = "libx264"
            if preferido != "libx264":
                for c in opcoes:
                    teste = ["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "color=s=1080x1920:r=30",
                             "-frames:v", "10", "-vf", "format=yuv420p", "-c:v", c, "-f", "null", "-"]
                    try:
                        if subprocess.run(teste, capture_output=True, timeout=20).returncode == 0:
                            _escolha["c"] = c
                            break
                    except (OSError, subprocess.TimeoutExpired):
                        pass
        return _escolha["c"]


class Editor(Agente):
    chave = "editor"
    nome = "Editor"
    cargo = "Monta o vídeo vertical com zoom, trilha e legendas"
    emoji = "🎬"
    motor = "ffmpeg"

    def __init__(self, *a, **kw) -> None:
        super().__init__(*a, **kw)
        self.codec = escolher_codificador(self.cfg.get("codificador", "auto"))
        self.motor = f"ffmpeg · {self.codec}"
        self.tele.atualizar(self.chave, motor=self.motor)

    def threads(self) -> int:
        """Threads do ffmpeg: 0 no config = deixa 2 núcleos livres para o resto do PC (mínimo 2)."""
        n = int(self.cfg.get("threads_ffmpeg", 0) or 0)
        return n if n > 0 else max(2, (os.cpu_count() or 4) - 2)

    def opcoes_video(self) -> list[str]:
        if self.codec == "libx264":
            return ["-c:v", "libx264", "-preset", self.cfg.get("preset", "medium"),
                    "-crf", str(self.cfg.get("crf", 18)), "-profile:v", "high",
                    "-threads", str(self.threads())]
        return ["-c:v", self.codec, *CODIFICADORES[self.codec]]

    @staticmethod
    def videos_fundo(cfg: dict) -> list[Path]:
        """Vídeos para a metade de baixo da tela dividida, lidos sozinhos a cada vídeo: o
        "video_fundo" do config ou, sem ele, todo vídeo da pasta fundos/ e da pasta principal."""
        escolhido = cfg.get("video_fundo")
        if escolhido:
            arq = Path(escolhido) if Path(escolhido).is_absolute() else RAIZ / escolhido
            if arq.exists():
                return [arq]
        return sorted(v for pasta in (RAIZ / "fundos", RAIZ) if pasta.exists()
                      for v in pasta.glob("*") if v.suffix.lower() in VIDEO)

    def limpar_fundo(self, arq: Path) -> Path:
        """Vídeo baixado do TikTok ou do CapCut termina numa vinheta escura e parada com a logo.
        Acha onde ela começa e usa uma cópia sem ela, feita uma vez em saida/fundos_limpos/."""
        pasta = RAIZ / "saida" / "fundos_limpos"
        limpo = pasta / f"{arq.stem}-{int(arq.stat().st_mtime)}{arq.suffix.lower()}"
        if limpo.exists():
            return limpo
        total = self.duracao_arquivo(arq)
        if total < 8:
            return arq
        try:  # brilho médio de 5 quadros por segundo nos últimos 10 s
            saida = subprocess.run(
                ["ffmpeg", "-v", "error", "-sseof", "-10", "-i", str(arq), "-an", "-vf",
                 "fps=5,scale=64:-2,signalstats,metadata=print:key=lavfi.signalstats.YAVG:file=-",
                 "-f", "null", "-"], capture_output=True, text=True, timeout=60).stdout
        except (OSError, subprocess.TimeoutExpired):
            return arq
        brilho = [float(l.split("=")[1]) for l in saida.splitlines() if "YAVG=" in l]
        # do fim para trás, enquanto a tela segue escura e quase igual
        k = len(brilho)
        while k > 0 and brilho[k - 1] < 60 and abs(brilho[k - 1] - brilho[-1]) < 8:
            k -= 1
        vinheta = (len(brilho) - k) / 5
        if vinheta < 1.5 or k == 0:
            return arq
        corte = total - 10 + k / 5 - 0.25
        pasta.mkdir(parents=True, exist_ok=True)
        try:
            self.rodar(["ffmpeg", "-y", "-v", "error", "-i", str(arq), "-t", f"{corte:.2f}", "-an",
                        "-c:v", "copy", str(limpo)])
        except RuntimeError:
            return arq
        self.log(f"{arq.name}: tirei a vinheta final de {vinheta:.1f}s")
        return limpo

    @staticmethod
    def duracao_arquivo(arq: Path) -> float:
        try:
            saida = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                    "-of", "csv=p=0", str(arq)], capture_output=True, text=True,
                                   timeout=30).stdout
            return float(saida.strip() or 0)
        except (OSError, ValueError, subprocess.TimeoutExpired):
            return 0.0

    @staticmethod
    def musicas(job: Job) -> list[Path]:
        """Trilhas do canal do vídeo; sem nenhuma, as da pasta musica/ geral."""
        for pasta in ([canais.pasta(job.canal) / "musica"] if job.canal else []) + [RAIZ / "musica"]:
            achadas = sorted(m for m in pasta.glob("*") if m.suffix.lower() in MUSICA) \
                if pasta.exists() else []
            if achadas:
                return achadas
        return []

    def processar(self, job: Job) -> Job:
        a, cfg = job.arquivos, self.conf(job)
        if a.get("episodio"):  # Laboratório Otaku: o motor desenha, mixa e codifica tudo
            self.tarefa(f"abrindo o motor do Laboratório (job {job.id})")
            final = laboratorio.renderizar(self, job, cfg)
            a["duracao"] = self.duracao_arquivo(final)
            self.log(f"episódio renderizado: {a['duracao']:.1f}s (job {job.id})")
            return job
        w, h = cfg.get("resolucao", [1080, 1920])
        dur = a["duracao"] + 0.4
        musicas = self.musicas(job)
        self.tarefa(f"renderizando {w}x{h} com {dur:.0f}s (job {job.id})")

        # um clipe por frase, cada um cortado no tempo exato da narração daquela frase
        cenas = a.get("cenas") or [a["fundo"]]
        tempos, modos = a["tempos"], a.get("cenas_modo") or []
        if len(cenas) != len(tempos):  # não deveria acontecer; se acontecer, um fundo só
            cenas, tempos, modos = cenas[:1], [a["duracao"]], modos[:1]
        tempos = [*tempos[:-1], tempos[-1] + 0.4]
        # cena sem imagem (só o fundo gerado, ou o mascote no lugar da ilustração): o vídeo de
        # fundo na tela inteira, seguindo de onde parou na cena anterior em vez de recomeçar
        origens = a.get("cenas_origem") or []
        sem_imagem = [i for i, o in enumerate(origens[:len(cenas)]) if o in ("gerado", "mascote_reserva")]
        fundos = self.videos_fundo(cfg) if sem_imagem and cfg.get("video_sem_imagem", True) else []
        pontos: dict[int, float] = {}  # cena -> segundo do vídeo de fundo em que ela começa
        if fundos:
            fundo = self.limpar_fundo(random.choice(fundos))
            total = self.duracao_arquivo(fundo)
            ponto = random.uniform(0, max(total - 5, 0))
            cenas, modos = list(cenas), list(modos) + ["clipe"] * (len(cenas) - len(modos))
            for i in sem_imagem:
                cenas[i], modos[i], pontos[i] = str(fundo), "fundo", ponto
                ponto = (ponto + tempos[i]) % total if total else 0.0
            self.log(f"{len(sem_imagem)} cena(s) sem imagem: {fundo.name} na tela inteira")
        elif sem_imagem:
            self.log(f"{len(sem_imagem)} cena(s) sem imagem e nenhum vídeo em fundos/", "aviso")
        # cena em tela cheia longa vira duas: a segunda é um close num detalhe da mesma imagem,
        # cortado no começo de uma palavra (os shorts de referência trocam de imagem a cada 2-4 s)
        segs: list[tuple] = []  # (arquivo, duração, modo, variante ou cena, imagens extras da mesma cena)
        palavras, inicio = a.get("palavras") or [], 0.0
        extras = a.get("cenas_extra") or {}  # quiz: mais imagens na mesma pergunta, entrando em fade
        for i, (cena, t) in enumerate(zip(cenas, tempos)):
            modo = modos[i] if i < len(modos) else \
                ("foto" if Path(cena).suffix.lower() in FOTO else "clipe")
            if modo == "cheia" and t > cfg.get("cena_max_s", 4.2):
                cortes = [p[0] for p in palavras if inicio + 1.4 < p[0] < inicio + t - 1.4]
                corte = min(cortes, key=lambda x: abs(x - inicio - t / 2)) if cortes else inicio + t / 2
                segs += [(cena, corte - inicio, modo, i % 2, []), (cena, inicio + t - corte, modo, 2, [])]
            else:
                mais = [x for x in extras.get(i) or extras.get(str(i)) or [] if Path(x).exists()] \
                    if modo in ("topo", "resposta", "foto") else []
                segs.append((cena, t, modo, i if modo == "fundo" else i % 2, mais))
            inicio += t
        # transição suave: as cenas se dissolvem (crossfade) em vez de cortar seco. Cada trecho ganha
        # um pouco de sobra para a dissolução e o total continua igual ao da narração; no quiz o
        # corte seco fica, porque o tique da contagem acompanha a troca
        quiz_job = bool(a.get("quiz") or a.get("perguntas"))
        dx = 0.0 if quiz_job or len(segs) < 2 else float(cfg.get("transicao_s", 0.2) or 0)
        if dx:
            dx = min(dx, 0.4 * min(x[1] for x in segs))
        entradas: list[str] = []
        mapa: list[tuple[list[int], list[float], float]] = []  # por trecho: entradas, durações, fade entre elas
        fade_img = float(cfg.get("quiz_fade_s", 0.5) or 0)
        for idx, (cena, t, modo, k, mais) in enumerate(segs):
            t_ext = t + ((dx / 2 if idx == 0 else dx) if dx else 0.0)
            arquivos = [cena, *mais]
            m = len(arquivos)
            # várias imagens no mesmo trecho: cada uma fica t/m e as trocas são dissolvidas (sem som)
            d = min(fade_img, 0.4 * t_ext / m) if m > 1 else 0.0
            ids, durs = [], []
            for j, arq in enumerate(arquivos):
                dur_j = t_ext if m == 1 else t_ext / m + (d if 0 < j < m - 1 else d / 2)
                # foto repete o quadro; vídeo repete o arquivo (pelo tipo do arquivo, não pelo modo)
                laco = ["-loop", "1", "-framerate", "30"] if Path(arq).suffix.lower() in FOTO \
                    else ["-stream_loop", "-1"]
                if modo == "fundo":
                    laco = ["-ss", f"{pontos[k]:.2f}", *laco]
                ids.append(len(durs) + sum(len(x[0]) for x in mapa))
                durs.append(dur_j)
                entradas += [*laco, "-t", f"{dur_j:.3f}", "-i", arq]
            mapa.append((ids, durs, d))
        n = len(segs)
        nar = sum(len(x[0]) for x in mapa)  # a narração entra depois de todas as imagens
        entradas += ["-i", a["narracao"]]
        # volume padrão das plataformas (-14 LUFS); o loudnorm trabalha em 192 kHz, volta para 48
        norma = "loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000"
        audio = f"[{nar}:a]{norma}[voz]"
        if musicas:
            trilha = random.choice(musicas)
            # começa num ponto sorteado da faixa: vídeos do mesmo canal não abrem sempre igual
            total_trilha = self.duracao_arquivo(trilha)
            comeco = random.uniform(0, total_trilha - dur - 2) if total_trilha > dur + 12 else 0.0
            entradas += ["-stream_loop", "-1", "-ss", f"{comeco:.2f}", "-i", str(trilha)]
            # faixa com licença CC BY: o crédito fica num .txt de mesmo nome e vai para a descrição
            credito = trilha.with_suffix(".txt")
            if credito.exists():
                linha = credito.read_text(encoding="utf-8").strip().splitlines()
                if linha:
                    job.arquivos.setdefault("creditos", []).append("Música: " + linha[0].strip())
            # a trilha abaixa sozinha enquanto a voz fala (sidechain); fade curto no fim para
            # o vídeo recomeçar sem buraco quando a plataforma repete
            vol = cfg.get("musica_volume", 0.15)
            audio = (f"[{nar}:a]asplit=2[v1][v2];"
                     f"[{nar + 1}:a]volume={vol},afade=t=in:d={0.8 if comeco else 0.05},"
                     f"afade=t=out:st={max(dur - 0.6, 0):.2f}:d=0.6[m];"
                     f"[m][v2]sidechaincompress=threshold=0.03:ratio=6:attack=15:release=350[bg];"
                     f"[v1][bg]amix=inputs=2:duration=first:normalize=0,{norma}[voz]")
            self.log(f"trilha: {trilha.name}")
        legendas = a["legendas"].replace("\\", "/").replace(":", "\\:")
        # cada clipe: 8% maior + recorte que balança devagar (efeito de zoom), no mesmo formato
        zw, zh = int(w * 1.08) // 2 * 2, int(h * 1.08) // 2 * 2

        def clipe(e: int, r: str, escuro: float = -0.06) -> str:
            return (f"[{e}:v]fps=30,scale={zw}:{zh}:force_original_aspect_ratio=increase:flags=lanczos,"
                    f"crop={w}:{h}:'(iw-ow)/2+sin(t/3)*20':'(ih-oh)/2',eq=brightness={escuro},"
                    f"setsar=1,format=yuv420p[{r}]")

        def fundo_cheio(e: int, r: str) -> str:
            # vídeo de fundo um pouco mais escuro, para a legenda e os cartões se destacarem
            return clipe(e, r, cfg.get("fundo_escuro", -0.12))

        def caixa(e: int, r: str, alt: int, y: str, escuro: float) -> str:
            # a imagem inteira numa faixa, sobre ela mesma ampliada, desfocada e escurecida
            return (f"[{e}:v]fps=30,split[f{r}][g{r}];"
                    f"[g{r}]scale={w // 4}:{h // 4}:force_original_aspect_ratio=increase,"
                    f"crop={w // 4}:{h // 4},boxblur=12:2,eq=brightness={escuro},scale={w}:{h},setsar=1[b{r}];"
                    f"[f{r}]scale={w}:{alt}:force_original_aspect_ratio=decrease:flags=lanczos,"
                    f"setsar=1[p{r}];[b{r}][p{r}]overlay=(W-w)/2:{y},format=yuv420p[{r}]")

        def foto(e: int, r: str) -> str:
            # Real ou IA: faixa central que não encosta nos textos de cima e de baixo
            alt = int(h * cfg.get("foto_altura", 0.48)) // 2 * 2
            return caixa(e, r, alt, f"(H-h)/2-{h // 40}", -0.15)

        def topo(e: int, r: str) -> str:
            # quiz de perguntas: ilustração na parte de cima, deixando o meio para os cartões
            alt, y0 = int(h * 0.3125) // 2 * 2, int(h * 0.151)
            return caixa(e, r, alt, f"{y0}+({alt}-h)/2", -0.3)

        def resposta(e: int, r: str) -> str:
            # quiz: na resposta a imagem cresce (a pergunta e os cartões saem; o cartão certo desce)
            alt, y0 = int(h * 0.40) // 2 * 2, int(h * 0.151)
            return caixa(e, r, alt, f"{y0}+({alt}-h)/2", -0.25)

        def cheia(e: int, r: str, variante: int) -> str:
            # imagem em pé na tela toda com zoom lento; a ampliação 2x antes do zoompan evita
            # o tremido que ele faz quando arredonda a posição para pixels inteiros
            z, dx, dy = [("min(1+0.0009*on,1.2)", "", ""), ("max(1.13-0.0009*on,1)", "", ""),
                         ("min(1.28+0.0008*on,1.45)", "+iw*0.06", "-ih*0.05")][variante]
            return (f"[{e}:v]scale={w * 2}:{h * 2}:force_original_aspect_ratio=increase,"
                    f"crop={w * 2}:{h * 2},zoompan=z='{z}':x='iw/2-(iw/zoom/2){dx}':"
                    f"y='ih/2-(ih/zoom/2){dy}':d=1:s={w}x{h}:fps=30,setsar=1,format=yuv420p[{r}]")

        def um(e: int, r: str, modo: str, variante: int) -> str:
            return {"clipe": clipe, "fundo": fundo_cheio, "foto": foto, "topo": topo,
                    "resposta": resposta}.get(modo, lambda x, y: cheia(x, y, variante))(e, r)

        def parte(i: int) -> str:
            modo, variante = segs[i][2], segs[i][3]
            ids, durs, d = mapa[i]
            if len(ids) == 1:
                return um(ids[0], f"c{i}", modo, variante)
            # várias imagens no mesmo trecho: entram uma depois da outra em fade, sem som
            filtros = [um(e, f"c{i}k{j}", modo, variante) + f";[c{i}k{j}]settb=AVTB,setpts=PTS-STARTPTS[s{i}k{j}]"
                       for j, e in enumerate(ids)]
            atual, acum = f"s{i}k0", durs[0]
            for j in range(1, len(ids)):
                saida = f"c{i}" if j == len(ids) - 1 else f"s{i}m{j}"
                filtros.append(f"[{atual}][s{i}k{j}]xfade=transition=fade:duration={d:.3f}:"
                               f"offset={acum - d:.3f}[{saida}]")
                atual, acum = saida, acum + durs[j] - d
            return ";".join(filtros)
        partes = [parte(i) for i in range(n)]
        if dx:
            xs = [f"[c{i}]settb=AVTB,fps=30,setpts=PTS-STARTPTS[x{i}]" for i in range(n)]
            cadeia, atual, acum = [], "x0", 0.0
            for i in range(1, n):
                acum += segs[i - 1][1]  # a dissolução fica centrada no instante da troca da fala
                saida = f"m{i}" if i < n - 1 else "base"
                cadeia.append(f"[{atual}][x{i}]xfade=transition=fade:duration={dx:.3f}:"
                              f"offset={acum - dx / 2:.3f}[{saida}]")
                atual = saida
            juntar = ";".join(xs + cadeia)
        else:
            # mesmo relógio em todos os trechos (os que têm fade interno saem com outro timebase)
            juntar = ";".join(f"[c{i}]settb=AVTB,fps=30,setpts=PTS-STARTPTS[x{i}]" for i in range(n)) + ";" \
                + "".join(f"[x{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=0[base]"
        # fps=30 fixo antes das legendas: quadros em ritmo constante, sem engasgo
        video = ";".join([*partes, juntar, f"[base]fps=30,ass='{legendas}',format=yuv420p[v]"])
        final = job.pasta / "final.mp4"

        def render() -> None:
            self.rodar(["ffmpeg", "-y", "-v", "error", *entradas,
                        "-filter_complex", f"{video};{audio}", "-map", "[v]", "-map", "[voz]",
                        "-t", f"{dur:.2f}", *self.opcoes_video(),
                        "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(final)],
                       timeout=1200)
        try:
            render()
        except RuntimeError as e:
            if self.codec == "libx264":
                raise
            self.log(f"{self.codec} falhou, voltando para libx264 ({str(e)[:80]})", "aviso")
            self.codec = _escolha["c"] = "libx264"
            self.tele.atualizar(self.chave, motor="ffmpeg · libx264")
            render()
        a["final"] = str(final)
        self.log(f"vídeo final: {final.stat().st_size / 1e6:.1f} MB")
        return job
