// Laboratório Otaku · EXP. 001 · Rasengan x fusão nuclear. Cenas deste episódio (usa motor/blocos.js).
'use strict';

CENAS.gancho = {
  desenhar(c, t, b) {
    const tF = b.palavra('forca'), tAno = b.palavra('1958'), tFim = b.palavra('conseguiu');
    const kE = E.elastic(prog(t, 0.05, 1.2));
    const pulso = 1 + 0.025 * Math.sin(t * 7);
    const sx = CX + 150, sy = 700;
    const aM = entra(t, 0.0, 0.5, E.back);
    mascote(c, CX - 70, 950, 0.8 * clamp(aM), t, { expr: t < tF ? 'confiante' : (t < tFim ? 'serio' : 'choque'), mao: [sx - 10, sy + 150], olhar: 0.6 });
    esfera(c, sx, sy, 175 * kE * pulso, t, { intens: 1 });
    onda(c, sx, sy, t - 0.08, { dur: 0.7, r1: 520, cor: PAL.cor, lw: 14 });
    // título do experimento até a palavra "força"
    const aTit = entra(t, 0.1, 0.4, E.back) * (1 - prog(t, tF - 0.25, tF - 0.05));
    if (aTit > 0) {
      texto(c, 'RASENGAN', CX, 420, { fonte: F.titulo(170), alpha: clamp(aTit), cor: PAL.tinta, espaco: 8, glow: 34, corGlow: PAL.cor });
      rotulo(c, 'É POSSÍVEL NA VIDA REAL?', CX, 282, { alinha: 'center', px: 30, peso: 700, cor: PAL.cor, alpha: clamp(aTit) });
    }
    // "FORÇA" riscada
    const aF = entra(t, tF - 0.05, 0.3, E.back);
    if (aF > 0) {
      const y = 370;
      c.save(); c.globalAlpha *= clamp(aF) * (1 - prog(t, tAno - 0.3, tAno));
      texto(c, 'FORÇA', CX, y, { fonte: F.titulo(150), cor: PAL.tinta, espaco: 6 });
      const kr = prog(t, tF + 0.25, tF + 0.5);
      c.strokeStyle = PAL.vermelho; c.lineWidth = 16; c.lineCap = 'round'; c.shadowColor = PAL.vermelho; c.shadowBlur = 20;
      c.beginPath(); c.moveTo(CX - 210, y + 6); c.lineTo(CX - 210 + 420 * kr, y - 10 + 6 * kr); c.stroke();
      c.restore();
    }
    // contador de anos 1958 -> hoje
    const aA = entra(t, tAno - 0.1, 0.3, E.back);
    if (aA > 0) {
      const ano = Math.round(lerp(1958, 2026, E.io(prog(t, tAno + 0.35, tFim - 0.15))));
      c.save(); c.globalAlpha *= clamp(aA);
      rotulo(c, 'A CIÊNCIA TENTA DESDE', CX, 282, { alinha: 'center', px: 28, cor: PAL.apagado });
      texto(c, String(ano), CX, 420, { fonte: F.titulo(170), cor: ano === 2026 ? PAL.tinta : PAL.cor, espaco: 6, glow: 30, corGlow: PAL.cor });
      c.restore();
    }
    carimbo(c, t, tFim, 'AINDA NÃO', CX + 60, 1225, { px: 84 });
  },
  sons(b) {
    const tAno = b.palavra('1958'), tFim = b.palavra('conseguiu');
    const out = [{ t: 0.06, tipo: 'boom', ganho: 1 }, { t: b.palavra('forca') + 0.25, tipo: 'risco' }];
    for (let x = tAno + 0.35; x < tFim - 0.15; x += 0.075) out.push({ t: x, tipo: 'tick', ganho: 0.5 });
    out.push({ t: tFim, tipo: 'carimbo' });
    return out;
  }
};

CENAS.minato = {
  desenhar(c, t, b) {
    const t0 = b.t0, tTreino = b.palavra('treino'), tPassos = b.palavra('passos');
    const sai = E.io(prog(t, tTreino - 0.25, tTreino + 0.25));
    // parte A: 36 meses
    if (sai < 1) {
      c.save(); c.globalAlpha *= 1 - sai; c.translate(0, -sai * 80);
      etiqueta(c, t, t0 + 0.1, 'CRIAÇÃO DA TÉCNICA');
      const ini = b.palavra('levou'), fim = b.fimPalavra('anos') + 0.3;
      const meses = Math.floor(36 * prog(t, ini, fim));
      const cel = 112, gap = 14, x0 = CX - (6 * cel + 5 * gap) / 2, y0 = 560;
      for (let i = 0; i < 36; i++) {
        const lx = i % 6, ly = Math.floor(i / 6), x = x0 + lx * (cel + gap), y = y0 + ly * (cel * 0.62 + gap);
        const on = i < meses, ka = on ? 1 : 0.25;
        c.save(); retRed(c, x, y, cel, cel * 0.62, 10);
        c.fillStyle = on ? rgba(PAL.cor, 0.22) : 'rgba(255,255,255,0.03)'; c.fill();
        c.strokeStyle = on ? rgba(PAL.cor, 0.9) : 'rgba(255,255,255,0.12)'; c.lineWidth = 2; c.stroke(); c.restore();
        if (on && ly < 6) rotulo(c, ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'][i % 12], x + cel / 2, y + cel * 0.31, { alinha: 'center', px: 22, cor: PAL.tinta, alpha: ka });
      }
      const anos = Math.min(3, Math.floor(meses / 12));
      const aT = entra(t, ini, 0.3, E.back);
      texto(c, `${anos} ${anos === 1 ? 'ANO' : 'ANOS'}`, CX, 460, { fonte: F.titulo(150), alpha: clamp(aT), cor: anos === 3 ? PAL.cor : PAL.tinta, glow: anos === 3 ? 30 : 0, espaco: 4 });
      c.restore();
    }
    // parte B: três passos
    if (sai > 0) {
      const passos = [['01', 'GIRAR', PAL.cor], ['02', 'FORÇA', PAL.laranja], ['03', 'SEGURAR', PAL.cor2]];
      passos.forEach(([n, nome, cor], i) => {
        const a = entra(t, tPassos - 0.35 + i * 0.16, 0.42, E.back);
        if (a <= 0) return;
        const y = 470 + i * 230, x = 150, w = 780, h = 190;
        c.save(); c.globalAlpha *= clamp(a); c.translate((1 - a) * -120, 0);
        retRed(c, x, y, w, h, 26); c.fillStyle = rgba(cor, 0.10); c.fill(); c.strokeStyle = rgba(cor, 0.8); c.lineWidth = 3; c.stroke();
        texto(c, n, x + 60, y + h / 2, { fonte: F.mono(54, 700), cor, alinha: 'left' });
        texto(c, nome, x + 200, y + h / 2 + 6, { fonte: F.titulo(118), alinha: 'left', espaco: 4 });
        // ícone
        const ix = x + w - 100, iy = y + h / 2;
        if (i === 0) { giro(c, ix, iy, 52, 52, 0, t * 4, 4.6, cor, 7); }
        if (i === 1) { c.save(); c.strokeStyle = cor; c.lineWidth = 7; for (let k = 0; k < 3; k++) { const rr = 18 + k * 18 + ((t * 40) % 18); c.globalAlpha *= 1; c.beginPath(); c.arc(ix, iy, rr, 0, TAU); c.globalAlpha = 1 - rr / 72; c.stroke(); } c.restore(); }
        if (i === 2) { esfera(c, ix, iy, 46, t, { cor, aneis: 6, intens: 0.9 }); c.save(); c.strokeStyle = 'rgba(230,238,255,0.8)'; c.lineWidth = 3; c.beginPath(); c.arc(ix, iy, 64, 0, TAU); c.stroke(); c.restore(); }
        c.restore();
      });
    }
  },
  sons(b) {
    const out = [];
    const ini = b.palavra('levou'), fim = b.fimPalavra('anos') + 0.3;
    for (let i = 0; i < 36; i++) out.push({ t: ini + (fim - ini) * (i + 1) / 36, tipo: 'tick', ganho: 0.35 });
    for (let i = 0; i < 3; i++) out.push({ t: b.palavra('passos') - 0.3 + i * 0.16, tipo: 'pop', ganho: 0.8, nota: [0, 3, 7][i] });
    return out;
  }
};

CENAS.passo1 = {
  desenhar(c, t, b) {
    etiqueta(c, t, b.t0 + 0.05, 'PASSO 01 · GIRAR');
    const tEst = b.falaFim - 0.25;
    mascote(c, 905, 520, 0.42 * entra(t, b.t0 + 0.2, 0.4, E.back), t, { expr: t < tEst ? 'serio' : 'feliz', pose: 'aponta', olhar: -1 });
    const kGiro = prog(t, b.palavra('girar'), tEst);
    const vivo = t < tEst;
    if (vivo) {
      const amp = 0.015 + 0.09 * E.in(kGiro);
      balao(c, CX, CY, 250, t, { amp, tipo: 'agua' });
      // giros em várias direções
      const rots = [[0, 1], [1.05, -1], [2.1, 1], [0.5, -1], [2.6, 1], [1.6, -1]];
      rots.forEach(([rot, s], i) => {
        const a = entra(t, b.palavra('girando') - 0.6 + i * 0.12, 0.4);
        const vel = (2 + 7 * kGiro) * s;
        giro(c, CX, CY, 175 - i * 12, 70 + (i % 3) * 22, rot + t * 0.3 * s, t * vel + i, 3.6, i % 2 ? PAL.tinta : PAL.cor, 6, a * 0.95);
      });
      // ondas na água
      c.save(); c.globalAlpha = 0.5; c.strokeStyle = 'rgba(190,240,255,0.5)'; c.lineWidth = 2;
      for (let k = 0; k < 3; k++) { c.beginPath(); for (let x = -180; x <= 180; x += 8) { const y = CY + 120 + k * 34 + Math.sin(x / 30 + t * (3 + 5 * kGiro) + k) * (4 + 10 * kGiro); if (x === -180) c.moveTo(CX + x * (1 - k * 0.12), y); else c.lineTo(CX + x * (1 - k * 0.12), y); } c.stroke(); }
      c.restore();
    } else {
      const dt = t - tEst;
      onda(c, CX, CY, dt, { dur: 0.6, r1: 620, cor: 'rgba(160,230,255,0.9)', lw: 16 });
      estouro(c, CX, CY, dt, { n: 90, seed: 4, vel: 1100, grav: 1800, cor: 'rgba(120,210,255,0.9)', tam: 10, vida: 1.2 });
      estouro(c, CX, CY, dt, { n: 40, seed: 8, vel: 700, grav: 1500, cor: 'rgba(255,255,255,0.9)', tam: 5, vida: 1 });
      check(c, CX, CY, 2.2, prog(t, tEst + 0.25, tEst + 0.55));
      texto(c, 'ROTAÇÃO OK', CX, CY + 150, { fonte: F.mono(40, 700), cor: PAL.verde, alpha: entra(t, tEst + 0.3, 0.3), espaco: 4 });
    }
    // medidor de rotação
    const aM = entra(t, b.t0 + 0.3, 0.4);
    rotulo(c, 'ROTAÇÃO', 180, 1130, { alpha: aM, px: 26 });
    rotulo(c, Math.round(100 * kGiro) + '%', 900, 1130, { alpha: aM, px: 26, alinha: 'right', cor: PAL.cor });
    c.save(); c.globalAlpha *= aM; barra(c, 180, 1156, 720, 16, kGiro, PAL.cor); c.restore();
  },
  sons(b) {
    const tEst = b.falaFim - 0.25;
    return [{ t: b.palavra('girar'), tipo: 'subida', dur: tEst - b.palavra('girar'), ganho: 0.35 }, { t: tEst, tipo: 'estouro_agua' }, { t: tEst + 0.3, tipo: 'ding', ganho: 0.6 }];
  }
};

CENAS.passo2 = {
  desenhar(c, t, b) {
    etiqueta(c, t, b.t0 + 0.05, 'PASSO 02 · FORÇA', { cor: PAL.laranja });
    const tEst = Math.max(b.fimPalavra('borracha') - 0.05, b.t0 + 1.4);
    mascote(c, 905, 520, 0.42, t, { expr: t < tEst ? 'serio' : 'confiante', pose: 'aponta', olhar: -1 });
    const k = prog(t, b.palavra('forca') - 0.1, tEst);
    if (t < tEst) {
      const tremor = E.in(k);
      const sx = 1 + 0.06 * tremor * Math.sin(t * 46), sy = 1 - 0.06 * tremor * Math.sin(t * 46);
      const jx = (ruido1(t * 40, 3)) * 8 * tremor, jy = ruido1(t * 40, 7) * 8 * tremor;
      const aE = E.back(prog(t, b.t0, b.t0 + 0.45));
      const R = 215 * aE;
      c.save(); c.translate(CX + jx, CY + jy); c.scale(sx, sy);
      const g = c.createRadialGradient(-R * 0.35, -R * 0.4, R * 0.05, 0, 0, R);
      g.addColorStop(0, '#ffb27a'); g.addColorStop(0.35, '#f0622d'); g.addColorStop(0.8, '#9b2516'); g.addColorStop(1, '#3d0b07');
      c.fillStyle = g; c.beginPath(); c.arc(0, 0, R, 0, TAU); c.fill();
      c.strokeStyle = 'rgba(40,8,4,0.6)'; c.lineWidth = 6; c.beginPath(); c.ellipse(0, 0, R, R * 0.28, -0.3, 0, TAU); c.stroke();
      // rachaduras
      const kr = prog(k, 0.55, 1);
      if (kr > 0) {
        const r = rng(21); c.strokeStyle = `rgba(255,230,200,${0.9 * kr})`; c.lineWidth = 4; c.shadowColor = PAL.laranja; c.shadowBlur = 18;
        for (let i = 0; i < 7; i++) { const a = r() * TAU; const pts = [[Math.cos(a) * R * 0.2, Math.sin(a) * R * 0.2]]; let x = pts[0][0], y = pts[0][1]; for (let j = 0; j < 5; j++) { const aa = a + (r() - 0.5) * 0.9; x += Math.cos(aa) * R * 0.17; y += Math.sin(aa) * R * 0.17; pts.push([x, y]); } caminhoParcial(c, pts, kr); c.stroke(); }
      }
      c.restore();
      // ondas de força chegando
      for (let i = 0; i < 4; i++) {
        const ph = ((t * 1.6 + i / 4) % 1); c.save(); c.globalAlpha = (1 - ph) * 0.6 * clamp(k * 3); c.strokeStyle = PAL.laranja; c.lineWidth = 5;
        c.beginPath(); c.arc(CX, CY, lerp(420, 230, ph), 0, TAU); c.stroke(); c.restore();
      }
    } else {
      const dt = t - tEst;
      onda(c, CX, CY, dt, { dur: 0.55, r1: 640, cor: PAL.laranja, lw: 18 });
      estouro(c, CX, CY, dt, { n: 46, seed: 6, vel: 1250, grav: 1700, cor: '#e2552a', tam: 14, vida: 1.2, forma: 'caco' });
      estouro(c, CX, CY, dt, { n: 30, seed: 9, vel: 800, grav: 1200, cor: '#ffcf9e', tam: 6, vida: 0.9 });
      check(c, CX, CY, 2.2, prog(t, tEst + 0.2, tEst + 0.5), PAL.verde);
      texto(c, 'FORÇA OK', CX, CY + 150, { fonte: F.mono(40, 700), cor: PAL.verde, alpha: entra(t, tEst + 0.25, 0.3), espaco: 4 });
    }
    const aM = entra(t, b.t0 + 0.2, 0.4);
    rotulo(c, 'PRESSÃO', 180, 1130, { alpha: aM, px: 26 });
    rotulo(c, Math.round(100 * k) + '%', 900, 1130, { alpha: aM, px: 26, alinha: 'right', cor: PAL.laranja });
    c.save(); c.globalAlpha *= aM; barra(c, 180, 1156, 720, 16, k, mistura(PAL.verde, PAL.laranja, k)); c.restore();
  },
  sons(b) {
    const tEst = Math.max(b.fimPalavra('borracha') - 0.05, b.t0 + 1.4);
    return [{ t: b.palavra('forca') - 0.1, tipo: 'subida', dur: tEst - b.palavra('forca') + 0.1, ganho: 0.45 }, { t: tEst, tipo: 'estouro' }];
  }
};

CENAS.passo3 = {
  desenhar(c, t, b) {
    etiqueta(c, t, b.t0 + 0.05, 'PASSO 03 · SEGURAR', { cor: PAL.cor2, extra: 'O PIOR', corExtra: PAL.vermelho, tExtra: b.palavra('pior') });
    const tDuas = b.palavra('duas'), tMexer = b.palavra('mexer');
    mascote(c, 905, 520, 0.42, t, { expr: t < b.palavra('pior') ? 'serio' : (t < tMexer ? 'choque' : 'confiante'), pose: 'aponta', olhar: -1 });
    const k = prog(t, tDuas - 0.2, tMexer);
    const R = 250;
    // mira
    const aMira = entra(t, b.palavra('balao') - 0.1, 0.4);
    const trava = prog(t, tMexer, tMexer + 0.25);
    cantos(c, CX - 330, CY - 340, 660, 680, trava > 0 ? PAL.verde : PAL.apagado, aMira, 46, 4);
    if (aMira > 0) { linha(c, CX - 380, CY, CX - 300, CY, PAL.apagado, 2, aMira); linha(c, CX + 300, CY, CX + 380, CY, PAL.apagado, 2, aMira); linha(c, CX, CY - 390, CX, CY - 330, PAL.apagado, 2, aMira); }
    esfera(c, CX, CY, lerp(60, 165, E.out(k)), t, { cor: PAL.cor, intens: lerp(0.5, 1.2, k), aneis: 16 });
    balao(c, CX, CY, R, t, { amp: 0.006 + 0.012 * k * (1 - trava), tipo: 'ar', alpha: entra(t, b.palavra('balao') - 0.2, 0.45) });
    // leituras
    const aL = entra(t, tDuas, 0.4);
    rotulo(c, 'ROTAÇÃO', 180, 1090, { alpha: aL, px: 24 }); c.save(); c.globalAlpha *= aL; barra(c, 180, 1110, 330, 14, k, PAL.cor); c.restore();
    rotulo(c, 'FORÇA', 570, 1090, { alpha: aL, px: 24 }); c.save(); c.globalAlpha *= aL; barra(c, 570, 1110, 330, 14, k, PAL.laranja); c.restore();
    const aD = entra(t, tMexer - 0.15, 0.3);
    const desl = (trava > 0.5 ? 0 : Math.abs(ruido1(t * 20, 4)) * 0.4).toFixed(1).replace('.', ',');
    rotulo(c, 'MOVIMENTO DO BALÃO', CX, 1165, { alpha: aD, px: 26, alinha: 'center' });
    texto(c, desl + ' mm', CX, 1218, { fonte: F.mono(54, 700), cor: trava > 0.5 ? PAL.verde : PAL.tinta, alpha: aD });
  },
  sons(b) {
    return [{ t: b.palavra('pior'), tipo: 'pop', ganho: 0.9, nota: -5 }, { t: b.palavra('duas') - 0.2, tipo: 'zumbido', dur: b.palavra('mexer') - b.palavra('duas') + 0.6, ganho: 0.35 }, { t: b.palavra('mexer'), tipo: 'trava' }];
  }
};

CENAS.patinadora = {
  desenhar(c, t, b) {
    etiqueta(c, t, b.t0 + 0.05, 'ANALOGIA · PATINAÇÃO');
    const tF = b.palavra('fecha'), tB = b.fimPalavra('bracos') + 0.25;
    const kb = E.io(prog(t, tF, tB));
    // L = I·w constante: integra o ângulo
    const I = k => 0.45 + 1.55 * Math.pow(1 - 0.78 * k, 2);
    const L = I(0) * 1.5 * TAU;
    let ang = 0; const passo = 1 / 240;
    for (let x = b.t0; x < t; x += passo) ang += L / I(E.io(prog(x, tF, tB))) * passo;
    const w = L / I(kb) / TAU;
    const ox = CX, oy = 1060, s = 1.45;
    // gelo
    c.save();
    const gg = c.createRadialGradient(ox, oy, 10, ox, oy, 300); gg.addColorStop(0, 'rgba(170,220,255,0.22)'); gg.addColorStop(1, 'rgba(170,220,255,0)');
    c.fillStyle = gg; c.beginPath(); c.ellipse(ox, oy, 300, 60, 0, 0, TAU); c.fill();
    c.globalCompositeOperation = 'lighter'; c.lineCap = 'round';
    for (let j = 0; j < 5; j++) {
      const rr = 60 + j * 45, a0 = -ang * (1.2 - j * 0.12);
      c.strokeStyle = rgba(PAL.cor, 0.45 - j * 0.07); c.lineWidth = 3;
      c.beginPath(); c.ellipse(ox, oy, rr, rr * 0.2, 0, a0, a0 + 1.6 + w * 0.3); c.stroke();
    }
    c.restore();
    // esqueleto 3D girando no eixo vertical
    const braco = lerp(1, 0, kb);
    const P = {
      cab: [0, -560, 0], pesc: [0, -490, 0], omE: [-62, -470, 0], omD: [62, -470, 0], quad: [0, -280, 0],
      maoE: [lerp(-36, -300, braco), lerp(-405, -470, braco), lerp(46, 0, braco)],
      maoD: [lerp(36, 300, braco), lerp(-405, -470, braco), lerp(46, 0, braco)],
      cotE: [lerp(-70, -180, braco), lerp(-395, -468, braco), lerp(40, 6, braco)],
      cotD: [lerp(70, 180, braco), lerp(-395, -468, braco), lerp(40, 6, braco)],
      joe: [6, -140, 0], pe: [0, 0, 0],
      joeL: [70, -170, 60], peL: [20, -70, 30]
    };
    const Q = {};
    for (const k in P) { const p = rotY(P[k], ang); Q[k] = [ox + p[0] * s * 0.62, oy + p[1] * s * 0.62, p[2]]; }
    const ossos = [['pesc', 'quad', 30], ['omE', 'omD', 22], ['omE', 'cotE', 18], ['cotE', 'maoE', 16], ['omD', 'cotD', 18], ['cotD', 'maoD', 16], ['quad', 'joe', 22], ['joe', 'pe', 20], ['quad', 'joeL', 22], ['joeL', 'peL', 20]];
    ossos.sort((x, y) => (Q[y[0]][2] + Q[y[1]][2]) - (Q[x[0]][2] + Q[x[1]][2]));
    // rastro das mãos
    c.save(); c.globalCompositeOperation = 'lighter';
    for (let j = 1; j <= 8; j++) {
      const aj = ang - j * 0.06 * (w / 1.5);
      for (const k of ['maoE', 'maoD']) { const p = rotY(P[k], aj); c.fillStyle = rgba(PAL.cor, 0.22 * (1 - j / 9)); c.beginPath(); c.arc(ox + p[0] * s * 0.62, oy + p[1] * s * 0.62, 14, 0, TAU); c.fill(); }
    }
    c.restore();
    c.lineCap = 'round'; c.lineJoin = 'round';
    for (const [a1, a2, lw] of ossos) {
      const z = (Q[a1][2] + Q[a2][2]) / 2, luz = 0.6 + 0.4 * clamp(-z / 300 + 0.5);
      c.strokeStyle = mistura('#5d6b93', PAL.tinta, luz); c.lineWidth = lw * s * 0.62 + 4;
      c.beginPath(); c.moveTo(Q[a1][0], Q[a1][1]); c.lineTo(Q[a2][0], Q[a2][1]); c.stroke();
    }
    c.fillStyle = PAL.tinta; c.beginPath(); c.arc(Q.cab[0], Q.cab[1], 34 * s * 0.62 + 4, 0, TAU); c.fill();
    for (const k of ['maoE', 'maoD']) { c.fillStyle = PAL.cor; c.beginPath(); c.arc(Q[k][0], Q[k][1], 11, 0, TAU); c.fill(); }
    // lâmina do patim
    linha(c, Q.pe[0] - 34, Q.pe[1] + 6, Q.pe[0] + 34, Q.pe[1] + 6, PAL.cor, 5);
    // leituras
    const aL = entra(t, b.t0 + 0.3, 0.4);
    rotulo(c, 'VOLTAS/SEGUNDO', 110, 430, { alpha: aL, px: 26 });
    texto(c, w.toFixed(1).replace('.', ','), 110, 510, { fonte: F.titulo(110), alinha: 'left', alpha: aL, cor: kb > 0.5 ? PAL.cor : PAL.tinta, glow: kb > 0.5 ? 26 : 0 });
    const aN = entra(t, b.palavra('nenhuma') - 0.1, 0.3, E.back);
    if (aN > 0) {
      c.save(); c.globalAlpha *= clamp(aN); retRed(c, CX - 220, 1160, 440, 60, 30); c.fillStyle = rgba(PAL.verde, 0.15); c.fill(); c.strokeStyle = PAL.verde; c.lineWidth = 2.5; c.stroke(); c.restore();
      texto(c, 'FORÇA EXTRA: ZERO', CX, 1191, { fonte: F.mono(30, 700), cor: PAL.verde, alpha: clamp(aN), espaco: 2 });
    }
    const aFo = entra(t, tF, 0.4);
    rotulo(c, 'BRAÇOS FECHADOS', 970, 430, { alinha: 'right', alpha: aFo, px: 26, cor: PAL.tinta });
    rotulo(c, '= GIRO MAIS RÁPIDO', 970, 470, { alinha: 'right', alpha: aFo, px: 26, cor: PAL.cor });
    // mascote assistindo: fica em choque quando o giro dispara
    mascote(c, 935, 640, 0.36, t, { expr: kb > 0.5 ? 'choque' : 'feliz', pose: 'aponta', olhar: -1, alpha: entra(t, b.t0 + 0.4, 0.4) });
  },
  sons(b) {
    const tF = b.palavra('fecha'), tB = b.fimPalavra('bracos') + 0.25;
    return [{ t: tF, tipo: 'subida', dur: tB - tF + 0.4, ganho: 0.4 }, { t: b.palavra('nenhuma') - 0.1, tipo: 'pop', ganho: 0.7, nota: 7 }];
  }
};

CENAS.furacao = {
  desenhar(c, t, b) {
    etiqueta(c, t, b.t0 + 0.05, 'MESMA REGRA · FURACÃO');
    const a = entra(t, b.t0, 0.6);
    const tOlho = b.palavra('olho');
    c.save(); c.globalAlpha *= a;
    // bandas em espiral
    c.globalCompositeOperation = 'lighter';
    for (let arm = 0; arm < 5; arm++) {
      c.beginPath();
      for (let i = 0; i <= 120; i++) {
        const u = i / 120, rr = lerp(70, 470, u), th = arm * TAU / 5 - Math.log(rr / 70) * 1.9 + t * 0.9;
        const x = CX + Math.cos(th) * rr, y = CY + Math.sin(th) * rr * 0.92;
        if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
      }
      c.strokeStyle = 'rgba(150,195,255,0.07)'; c.lineWidth = 70; c.stroke();
      c.strokeStyle = 'rgba(180,215,255,0.08)'; c.lineWidth = 34; c.stroke();
      c.strokeStyle = 'rgba(220,238,255,0.12)'; c.lineWidth = 6; c.stroke();
    }
    // partículas de vento: mais rápidas perto do olho (v ~ 1/r)
    const r = rng(17);
    for (let i = 0; i < 160; i++) {
      const r0 = 90 + r() * 400, ph = r() * TAU;
      const om = 2.4 * Math.pow(120 / r0, 1.6);
      const th = ph + om * t;
      const x = CX + Math.cos(th) * r0, y = CY + Math.sin(th) * r0 * 0.92;
      const cauda = Math.min(1.2, om * 0.12);
      c.strokeStyle = r0 < 180 ? rgba(PAL.cor, 0.9) : 'rgba(230,240,255,0.5)'; c.lineWidth = r0 < 180 ? 4 : 2.5; c.lineCap = 'round';
      c.beginPath(); c.moveTo(x, y); c.lineTo(CX + Math.cos(th - cauda) * r0, CY + Math.sin(th - cauda) * r0 * 0.92); c.stroke();
    }
    c.globalCompositeOperation = 'source-over';
    // olho
    const g = c.createRadialGradient(CX, CY, 0, CX, CY, 90); g.addColorStop(0, '#04060c'); g.addColorStop(0.7, 'rgba(4,6,12,0.9)'); g.addColorStop(1, 'rgba(4,6,12,0)');
    c.fillStyle = g; c.beginPath(); c.arc(CX, CY, 90, 0, TAU); c.fill();
    c.restore();
    // setas de velocidade
    const aS = entra(t, b.palavra('vento') - 0.1, 0.4);
    [[440, 0.35], [300, 0.6], [170, 1]].forEach(([rr, f], i) => {
      const x = CX - rr, y = CY + 40;
      seta(c, x, y, x, y - 40 - 170 * f, i === 2 ? PAL.cor : PAL.tinta, 7, 24, aS);
    });
    rotulo(c, 'LONGE', CX - 440, CY + 80, { alinha: 'center', alpha: aS, px: 24, peso: 700 });
    rotulo(c, 'PERTO', CX - 170, CY + 80, { alinha: 'center', alpha: aS * entra(t, tOlho - 0.2, 0.3), px: 24, peso: 700, cor: PAL.cor });
    const aR = entra(t, b.palavra('regra'), 0.4);
    rotulo(c, 'CONSERVAÇÃO DO MOMENTO ANGULAR', CX, 1180, { alinha: 'center', alpha: aR, px: 28, cor: PAL.tinta });
    texto(c, 'massa × velocidade × raio = constante', CX, 1230, { fonte: F.mono(26, 400), cor: PAL.apagado, alpha: aR });
  },
  sons(b) { return [{ t: b.t0, tipo: 'vento', dur: b.dur + 0.3, ganho: 0.4 }]; }
};

CENAS.fusao = {
  desenhar(c, t, b) {
    const tSeg = b.palavra('segurar'), tFus = b.palavra('fusao');
    const sai = E.io(prog(t, tFus - 0.5, tFus - 0.1));
    if (sai < 1) {
      c.save(); c.globalAlpha *= 1 - sai;
      // energia tentando escapar de um anel
      const k = entra(t, b.t0, 0.6);
      const R = 190;
      for (let i = 0; i < 12; i++) {
        const a = i * TAU / 12 + t * 0.4, f = 0.5 + 0.5 * Math.sin(t * 6 + i * 1.7);
        seta(c, CX + Math.cos(a) * (R - 30), CY + Math.sin(a) * (R - 30), CX + Math.cos(a) * (R + 40 + 60 * f), CY + Math.sin(a) * (R + 40 + 60 * f), PAL.cor2, 6, 22, k);
      }
      c.save(); c.globalAlpha *= k; c.strokeStyle = PAL.tinta; c.lineWidth = 8; formaOndulada(c, CX, CY, R, t * 3, 0.05, { sy: 1 }); c.stroke(); c.restore();
      esfera(c, CX, CY, 110 * k, t, { cor: PAL.cor2, aneis: 9 });
      texto(c, 'SEGURAR', CX, 430, { fonte: F.titulo(160), alpha: entra(t, tSeg - 0.05, 0.3), espaco: 6, glow: 20, corGlow: PAL.cor2 });
      c.restore();
    }
    if (t > tFus - 0.5) {
      // dois núcleos se aproximam e se fundem
      const kAp = E.in(prog(t, tFus - 0.5, tFus + 0.15));
      const tFlash = tFus + 0.15;
      const nucleo = (x, y, seed, s = 1) => {
        const r = rng(seed);
        for (let i = 0; i < 7; i++) { const a = r() * TAU, d = r() * 34 * s; const px = x + Math.cos(a) * d, py = y + Math.sin(a) * d; const g = c.createRadialGradient(px - 8, py - 8, 2, px, py, 26 * s); const cor = i % 2 ? '#ff6bb5' : '#c9d3ee'; g.addColorStop(0, '#ffffff'); g.addColorStop(0.3, cor); g.addColorStop(1, rgba(i % 2 ? '#a3165f' : '#56627f', 1)); c.fillStyle = g; c.beginPath(); c.arc(px, py, 24 * s, 0, TAU); c.fill(); }
      };
      if (t < tFlash) {
        const d = lerp(420, 40, kAp);
        nucleo(CX - d, CY, 31); nucleo(CX + d, CY, 32);
        linha(c, CX - d - 120, CY, CX - d - 60, CY, PAL.cor2, 4, 0.6); linha(c, CX + d + 60, CY, CX + d + 120, CY, PAL.cor2, 4, 0.6);
      } else {
        const dt = t - tFlash;
        onda(c, CX, CY, dt, { dur: 0.8, r1: 760, cor: '#ffffff', lw: 22 });
        onda(c, CX, CY, dt - 0.08, { dur: 0.8, r1: 620, cor: PAL.cor2, lw: 12 });
        esfera(c, CX, CY, 150 + 20 * Math.sin(t * 5), t, { cor: PAL.cor2, aneis: 12, intens: 1.2 });
        nucleo(CX, CY, 33, 1.25);
        const fl = 1 - prog(dt, 0, 0.35);
        if (fl > 0) { c.save(); c.globalAlpha = fl * 0.85; c.fillStyle = '#fff'; c.fillRect(0, 0, W, H); c.restore(); }
      }
      const aT = entra(t, tFlash, 0.35, E.back);
      texto(c, 'FUSÃO', CX, 380, { fonte: F.titulo(190), alpha: clamp(aT), espaco: 8, glow: 40, corGlow: PAL.cor2 });
      texto(c, 'NUCLEAR', CX, 1140, { fonte: F.titulo(150), alpha: clamp(aT), cor: PAL.cor2, espaco: 10, glow: 30 });
    }
  },
  sons(b) {
    const tFus = b.palavra('fusao');
    return [{ t: b.palavra('segurar') - 0.05, tipo: 'impacto', ganho: 0.7 }, { t: tFus - 0.9, tipo: 'subida', dur: 1.05, ganho: 0.6 }, { t: tFus + 0.15, tipo: 'boom', ganho: 1 }];
  }
};

CENAS.tokamak = {
  desenhar(c, t, b) {
    const s10 = b.seg('s10');
    etiqueta(c, t, b.t0 + 0.05, 'TOKAMAK · REATOR DE FUSÃO', { cor: PAL.cor2 });
    const aE = entra(t, b.t0, 0.7);
    const R = 300 * lerp(0.8, 1, aE), r = 108, incl = 0.42, gy = t * 0.25;
    const oy = 690;
    const P = (u, v, rr = r) => { let p = [(R + rr * Math.cos(v)) * Math.cos(u), rr * Math.sin(v), (R + rr * Math.cos(v)) * Math.sin(u)]; p = rotY(p, gy); p = rotX(p, incl); return proj(p, CX, oy, 1500); };
    const tIma = s10.t0 + 0 + (b.palavra('imas', 0, s10.t0 + 2) - s10.t0);
    const aIma = entra(t, tIma - 0.1, 0.5);
    // fundo do toro (meridianos de trás primeiro)
    const meridianos = 28;
    const desenhaMer = (frente) => {
      for (let i = 0; i < meridianos; i++) {
        const u = i * TAU / meridianos;
        const zc = P(u, 0)[2];
        if ((zc < 1) !== frente) continue;
        c.beginPath();
        for (let j = 0; j <= 36; j++) { const q = P(u, j * TAU / 36); if (j === 0) c.moveTo(q[0], q[1]); else c.lineTo(q[0], q[1]); }
        c.strokeStyle = `rgba(190,205,240,${(frente ? 0.42 : 0.16) * aE})`; c.lineWidth = frente ? 2.2 : 1.5; c.stroke();
      }
    };
    const desenhaBobinas = (frente) => {
      if (aIma <= 0) return;
      for (let i = 0; i < 12; i++) {
        const u = i * TAU / 12 + TAU / 24;
        const zc = P(u, 0)[2];
        if ((zc < 1) !== frente) continue;
        c.beginPath();
        for (let j = 0; j <= 40; j++) { const v = j * TAU / 40; const rr = r * 1.35 * (1 + 0.18 * Math.cos(v)); const q = P(u, v, rr); if (j === 0) c.moveTo(q[0], q[1]); else c.lineTo(q[0], q[1]); }
        c.save(); c.strokeStyle = rgba(PAL.cor, (frente ? 0.8 : 0.22) * aIma); c.lineWidth = frente ? 8 : 5; c.shadowColor = PAL.cor; c.shadowBlur = frente ? 18 : 0; c.stroke(); c.restore();
      }
    };
    desenhaBobinas(false);
    desenhaMer(false);
    // plasma: anel central brilhante
    const tPl = b.palavra('plasma');
    const aP = entra(t, tPl - 0.2, 0.6);
    if (aP > 0) {
      c.save(); c.globalCompositeOperation = 'lighter';
      const N = 140;
      for (let pass = 0; pass < 3; pass++) {
        for (let i = 0; i < N; i++) {
          const u0 = i * TAU / N, u1 = (i + 1) * TAU / N;
          const a = P(u0, 0, 0), q = P(u1, 0, 0);
          const brilho = 0.55 + 0.45 * Math.sin(u0 * 6 - t * 9) * Math.sin(u0 * 3 + t * 4);
          const prof = a[2];
          c.strokeStyle = pass === 2 ? `rgba(255,255,255,${0.7 * aP * brilho * prof})` : rgba(PAL.cor2, [0.12, 0.45][pass] * aP * (0.6 + 0.4 * brilho));
          c.lineWidth = [70, 26, 7][pass] * prof; c.lineCap = 'round';
          c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(q[0], q[1]); c.stroke();
        }
      }
      // linhas de campo helicoidais
      if (aIma > 0) {
        for (let h = 0; h < 2; h++) {
          c.beginPath();
          for (let i = 0; i <= 600; i++) { const u = i * TAU / 600, v = u * 9 + h * Math.PI + t * 3; const q = P(u, v, r * 0.62); if (i === 0) c.moveTo(q[0], q[1]); else c.lineTo(q[0], q[1]); }
          c.strokeStyle = rgba(PAL.cor, 0.35 * aIma); c.lineWidth = 2; c.stroke();
        }
      }
      c.restore();
    }
    desenhaMer(true);
    desenhaBobinas(true);
    if (aIma > 0) rotulo(c, 'ÍMÃS SUPERCONDUTORES', CX, 1000, { alinha: 'center', alpha: aIma * (1 - prog(t, s10.t0 + 4.2, s10.t0 + 4.6)), px: 26, cor: PAL.cor });

    // ---- s09: temperatura ----
    const t150 = b.palavra('150'), tDez = b.palavra('dez');
    const sai9 = prog(t, s10.t0 - 0.1, s10.t0 + 0.3);
    if (t > t150 - 0.2 && sai9 < 1) {
      c.save(); c.globalAlpha *= 1 - sai9;
      const temp = 150e6 * E.out(prog(t, t150 - 0.1, b.fimPalavra('graus') + 0.3));
      leitura(c, t, t150 - 0.2, 'TEMPERATURA DO PLASMA', milhar(temp) + ' °C', CX, 1065, { cor: PAL.cor2, px: 92 });
      const aB = entra(t, tDez - 0.1, 0.4);
      if (aB > 0) {
        rotulo(c, 'CENTRO DO SOL', 150, 1150, { alpha: aB, px: 24 }); rotulo(c, '15 mi °C', 930, 1150, { alpha: aB, px: 24, alinha: 'right', cor: PAL.laranja });
        c.save(); c.globalAlpha *= aB; barra(c, 150, 1170, 780, 14, 0.1 * E.out(prog(t, tDez, tDez + 0.4)), PAL.laranja); c.restore();
        rotulo(c, 'TOKAMAK', 150, 1215, { alpha: aB, px: 24 }); rotulo(c, '150 mi °C  ×10', 930, 1215, { alpha: aB, px: 24, alinha: 'right', cor: PAL.cor2 });
        c.save(); c.globalAlpha *= aB; barra(c, 150, 1235, 780, 14, E.out(prog(t, tDez + 0.2, tDez + 0.9)), PAL.cor2); c.restore();
      }
      c.restore();
    }
    // ---- s10: nada encosta ----
    if (t > s10.t0) {
      const aN = entra(t, s10.t0 + 0.1, 0.4) * (1 - prog(t, tIma - 0.3, tIma));
      if (aN > 0) {
        leitura(c, t, s10.t0 + 0.1, 'O AÇO DERRETE A', '~1.500 °C', CX, 1085, { px: 92, cor: PAL.tinta });
        c.save(); c.globalAlpha *= aN; texto(c, 'o plasma está 100.000× acima', CX, 1170, { fonte: F.mono(28, 400), cor: PAL.apagado }); c.restore();
      }
      const tSem = b.palavra('tocar', 0, s10.t1 - 1);
      const aG = entra(t, tSem - 0.4, 0.4);
      if (aG > 0) {
        // indicador de folga entre plasma e parede (na seção da frente)
        const u = gy - Math.PI / 2; // ponto mais próximo da câmera
        const pIn = P(u, -Math.PI / 2, r * 0.3), pOut = P(u, -Math.PI / 2, r);
        c.save(); c.globalAlpha *= aG; c.setLineDash([8, 8]); c.strokeStyle = PAL.verde; c.lineWidth = 3;
        c.beginPath(); c.moveTo(pIn[0], pIn[1]); c.lineTo(pOut[0], pOut[1]); c.stroke(); c.restore();
        leitura(c, t, tSem - 0.4, 'CONTATO COM A PAREDE', 'ZERO', CX, 1140, { cor: PAL.verde, px: 100 });
      }
    }
  },
  sons(b) {
    const s10 = b.seg('s10');
    const t150 = b.palavra('150'), fim = b.fimPalavra('graus') + 0.3;
    const out = [{ t: b.palavra('plasma') - 0.2, tipo: 'plasma', dur: b.t1 - b.palavra('plasma') + 0.3, ganho: 0.4 }];
    for (let x = t150 - 0.1; x < fim; x += 0.06) out.push({ t: x, tipo: 'tick', ganho: 0.3 });
    out.push({ t: b.palavra('dez') - 0.1, tipo: 'pop', ganho: 0.7, nota: 0 });
    out.push({ t: b.palavra('imas', 0, s10.t0 + 2) - 0.1, tipo: 'zap', ganho: 0.7 });
    out.push({ t: b.palavra('tocar', 0, s10.t1 - 1) - 0.4, tipo: 'ding', ganho: 0.5 });
    return out;
  }
};

CENAS.linha_tempo = {
  desenhar(c, t, b) {
    etiqueta(c, t, b.t0 + 0.05, 'HISTÓRICO');
    const x0 = 120, x1 = 960, y = 720;
    const X = ano => lerp(x0, x1, (ano - 1950) / (2030 - 1950));
    const aL = entra(t, b.t0, 0.5);
    c.save(); c.globalAlpha *= aL;
    linha(c, x0, y, x1, y, 'rgba(255,255,255,0.25)', 4);
    for (let a = 1950; a <= 2030; a += 10) { linha(c, X(a), y - 14, X(a), y + 14, 'rgba(255,255,255,0.35)', 3); rotulo(c, String(a), X(a), y + 46, { alinha: 'center', px: 22 }); }
    c.restore();
    const t58 = b.palavra('1958'), tHoje = b.palavra('hoje');
    const a58 = entra(t, t58 - 0.1, 0.35, E.back);
    if (a58 > 0) {
      c.save(); c.globalAlpha *= clamp(a58);
      brilho(c, PAL.cor2, 24, () => { c.fillStyle = PAL.cor2; c.beginPath(); c.arc(X(1958), y, 14 * a58, 0, TAU); c.fill(); });
      linha(c, X(1958), y - 22, X(1958), y - 92, PAL.cor2, 3);
      texto(c, '1958', X(1958) - 20, y - 230, { fonte: F.titulo(110), cor: PAL.tinta, alinha: 'left', glow: 20, corGlow: PAL.cor2 });
      rotulo(c, '1º TOKAMAK (T-1) · URSS', X(1958) - 20, y - 140, { alinha: 'left', px: 26, peso: 700, cor: PAL.cor2 });
      c.restore();
    }
    const kH = E.io(prog(t, tHoje - 0.5, tHoje + 0.5));
    if (kH > 0) {
      const ano = lerp(1958, 2026, kH);
      c.save(); c.shadowColor = PAL.cor2; c.shadowBlur = 16; linha(c, X(1958), y, X(ano), y, PAL.cor2, 6); c.restore();
      c.fillStyle = PAL.tinta; c.beginPath(); c.arc(X(ano), y, 11, 0, TAU); c.fill();
      texto(c, Math.round(ano) >= 2026 ? 'HOJE' : String(Math.round(ano)), X(ano), y - 60, { fonte: F.mono(34, 700), cor: PAL.tinta, alinha: 'center' });
    }
    const tW = b.palavra('watt');
    const aW = entra(t, tW - 0.15, 0.35, E.back);
    if (aW > 0) {
      rotulo(c, 'ENERGIA ENTREGUE À REDE ELÉTRICA', CX, 900, { alinha: 'center', alpha: clamp(aW), px: 26 });
      const pis = t > tW + 0.6 ? (Math.floor((t - tW) * 3) % 2 ? 0.55 : 1) : 1;
      c.save(); c.translate(CX, 1060); c.scale(aW, aW);
      texto(c, '0 W', 0, 0, { fonte: F.titulo(250), cor: PAL.vermelho, alpha: pis, glow: 40, espaco: 6 });
      c.restore();
      rotulo(c, 'NENHUM REATOR, EM 68 ANOS', CX, 1215, { alinha: 'center', alpha: entra(t, tW + 0.5, 0.4), px: 26, cor: PAL.apagado });
    }
  },
  sons(b) {
    const tHoje = b.palavra('hoje'), out = [{ t: b.palavra('1958') - 0.1, tipo: 'pop', ganho: 0.9, nota: 0 }];
    for (let x = tHoje - 0.5; x < tHoje + 0.5; x += 0.07) out.push({ t: x, tipo: 'tick', ganho: 0.3 });
    out.push({ t: b.palavra('watt') - 0.15, tipo: 'erro', ganho: 0.7 });
    return out;
  }
};

CENAS.fuga = {
  desenhar(c, t, b) {
    etiqueta(c, t, b.t0 + 0.05, 'POR QUE É TÃO DIFÍCIL');
    const tE = b.palavra('energia'), tFug = b.palavra('fugir');
    const k = E.in(prog(t, tE - 0.3, tFug + 0.2));
    const cols = [[300, 'BALÃO'], [780, 'PLASMA']];
    cols.forEach(([x, nome], i) => {
      const a = entra(t, b.t0 + 0.1 + i * 0.15, 0.45);
      c.save(); c.globalAlpha *= a;
      const y = 720, R = 165;
      for (let j = 0; j < 10; j++) {
        const ang = j * TAU / 10 + i + t * 0.3, f = k * (0.6 + 0.4 * Math.sin(t * 8 + j * 2));
        if (f > 0.05) seta(c, x + Math.cos(ang) * (R - 10), y + Math.sin(ang) * (R - 10), x + Math.cos(ang) * (R + 20 + 120 * f), y + Math.sin(ang) * (R + 20 + 120 * f), i ? PAL.cor2 : PAL.cor, 5, 18, clamp(f * 2));
      }
      if (i === 0) { esfera(c, x, y, lerp(50, 110, k), t, { aneis: 10, intens: lerp(0.6, 1.3, k) }); balao(c, x, y, R, t * (1 + 3 * k), { amp: 0.01 + 0.09 * k, tipo: 'ar', seed: 5 }); }
      else {
        // seção do plasma: anel com núcleo rosa
        c.save(); c.strokeStyle = 'rgba(190,205,240,0.6)'; c.lineWidth = 5; formaOndulada(c, x, y, R, t * (1 + 3 * k), 0.006, { sy: 1, seed: 9 }); c.stroke();
        for (let q = 0; q < 8; q++) { const aa = q * TAU / 8; c.fillStyle = rgba(PAL.cor, 0.85); c.fillRect(x + Math.cos(aa) * (R + 18) - 9, y + Math.sin(aa) * (R + 18) - 9, 18, 18); }
        c.globalCompositeOperation = 'lighter';
        formaOndulada(c, x, y, lerp(70, 120, k), t * (2 + 5 * k), 0.04 + 0.2 * k, { sy: 1, seed: 12 });
        const g = c.createRadialGradient(x, y, 0, x, y, 140); g.addColorStop(0, '#fff'); g.addColorStop(0.3, rgba(PAL.cor2, 0.9)); g.addColorStop(1, rgba(PAL.cor2, 0));
        c.fillStyle = g; c.fill(); c.restore();
      }
      rotulo(c, nome, x, 960, { alinha: 'center', px: 30, peso: 700, cor: PAL.tinta });
      c.restore();
    });
    const aM = entra(t, tE - 0.3, 0.4);
    rotulo(c, 'ENERGIA LÁ DENTRO', 150, 1090, { alpha: aM, px: 26 });
    rotulo(c, Math.round(100 * k) + '%', 930, 1090, { alpha: aM, px: 26, alinha: 'right', cor: mistura(PAL.cor, PAL.vermelho, k) });
    c.save(); c.globalAlpha *= aM; barra(c, 150, 1115, 780, 18, k, mistura(PAL.cor, PAL.vermelho, k)); c.restore();
    const aI = entra(t, tFug, 0.25, E.back);
    if (aI > 0) { texto(c, 'INSTABILIDADE', CX, 1210, { fonte: F.titulo(80), cor: PAL.vermelho, alpha: clamp(aI) * (Math.floor(t * 6) % 2 ? 0.7 : 1), espaco: 6, glow: 24 }); }
  },
  sons(b) {
    const tE = b.palavra('energia'), tFug = b.palavra('fugir');
    return [{ t: tE - 0.3, tipo: 'subida', dur: tFug - tE + 0.5, ganho: 0.5 }, { t: tFug, tipo: 'erro', ganho: 0.8 }];
  }
};

CENAS.comparacao = {
  desenhar(c, t, b) {
    etiqueta(c, t, b.t0 + 0.05, 'QUANTO TEMPO LEVOU');
    const linhas = [
      { nome: 'MINATO', valor: '3 ANOS', k: 3 / 68, cor: PAL.tinta, t0: b.t0 + 0.2 },
      { nome: 'NARUTO', valor: '1 SEMANA', k: 0.006, cor: PAL.laranja, t0: b.palavra('naruto') - 0.1 },
      { nome: 'CIÊNCIA', valor: '68 ANOS E CONTANDO', k: 1.25, cor: PAL.cor2, t0: b.t0 + 0.45 }
    ];
    const x0 = 150, wMax = 780;
    linhas.forEach((l, i) => {
      const y = 520 + i * 220;
      const a = entra(t, l.t0, 0.4);
      if (a <= 0) return;
      c.save(); c.globalAlpha *= a;
      texto(c, l.nome, x0, y, { fonte: F.titulo(84), alinha: 'left', cor: l.cor, espaco: 3 });
      const kb = E.out(prog(t, l.t0 + 0.15, l.t0 + 0.9)) * l.k;
      c.save(); c.shadowColor = l.cor; c.shadowBlur = 16; c.fillStyle = l.cor;
      retRed(c, x0, y + 52, Math.max(14, wMax * kb), 34, 8); c.fill(); c.restore();
      if (l.k > 1 && kb > 1) { seta(c, W - 90, y + 69, W - 40, y + 69, l.cor, 6, 22); }
      texto(c, l.valor, i === 2 ? x0 : x0 + Math.max(14, wMax * kb) + 24, i === 2 ? y + 130 : y + 70, { fonte: F.mono(32, 700), alinha: 'left', cor: PAL.tinta });
      c.restore();
    });
    // clone
    const tC = b.palavra('clone');
    const aC = entra(t, tC - 0.1, 0.35, E.back);
    if (aC > 0) {
      const y = 740 + 70, x = 560;
      c.save(); c.globalAlpha *= clamp(aC);
      retRed(c, x - 20, y - 54, 330, 92, 46); c.fillStyle = rgba(PAL.laranja, 0.15); c.fill(); c.strokeStyle = PAL.laranja; c.lineWidth = 3; c.stroke();
      mascote(c, x + 34, y - 8, 0.24, t, { expr: 'confiante' }); mascote(c, x + 88, y - 8, 0.24, t + 0.7, { expr: 'feliz', alpha: 0.7 });
      texto(c, '+1 CLONE', x + 128, y - 6, { fonte: F.mono(32, 800), alinha: 'left', cor: PAL.laranja });
      c.restore();
    }
  },
  sons(b) {
    return [{ t: b.t0 + 0.2, tipo: 'pop', nota: 0, ganho: 0.6 }, { t: b.t0 + 0.45, tipo: 'pop', nota: 5, ganho: 0.6 }, { t: b.palavra('naruto') - 0.1, tipo: 'pop', nota: 9, ganho: 0.7 }, { t: b.palavra('clone') - 0.1, tipo: 'pop', nota: 12, ganho: 0.8 }];
  }
};

CENAS.medidor = {
  desenhar(c, t, b) {
    const aT = entra(t, b.t0, 0.45, E.back);
    texto(c, 'MEDIDOR DE', CX, 360, { fonte: F.titulo(92), alpha: clamp(aT), espaco: 6 });
    texto(c, 'REALIDADE', CX, 470, { fonte: F.titulo(132), alpha: clamp(aT), cor: PAL.cor, espaco: 8, glow: 30 });
    const tCem = b.palavra('cem'), tZero = b.palavra('zero'), tEnq = b.palavra('enquanto');
    mascote(c, 150, 1010, 0.42 * entra(t, b.t0 + 0.3, 0.4, E.back), t, { expr: t < tZero ? 'feliz' : 'choque', pose: 'aponta', olhar: 1 });
    const gauge = (cx, cy, R, k, rot, cor, aa, valor) => {
      if (aa <= 0) return;
      c.save(); c.globalAlpha *= aa;
      c.lineCap = 'round';
      c.strokeStyle = 'rgba(255,255,255,0.09)'; c.lineWidth = 30; c.beginPath(); c.arc(cx, cy, R, Math.PI, TAU); c.stroke();
      // escala colorida
      for (let i = 0; i < 40; i++) {
        const a0 = Math.PI + i / 40 * Math.PI, a1 = a0 + Math.PI / 40 * 0.7;
        c.strokeStyle = mistura(PAL.vermelho, PAL.verde, i / 39); c.globalAlpha = aa * (i / 40 <= k ? 1 : 0.18); c.lineWidth = 30; c.lineCap = 'butt';
        c.beginPath(); c.arc(cx, cy, R, a0, a1); c.stroke();
      }
      c.globalAlpha = aa;
      const an = Math.PI + k * Math.PI;
      c.strokeStyle = PAL.tinta; c.lineWidth = 8; c.lineCap = 'round';
      c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.cos(an) * (R - 40), cy + Math.sin(an) * (R - 40)); c.stroke();
      c.fillStyle = PAL.tinta; c.beginPath(); c.arc(cx, cy, 16, 0, TAU); c.fill();
      texto(c, valor, cx, cy - 70, { fonte: F.titulo(76), cor, glow: 20 });
      rotulo(c, rot, cx, cy + 52, { alinha: 'center', px: 28, peso: 700, cor: PAL.tinta });
      c.restore();
    };
    const k1 = E.out(prog(t, tCem - 0.4, tCem + 0.3));
    gauge(CX, 760, 220, k1, 'GIRAR', PAL.verde, entra(t, b.palavra('girar') - 0.2, 0.4), Math.round(100 * k1) + '%');
    // segurar: sobe com esperança e cai para zero
    const subida = E.out(prog(t, tZero - 1.2, tZero - 0.5)) * 0.32, queda = E.io(prog(t, tZero - 0.15, tZero + 0.2));
    const k2 = subida * (1 - queda);
    gauge(CX, 1110, 220, k2, 'SEGURAR NA MÃO', PAL.vermelho, entra(t, b.palavra('segurar') - 0.2, 0.4), Math.round(100 * k2) + '%');
    carimbo(c, t, tEnq - 0.05, 'POR ENQUANTO', CX + 170, 1205, { cor: PAL.laranja, px: 52, rot: -0.1 });
  },
  sons(b) {
    return [{ t: b.palavra('cem') + 0.2, tipo: 'ding', ganho: 0.8 }, { t: b.palavra('zero') + 0.05, tipo: 'erro', ganho: 0.8 }, { t: b.palavra('enquanto') - 0.05, tipo: 'carimbo' }];
  }
};

CENAS.cta = {
  desenhar(c, t, b) {
    const a = entra(t, b.t0, 0.5, E.back);
    mascote(c, CX + 40, 470, 0.6 * clamp(a), t, { expr: 'feliz', pose: 'acena' });
    esfera(c, CX - 170, 450, 80 * clamp(a), t, { aneis: 10 });
    texto(c, 'QUAL PODER', CX, 790, { fonte: F.titulo(118), alpha: clamp(a), espaco: 5 });
    texto(c, 'VEM AGORA?', CX, 905, { fonte: F.titulo(118), alpha: clamp(entra(t, b.t0 + 0.15, 0.5, E.back)), cor: PAL.cor, espaco: 5, glow: 26 });
    // balão de comentário digitando sugestões
    const aB = entra(t, b.palavra('comenta') + 0.3, 0.4, E.back);
    if (aB > 0) {
      const sug = ['Kamehameha', 'Chidori', 'Gear 5', 'Hollow Purple', 'Bankai'];
      const tt = t - (b.palavra('comenta') + 0.6);
      const i = Math.max(0, Math.floor(tt / 1.1)) % sug.length, kk = tt < 0 ? 0 : (tt % 1.1) / 0.6;
      const txt = sug[i].slice(0, Math.floor(sug[i].length * clamp(kk)));
      const x = 190, y = 990, w = 700, h = 104;
      c.save(); c.globalAlpha *= clamp(aB);
      retRed(c, x, y, w, h, 30); c.fillStyle = 'rgba(255,255,255,0.07)'; c.fill(); c.strokeStyle = 'rgba(255,255,255,0.35)'; c.lineWidth = 2.5; c.stroke();
      c.fillStyle = 'rgba(255,255,255,0.07)'; c.beginPath(); c.moveTo(x + 60, y + h); c.lineTo(x + 40, y + h + 34); c.lineTo(x + 100, y + h); c.fill();
      pessoa(c, x + 60, y + h / 2 + 6, 0.62, PAL.apagado);
      texto(c, txt + (Math.floor(t * 3) % 2 ? '|' : ''), x + 120, y + h / 2 + 2, { fonte: F.texto(44, 700), alinha: 'left', cor: PAL.tinta });
      c.restore();
    }
    logo(c, CX - 205, 1200, 1.1, t, entra(t, b.t0 + 0.4, 0.5));
    texto(c, 'LABORATÓRIO OTAKU', CX + 25, 1201, { fonte: F.mono(32, 700), alpha: entra(t, b.t0 + 0.4, 0.5), espaco: 3 });
  },
  sons(b) {
    const out = [{ t: b.t0 + 0.05, tipo: 'boom', ganho: 0.6 }, { t: b.palavra('comenta') + 0.3, tipo: 'pop', nota: 7, ganho: 0.6 }];
    return out;
  }
};
