# Laboratório Otaku

Pasta do canal: `canais/laboratorio-otaku`. Os vídeos prontos saem em `prontos/`.
Criado em 15/11/2026, quando o projeto passou a ter um canal só: anime, com vídeos 100% feitos por código.

## Nome e perfil
- **Nome:** Laboratório Otaku. **@ sugerido:** @laboratoriootaku (confira se está livre no TikTok, YouTube e Instagram).
- **Bio:** Poderes de anime testados com física de verdade. Comenta o próximo poder 🧪
- **Hashtags:** #anime #laboratoriootaku + as do episódio (#naruto #rasengan #fisica...)

## Como é o vídeo
- Cada vídeo é um "EXP. NNN": um poder de anime explicado com ciência real, de 75 a 95 s, 1080x1920 a 60 quadros.
- Tudo é desenhado por código (canvas): diagramas, HUD com números contando, esfera de energia, e o mascote
  do canal, um cientista chibi original (cabelo azul-marinho, óculos de laboratório na testa, jaleco).
- Legenda palavra por palavra com a palavra falada na cor do episódio; trilha e efeitos sonoros compostos pelo
  próprio motor (sem música de terceiros); narração edge-tts (Antonio, +8%); som em -14 LUFS.
- Fim fixo: "MEDIDOR DE REALIDADE" (quanto do poder é possível) e o pedido "comenta o próximo poder".

## Direitos autorais (importante)
- Nunca desenhamos personagens de anime (Naruto, Gojo...): só o nome do poder, diagramas e o nosso mascote.
  Personagem reconhecível é o que dá strike e derruba vídeo.
- Nada de print, cena, abertura ou música de anime.

## Como entram episódios novos
- Cada episódio é uma pasta `NNN-slug` com `roteiro.json` (falas, título, descrição, hashtags) e `cenas.js`
  (as animações). Os episódios chegam pelas atualizações em `escritorio/bancos/laboratorio-otaku/episodios/`,
  e você pode colocar episódios à mão em `canais/laboratorio-otaku/episodios/`.
- Quando a fila acaba, o canal espera: peça os próximos episódios ao Claude (ex.: "faz o EXP. 002 do Infinito do Gojo").
