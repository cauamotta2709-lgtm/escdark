// Laboratório Otaku: utilidades de desenho. Tudo é função do tempo t (em segundos),
// sem estado entre quadros, para o renderizador poder pular para qualquer instante.
'use strict';

const W = 1080, H = 1920;
const TAU = Math.PI * 2;
const CENAS = {};   // cada cena: { desenhar(ctx, t, bloco), sons(bloco) }

const PAL = {
  fundo1: '#04060c', fundo2: '#0a1124',
  grade: 'rgba(110,150,255,0.055)', gradeForte: 'rgba(110,150,255,0.11)',
  tinta: '#e9eefb', apagado: '#7c88ad', escuro: '#1a2340',
  cor: '#3fd0ff', cor2: '#ff3fa4', laranja: '#ffb02e', verde: '#3dffa8', vermelho: '#ff4d5e'
};

const F = {
  titulo: (px) => `${px}px Anton`,
  mono: (px, peso = 400) => `${peso} ${px}px "JetBrains Mono"`,
  texto: (px, peso = 900) => `${peso} ${px}px "Inter Tight"`
};

// ---------- matemática ----------
const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const lerp = (a, b, k) => a + (b - a) * k;
const prog = (t, a, b) => clamp((t - a) / (b - a));
const E = {
  out: k => 1 - Math.pow(1 - k, 3),
  out5: k => 1 - Math.pow(1 - k, 5),
  in: k => k * k * k,
  io: k => k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2,
  back: k => { const c = 1.9; return 1 + (c + 1) * Math.pow(k - 1, 3) + c * Math.pow(k - 1, 2); },
  elastic: k => k === 0 || k === 1 ? k : Math.pow(2, -10 * k) * Math.sin((k * 10 - 0.75) * (TAU / 3)) + 1
};
// entra em [a, a+d] com curva e
const entra = (t, a, d = 0.45, e = E.out) => e(prog(t, a, a + d));

function rng(seed) {
  let s = seed | 0;
  return () => {
    s = (s + 0x6D2B79F5) | 0;
    let x = Math.imul(s ^ (s >>> 15), 1 | s);
    x = (x + Math.imul(x ^ (x >>> 7), 61 | x)) ^ x;
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}
// ruído suave 1D determinístico
function ruido1(x, seed = 1) {
  const i = Math.floor(x), f = x - i;
  const h = n => { const r = Math.sin((n + seed * 131.7) * 127.1) * 43758.5453; return r - Math.floor(r); };
  const u = f * f * (3 - 2 * f);
  return lerp(h(i), h(i + 1), u) * 2 - 1;
}

// ---------- 3D simples ----------
function rotX(p, a) { const c = Math.cos(a), s = Math.sin(a); return [p[0], p[1] * c - p[2] * s, p[1] * s + p[2] * c]; }
function rotY(p, a) { const c = Math.cos(a), s = Math.sin(a); return [p[0] * c + p[2] * s, p[1], -p[0] * s + p[2] * c]; }
function rotZ(p, a) { const c = Math.cos(a), s = Math.sin(a); return [p[0] * c - p[1] * s, p[0] * s + p[1] * c, p[2]]; }
function proj(p, cx, cy, foco = 1400) { const k = foco / (foco + p[2]); return [cx + p[0] * k, cy + p[1] * k, k]; }

// ---------- cor ----------
function hexRgb(h) { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function rgba(h, a) { const [r, g, b] = hexRgb(h); return `rgba(${r},${g},${b},${a})`; }
function mistura(h1, h2, k) {
  const a = hexRgb(h1), b = hexRgb(h2);
  return `rgb(${Math.round(lerp(a[0], b[0], k))},${Math.round(lerp(a[1], b[1], k))},${Math.round(lerp(a[2], b[2], k))})`;
}

// ---------- desenho ----------
function brilho(ctx, cor, blur, fn) {
  ctx.save(); ctx.shadowColor = cor; ctx.shadowBlur = blur; fn(); ctx.restore();
}
function texto(ctx, s, x, y, { fonte = F.texto(60), cor = PAL.tinta, alinha = 'center', base = 'middle', alpha = 1, borda = 0, corBorda = 'rgba(0,0,0,0.85)', espaco = 0, glow = 0, corGlow = null } = {}) {
  if (alpha <= 0.001) return;
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.font = fonte; ctx.textAlign = alinha; ctx.textBaseline = base;
  if (espaco) ctx.letterSpacing = espaco + 'px';
  if (borda) { ctx.lineJoin = 'round'; ctx.lineWidth = borda; ctx.strokeStyle = corBorda; ctx.strokeText(s, x, y); }
  if (glow) { ctx.shadowColor = corGlow || cor; ctx.shadowBlur = glow; }
  ctx.fillStyle = cor; ctx.fillText(s, x, y);
  ctx.restore();
}
function largura(ctx, s, fonte, espaco = 0) { ctx.save(); ctx.font = fonte; if (espaco) ctx.letterSpacing = espaco + 'px'; const w = ctx.measureText(s).width; ctx.restore(); return w; }

function linha(ctx, x1, y1, x2, y2, cor, lw = 3, alpha = 1) {
  ctx.save(); ctx.globalAlpha *= alpha; ctx.strokeStyle = cor; ctx.lineWidth = lw; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.restore();
}
function seta(ctx, x1, y1, x2, y2, cor, lw = 4, cab = 18, alpha = 1) {
  const a = Math.atan2(y2 - y1, x2 - x1);
  ctx.save(); ctx.globalAlpha *= alpha; ctx.strokeStyle = cor; ctx.fillStyle = cor; ctx.lineWidth = lw; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - Math.cos(a) * cab * 0.6, y2 - Math.sin(a) * cab * 0.6); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - Math.cos(a - 0.45) * cab, y2 - Math.sin(a - 0.45) * cab);
  ctx.lineTo(x2 - Math.cos(a + 0.45) * cab, y2 - Math.sin(a + 0.45) * cab); ctx.closePath(); ctx.fill();
  ctx.restore();
}
function retRed(ctx, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}
// linha tracejada que vai sendo desenhada (k de 0 a 1)
function caminhoParcial(ctx, pts, k) {
  if (pts.length < 2 || k <= 0) return;
  let total = 0; const seg = [];
  for (let i = 1; i < pts.length; i++) { const d = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); seg.push(d); total += d; }
  let resta = total * clamp(k);
  ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length && resta > 0; i++) {
    const d = seg[i - 1];
    if (resta >= d) ctx.lineTo(pts[i][0], pts[i][1]);
    else { const f = resta / d; ctx.lineTo(lerp(pts[i - 1][0], pts[i][0], f), lerp(pts[i - 1][1], pts[i][1], f)); }
    resta -= d;
  }
}

// rótulo técnico: texto mono com traço-guia
function rotulo(ctx, s, x, y, { cor = PAL.apagado, px = 30, alinha = 'left', alpha = 1, peso = 400 } = {}) {
  texto(ctx, s, x, y, { fonte: F.mono(px, peso), cor, alinha, alpha, espaco: 2 });
}

// mira de canto (moldura técnica)
function cantos(ctx, x, y, w, h, cor, alpha = 1, tam = 34, lw = 3) {
  ctx.save(); ctx.globalAlpha *= alpha; ctx.strokeStyle = cor; ctx.lineWidth = lw; ctx.lineCap = 'square';
  const c = (px, py, dx, dy) => { ctx.beginPath(); ctx.moveTo(px + dx * tam, py); ctx.lineTo(px, py); ctx.lineTo(px, py + dy * tam); ctx.stroke(); };
  c(x, y, 1, 1); c(x + w, y, -1, 1); c(x, y + h, 1, -1); c(x + w, y + h, -1, -1);
  ctx.restore();
}

// número com casas de milhar (pt-BR)
function milhar(n) { return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }

// partículas de explosão determinísticas
function estouro(ctx, cx, cy, t, { n = 60, seed = 3, vel = 900, grav = 1400, cor = PAL.cor, tam = 9, vida = 1.1, forma = 'gota' } = {}) {
  if (t < 0 || t > vida) return;
  const r = rng(seed);
  ctx.save();
  for (let i = 0; i < n; i++) {
    const a = r() * TAU, v = vel * (0.35 + r() * 0.65), s = tam * (0.5 + r());
    const x = cx + Math.cos(a) * v * t, y = cy + Math.sin(a) * v * t + 0.5 * grav * t * t;
    const al = 1 - t / vida;
    ctx.globalAlpha = al;
    ctx.fillStyle = cor;
    if (forma === 'caco') {
      ctx.save(); ctx.translate(x, y); ctx.rotate(a + t * 8 * (r() - 0.5));
      ctx.fillRect(-s, -s * 0.5, s * 2, s); ctx.restore();
    } else {
      ctx.beginPath(); ctx.arc(x, y, s * (1 - t / vida * 0.5), 0, TAU); ctx.fill();
    }
  }
  ctx.restore();
}

// anel de flash (onda de choque)
function onda(ctx, cx, cy, t, { dur = 0.6, r0 = 40, r1 = 520, cor = PAL.tinta, lw = 10 } = {}) {
  if (t < 0 || t > dur) return;
  const k = E.out(t / dur);
  ctx.save(); ctx.globalAlpha = 1 - t / dur; ctx.strokeStyle = cor; ctx.lineWidth = lw * (1 - k) + 1;
  ctx.beginPath(); ctx.arc(cx, cy, lerp(r0, r1, k), 0, TAU); ctx.stroke(); ctx.restore();
}
