// Mascote original do Laboratório Otaku: cientista chibi com óculos de laboratório na testa.
// Desenhado 100% por código. Origem = centro da cabeça; s = escala (1 = cabeça com raio 100 px).
// opções: expr ('feliz' | 'serio' | 'choque' | 'confiante'), pose ('segura' | 'aponta' | 'acena' | 'parado'),
//         olhar (-1..1), mao: [x, y] alvo da mão direita em coordenadas da tela (opcional).
'use strict';

function mascote(c, x, y, s, t, { expr = 'feliz', pose = 'parado', olhar = 0, mao = null, alpha = 1, cor = PAL.cor } = {}) {
  if (alpha <= 0 || s <= 0) return;
  const CONT = '#0b1020', PELE = '#f7d6bf', PELE2 = '#e6b597', CAB = '#1d2b63', CAB2 = '#2f4596', JALECO = '#eef2fb', JALECO2 = '#c3cbe0';
  const resp = Math.sin(t * 2.2) * 3;               // respiração
  c.save(); c.globalAlpha *= alpha; c.translate(x, y + resp * s * 0.3); c.scale(s, s);
  c.lineJoin = 'round'; c.lineCap = 'round';
  const contorno = (lw = 6) => { c.strokeStyle = CONT; c.lineWidth = lw; c.stroke(); };

  // ---------- corpo ----------
  // pernas
  c.fillStyle = '#26314f';
  retRed(c, -46, 215, 38, 80, 14); c.fill(); contorno(5);
  retRed(c, 8, 215, 38, 80, 14); c.fill(); contorno(5);
  c.fillStyle = '#e9edf7'; retRed(c, -52, 282, 50, 24, 10); c.fill(); contorno(5); retRed(c, 2, 282, 50, 24, 10); c.fill(); contorno(5);
  // jaleco
  c.beginPath(); c.moveTo(-58, 98); c.quadraticCurveTo(-82, 170, -74, 238); c.lineTo(74, 238); c.quadraticCurveTo(82, 170, 58, 98); c.closePath();
  c.fillStyle = JALECO; c.fill(); contorno();
  // camisa escura e lapelas
  c.beginPath(); c.moveTo(-26, 98); c.lineTo(0, 160); c.lineTo(26, 98); c.closePath(); c.fillStyle = '#1a2340'; c.fill();
  c.beginPath(); c.moveTo(-26, 98); c.lineTo(0, 160); c.lineTo(-14, 186); c.lineTo(-40, 104); c.closePath(); c.fillStyle = JALECO2; c.fill(); contorno(4);
  c.beginPath(); c.moveTo(26, 98); c.lineTo(0, 160); c.lineTo(14, 186); c.lineTo(40, 104); c.closePath(); c.fillStyle = JALECO2; c.fill(); contorno(4);
  linha(c, 0, 160, 0, 236, CONT, 4);
  // crachá hexagonal
  c.save(); c.translate(-40, 168); c.beginPath(); for (let i = 0; i < 6; i++) { const a = i * TAU / 6 + TAU / 12; c.lineTo(Math.cos(a) * 13, Math.sin(a) * 13); } c.closePath(); c.fillStyle = cor; c.fill(); contorno(3); c.restore();

  // ---------- braços ----------
  const braco = (ox, oy, hx, hy) => {
    const ex = (ox + hx) / 2 + (hx > ox ? 10 : -10), ey = (oy + hy) / 2 + 14;
    c.beginPath(); c.moveTo(ox, oy); c.quadraticCurveTo(ex, ey, hx, hy);
    c.strokeStyle = CONT; c.lineWidth = 34; c.stroke(); c.strokeStyle = JALECO; c.lineWidth = 24; c.stroke();
    c.beginPath(); c.arc(hx, hy, 15, 0, TAU); c.fillStyle = PELE; c.fill(); contorno(5);
  };
  // mão direita (do personagem fica à esquerda da tela? usamos a da direita da tela)
  let hx = 92, hy = 210;
  if (pose === 'segura') { hx = 120; hy = 30; }
  if (pose === 'aponta') { hx = 150; hy = 60; }
  if (pose === 'acena') { hx = 125 + Math.sin(t * 9) * 18; hy = -10 + Math.cos(t * 9) * 6; }
  if (mao) { hx = (mao[0] - x) / s; hy = (mao[1] - y - resp * s * 0.3) / s; }
  braco(-60, 112, -88, 208);
  braco(60, 112, hx, hy);
  if (pose === 'aponta' && !mao) { c.save(); c.translate(hx, hy); c.rotate(-0.5); retRed(c, 6, -5, 26, 10, 5); c.fillStyle = PELE; c.fill(); contorno(4); c.restore(); }

  // ---------- cabeça ----------
  // cabelo de trás (espetado)
  c.beginPath();
  const pontas = [[-118, 30], [-150, -40], [-112, -70], [-140, -128], [-70, -120], [-62, -178], [-10, -138], [30, -190], [58, -128], [128, -150], [108, -80], [160, -52], [116, 6], [128, 52]];
  c.moveTo(-104, 70);
  for (const [px, py] of pontas) c.lineTo(px, py + Math.sin(t * 3 + px) * 2);
  c.lineTo(104, 70); c.closePath();
  c.fillStyle = CAB; c.fill(); contorno();
  // rosto
  c.beginPath(); c.moveTo(-92, -10); c.quadraticCurveTo(-96, 74, -30, 98); c.quadraticCurveTo(0, 110, 30, 98); c.quadraticCurveTo(96, 74, 92, -10);
  c.quadraticCurveTo(92, -96, 0, -98); c.quadraticCurveTo(-92, -96, -92, -10); c.closePath();
  c.fillStyle = PELE; c.fill(); contorno();
  // orelhas
  for (const sx of [-1, 1]) { c.beginPath(); c.ellipse(sx * 94, 18, 14, 22, 0, 0, TAU); c.fillStyle = PELE; c.fill(); contorno(5); }
  // sombra do cabelo no rosto
  c.save(); c.beginPath(); c.moveTo(-92, -10); c.quadraticCurveTo(-96, 74, -30, 98); c.quadraticCurveTo(0, 110, 30, 98); c.quadraticCurveTo(96, 74, 92, -10); c.quadraticCurveTo(92, -96, 0, -98); c.quadraticCurveTo(-92, -96, -92, -10); c.clip();
  c.fillStyle = PELE2; c.beginPath(); c.moveTo(-100, -40); for (let i = 0; i <= 8; i++) c.lineTo(-100 + i * 25, -30 + (i % 2) * 22); c.lineTo(100, -120); c.lineTo(-100, -120); c.closePath(); c.fill();
  c.restore();
  // franja
  c.beginPath(); c.moveTo(-100, -20);
  const franja = [[-84, -8], [-74, -48], [-52, 0], [-36, -46], [-12, -6], [4, -52], [28, -4], [44, -50], [66, -2], [78, -44], [100, -14], [104, -70], [60, -112], [0, -118], [-60, -112], [-104, -72]];
  for (const [px, py] of franja) c.lineTo(px, py);
  c.closePath(); c.fillStyle = CAB; c.fill(); contorno();
  // mechas de brilho
  c.strokeStyle = CAB2; c.lineWidth = 7;
  c.beginPath(); c.moveTo(-58, -96); c.quadraticCurveTo(-40, -70, -42, -42); c.stroke();
  c.beginPath(); c.moveTo(22, -104); c.quadraticCurveTo(34, -80, 34, -50); c.stroke();
  // óculos de laboratório na testa
  c.save(); c.translate(0, -84);
  c.fillStyle = '#323c5c'; retRed(c, -100, -10, 200, 20, 10); c.fill(); contorno(4);
  for (const sx of [-1, 1]) {
    c.beginPath(); c.arc(sx * 40, 0, 27, 0, TAU); c.fillStyle = '#4a5578'; c.fill(); contorno(5);
    const g = c.createRadialGradient(sx * 40 - 8, -8, 2, sx * 40, 0, 22); g.addColorStop(0, '#ffffff'); g.addColorStop(0.3, cor); g.addColorStop(1, '#0b3a5a');
    c.beginPath(); c.arc(sx * 40, 0, 19, 0, TAU); c.fillStyle = g; c.fill();
  }
  c.restore();

  // ---------- rosto ----------
  const piscando = (t % 3.4) > 3.27;
  const ox = olhar * 6;
  for (const sx of [-1, 1]) {
    const ex = sx * 40, ey = 22;
    // sobrancelha
    const sobe = expr === 'choque' ? -12 : expr === 'serio' ? 4 : expr === 'confiante' ? (sx < 0 ? 2 : -6) : -4;
    const incl = expr === 'serio' ? sx * 0.25 : expr === 'confiante' ? sx * 0.15 : -sx * 0.08;
    c.save(); c.translate(ex, ey - 46 + sobe); c.rotate(incl); linha(c, -20, 0, 20, 0, CONT, 7); c.restore();
    if (piscando && expr !== 'choque') { c.beginPath(); c.moveTo(ex - 22, ey + 4); c.quadraticCurveTo(ex, ey + 14, ex + 22, ey + 4); contorno(6); continue; }
    const rx = expr === 'choque' ? 20 : 22, ry = expr === 'choque' ? 24 : 30;
    c.beginPath(); c.ellipse(ex, ey, rx, ry, 0, 0, TAU); c.fillStyle = '#ffffff'; c.fill(); contorno(5);
    // íris
    const ir = expr === 'choque' ? 9 : 17;
    const gi = c.createLinearGradient(ex, ey - ir, ex, ey + ir); gi.addColorStop(0, '#0d4f7a'); gi.addColorStop(1, cor);
    c.beginPath(); c.ellipse(ex + ox, ey + 3, ir * 0.9, ir * 1.2, 0, 0, TAU); c.fillStyle = gi; c.fill();
    c.beginPath(); c.ellipse(ex + ox, ey + 4, ir * 0.4, ir * 0.55, 0, 0, TAU); c.fillStyle = CONT; c.fill();
    c.fillStyle = '#fff'; c.beginPath(); c.arc(ex + ox - 6, ey - 8, 6, 0, TAU); c.fill(); c.beginPath(); c.arc(ex + ox + 6, ey + 10, 3, 0, TAU); c.fill();
    // cílio superior
    c.beginPath(); c.ellipse(ex, ey, rx, ry, 0, Math.PI * 1.08, Math.PI * 1.92); c.strokeStyle = CONT; c.lineWidth = 8; c.stroke();
  }
  // bochechas
  c.fillStyle = 'rgba(255,120,140,0.35)'; for (const sx of [-1, 1]) { c.beginPath(); c.ellipse(sx * 58, 62, 15, 8, 0, 0, TAU); c.fill(); }
  // boca
  c.fillStyle = '#7a2534';
  if (expr === 'feliz') { c.beginPath(); c.moveTo(-18, 70); c.quadraticCurveTo(0, 96, 18, 70); c.closePath(); c.fill(); contorno(4); }
  else if (expr === 'choque') { c.beginPath(); c.ellipse(0, 78, 11, 15, 0, 0, TAU); c.fill(); contorno(4); }
  else if (expr === 'confiante') { c.beginPath(); c.moveTo(-16, 74); c.quadraticCurveTo(4, 86, 20, 68); contorno(5); }
  else { linha(c, -14, 76, 14, 76, CONT, 5); }
  // gota de suor no choque
  if (expr === 'choque') { c.beginPath(); c.moveTo(104, -30); c.quadraticCurveTo(118, -6, 104, 4); c.quadraticCurveTo(90, -6, 104, -30); c.fillStyle = '#9fe4ff'; c.fill(); contorno(3); }
  c.restore();
}
