// Elenco original do Laboratório Otaku: um personagem próprio para cada tipo de anime do canal.
// Nenhum é cópia de personagem existente: cabelo, roupa, cores e acessórios são inventados.
//   ninja (Ren), pirata (Nina), feiticeiro (Sora), alquimista (Teo), cacador (Bia), treinador (Lu + Fofo)
// Uso: personagem(c, 'ninja', x, y, s, t, { expr, pose, olhar, mao, alpha, cor })  (mesmas opções do mascote)
'use strict';

const ELENCO = {
  ninja: {
    nome: 'Ren', pele: '#f2cdb0', pele2: '#ddb092', cab: '#17675f', cab2: '#2a9a8c',
    roupa: '#7a2440', roupa2: '#5a1830', calca: '#2b2f45', sapato: '#3b3f57', luva: '#d9dbe4', olhos: '#3fbfa8',
  },
  pirata: {
    nome: 'Nina', pele: '#e8b892', pele2: '#d39c76', cab: '#8a3b22', cab2: '#b45a35',
    roupa: '#1f3466', roupa2: '#16264d', calca: '#3a2a22', sapato: '#2a1c16', luva: null, olhos: '#3f7fd0',
  },
  feiticeiro: {
    nome: 'Sora', pele: '#f5d9c4', pele2: '#e2bba1', cab: '#4a2a3a', cab2: '#6e3f57',
    roupa: '#b9a6e6', roupa2: '#8f7bc9', calca: '#3b3357', sapato: '#2a2440', luva: null, olhos: '#9b7cff',
  },
  alquimista: {
    nome: 'Teo', pele: '#f0cfb6', pele2: '#dbb194', cab: '#1b1b24', cab2: '#3a3a4a',
    roupa: '#5d6b3a', roupa2: '#46512b', calca: '#2c2a26', sapato: '#3a2e22', luva: '#f4f4f0', olhos: '#d9a03a',
  },
  cacador: {
    nome: 'Bia', pele: '#c98e6a', pele2: '#b17654', cab: '#c4642a', cab2: '#e08a48',
    roupa: '#d9c08a', roupa2: '#b89d66', calca: '#4a3426', sapato: '#2e221a', luva: null, olhos: '#5a9a3a',
  },
  treinador: {
    nome: 'Lu', pele: '#f6d8c2', pele2: '#e3b9a0', cab: '#5a3a86', cab2: '#7a58ad',
    roupa: '#1f8a8a', roupa2: '#176b6b', calca: '#2b3550', sapato: '#f2c53d', luva: null, olhos: '#e0607a',
  },
};

function personagem(c, tipo, x, y, s, t, { expr = 'feliz', pose = 'parado', olhar = 0, mao = null, alpha = 1, cor = PAL.cor, bicho = true } = {}) {
  const P = ELENCO[tipo];
  if (!P) return mascote(c, x, y, s, t, { expr, pose, olhar, mao, alpha, cor });
  if (alpha <= 0 || s <= 0) return;
  const CONT = '#0b1020';
  const resp = Math.sin(t * 2.2) * 3;
  if (tipo === 'treinador' && bicho) fofo(c, x + 175 * s, y + 250 * s, s * 0.85, t, { alpha, expr });
  c.save(); c.globalAlpha *= alpha; c.translate(x, y + resp * s * 0.3); c.scale(s, s);
  c.lineJoin = 'round'; c.lineCap = 'round';
  const contorno = (lw = 6) => { c.strokeStyle = CONT; c.lineWidth = lw; c.stroke(); };
  const preenche = (cor, lw = 6) => { c.fillStyle = cor; c.fill(); contorno(lw); };

  // ---------- atrás da cabeça ----------
  if (tipo === 'feiticeiro') {          // capuz caído atrás dos ombros
    c.beginPath(); c.moveTo(-120, 60); c.quadraticCurveTo(-150, -60, -60, -110); c.quadraticCurveTo(0, -130, 60, -110);
    c.quadraticCurveTo(150, -60, 120, 60); c.closePath(); preenche(P.roupa2);
  }
  if (tipo === 'ninja') {               // ponta do cachecol voando atrás
    const ond = Math.sin(t * 4) * 10;
    c.beginPath(); c.moveTo(-40, 110); c.quadraticCurveTo(-140, 110 + ond, -190, 70 - ond); c.lineTo(-180, 100 - ond); c.quadraticCurveTo(-130, 140 + ond, -30, 128); c.closePath(); preenche('#8d93a6', 5);
  }

  // ---------- corpo ----------
  c.fillStyle = P.calca;
  retRed(c, -46, 215, 38, 80, 14); c.fill(); contorno(5);
  retRed(c, 8, 215, 38, 80, 14); c.fill(); contorno(5);
  c.fillStyle = P.sapato; retRed(c, -52, 282, 50, 24, 10); c.fill(); contorno(5); retRed(c, 2, 282, 50, 24, 10); c.fill(); contorno(5);
  const larg = tipo === 'feiticeiro' ? 92 : tipo === 'pirata' || tipo === 'alquimista' ? 84 : 76;
  const baixo = tipo === 'pirata' || tipo === 'alquimista' || tipo === 'feiticeiro' ? 262 : 238;
  c.beginPath(); c.moveTo(-58, 98); c.quadraticCurveTo(-larg - 6, 170, -larg, baixo); c.lineTo(larg, baixo); c.quadraticCurveTo(larg + 6, 170, 58, 98); c.closePath();
  preenche(P.roupa);
  if (tipo === 'ninja') {               // faixa na cintura e cachecol
    retRed(c, -76, 176, 152, 24, 8); preenche(P.roupa2, 4);
    c.beginPath(); c.moveTo(18, 188); c.lineTo(34, 236); c.lineTo(48, 230); c.lineTo(32, 188); c.closePath(); preenche(P.roupa2, 4);
    retRed(c, -62, 88, 124, 36, 16); preenche('#8d93a6', 5);
  } else if (tipo === 'pirata') {       // camisa listrada e botões dourados
    c.save(); c.beginPath(); c.moveTo(-24, 98); c.lineTo(0, 190); c.lineTo(24, 98); c.closePath(); c.clip();
    for (let i = 0; i < 8; i++) { c.fillStyle = i % 2 ? '#f1f1f1' : '#c23b3b'; c.fillRect(-30, 98 + i * 12, 60, 12); }
    c.restore();
    c.beginPath(); c.moveTo(-24, 98); c.lineTo(0, 190); c.lineTo(24, 98); contorno(4);
    for (const by of [140, 180, 220]) for (const sx of [-1, 1]) { c.beginPath(); c.arc(sx * 34, by, 7, 0, TAU); preenche('#f2c53d', 3); }
    retRed(c, -84, 226, 168, 16, 6); preenche(P.roupa2, 4);
  } else if (tipo === 'feiticeiro') {   // cordão vermelho com borla
    c.beginPath(); c.moveTo(-40, 104); c.quadraticCurveTo(0, 150, 40, 104); c.strokeStyle = '#c8323c'; c.lineWidth = 8; c.stroke();
    c.beginPath(); c.moveTo(0, 128); c.lineTo(-10, 168); c.lineTo(10, 168); c.closePath(); preenche('#c8323c', 3);
    linha(c, 0, 168, 0, 260, CONT, 4);
  } else if (tipo === 'alquimista') {   // casaco longo com lapelas e camisa clara
    c.beginPath(); c.moveTo(-26, 98); c.lineTo(0, 150); c.lineTo(26, 98); c.closePath(); c.fillStyle = '#e8e2d0'; c.fill();
    for (const sx of [-1, 1]) { c.beginPath(); c.moveTo(sx * 26, 98); c.lineTo(0, 150); c.lineTo(sx * 18, 200); c.lineTo(sx * 46, 104); c.closePath(); preenche(P.roupa2, 4); }
    linha(c, 0, 150, 0, 262, CONT, 4);
  } else if (tipo === 'cacador') {      // colete de bolsos sobre camiseta vermelha, bússola
    c.beginPath(); c.moveTo(-24, 98); c.lineTo(-20, 238); c.lineTo(20, 238); c.lineTo(24, 98); c.closePath(); preenche('#9c2f2f', 4);
    for (const sx of [-1, 1]) { retRed(c, sx > 0 ? 30 : -66, 150, 36, 30, 6); preenche(P.roupa2, 4); retRed(c, sx > 0 ? 30 : -66, 196, 36, 28, 6); preenche(P.roupa2, 4); }
    linha(c, -10, 100, 10, 196, '#3a2a1e', 4);
    c.beginPath(); c.arc(10, 200, 13, 0, TAU); preenche('#d9b45a', 4); linha(c, 10, 200, 10 + Math.cos(t * 2) * 8, 200 + Math.sin(t * 2) * 8, '#c8323c', 3);
  } else if (tipo === 'treinador') {    // capa de chuva com zíper amarelo e alça da bolsa
    linha(c, 0, 100, 0, 238, '#f2c53d', 6);
    c.beginPath(); c.moveTo(-60, 104); c.lineTo(52, 226); c.strokeStyle = '#6b4a2a'; c.lineWidth = 12; c.stroke();
    retRed(c, 36, 206, 40, 32, 8); preenche('#8a6238', 4);
    retRed(c, -76, 226, 152, 12, 6); preenche('#f2c53d', 3);
  }

  // ---------- braços ----------
  const mangas = P.roupa;
  const maoCor = P.luva || P.pele;
  const braco = (ox, oy, hx, hy) => {
    const ex = (ox + hx) / 2 + (hx > ox ? 10 : -10), ey = (oy + hy) / 2 + 14;
    c.beginPath(); c.moveTo(ox, oy); c.quadraticCurveTo(ex, ey, hx, hy);
    c.strokeStyle = CONT; c.lineWidth = 34; c.stroke(); c.strokeStyle = mangas; c.lineWidth = 24; c.stroke();
    c.beginPath(); c.arc(hx, hy, 15, 0, TAU); preenche(maoCor, 5);
    if (tipo === 'ninja') { for (const k of [-6, 4]) linha(c, hx - 13, hy + k, hx + 13, hy + k - 3, '#9aa0b4', 3); }
    if (tipo === 'alquimista') { c.save(); c.translate(hx, hy); c.beginPath(); c.arc(0, 0, 8, 0, TAU); c.moveTo(0, -8); c.lineTo(7, 4); c.lineTo(-7, 4); c.closePath(); c.strokeStyle = '#c8323c'; c.lineWidth = 2; c.stroke(); c.restore(); }
  };
  let hx = 92, hy = 210;
  if (pose === 'segura') { hx = 120; hy = 30; }
  if (pose === 'aponta') { hx = 150; hy = 60; }
  if (pose === 'acena') { hx = 125 + Math.sin(t * 9) * 18; hy = -10 + Math.cos(t * 9) * 6; }
  if (pose === 'golpe') { hx = 170 + Math.sin(t * 20) * 3; hy = 120; }
  if (mao) { hx = (mao[0] - x) / s; hy = (mao[1] - y - resp * s * 0.3) / s; }
  braco(-60, 112, -88, 208);
  braco(60, 112, hx, hy);

  // ---------- cabeça ----------
  const rosto = () => {
    c.beginPath(); c.moveTo(-92, -10); c.quadraticCurveTo(-96, 74, -30, 98); c.quadraticCurveTo(0, 110, 30, 98); c.quadraticCurveTo(96, 74, 92, -10);
    c.quadraticCurveTo(92, -96, 0, -98); c.quadraticCurveTo(-92, -96, -92, -10); c.closePath();
  };
  // cabelo de trás
  c.beginPath();
  if (tipo === 'pirata') {              // chanel arredondado até o queixo
    c.moveTo(-112, 84); c.quadraticCurveTo(-140, -60, -40, -112); c.quadraticCurveTo(0, -120, 40, -112); c.quadraticCurveTo(140, -60, 112, 84);
    c.quadraticCurveTo(80, 96, 70, 60); c.lineTo(-70, 60); c.quadraticCurveTo(-80, 96, -112, 84);
  } else if (tipo === 'cacador') {      // cachos
    c.moveTo(-104, 60);
    for (let i = 0; i <= 12; i++) { const a = Math.PI * (1.05 + i * 0.075); c.arc(Math.cos(a) * 112, Math.sin(a) * 104 - 6, 30, a - 1.1, a + 1.1); }
    c.lineTo(104, 60);
  } else if (tipo === 'ninja') {        // coque alto amarrado
    c.moveTo(-100, 60); c.quadraticCurveTo(-130, -70, -40, -110); c.quadraticCurveTo(0, -122, 40, -110); c.quadraticCurveTo(130, -70, 100, 60);
  } else if (tipo === 'alquimista') {   // curto e penteado
    c.moveTo(-98, 30); c.quadraticCurveTo(-118, -80, -20, -116); c.quadraticCurveTo(80, -122, 108, -50); c.quadraticCurveTo(116, 0, 98, 30);
  } else {                              // repicado curto (feiticeiro, treinador)
    const pts = [[-110, 20], [-128, -40], [-100, -66], [-112, -110], [-56, -104], [-30, -140], [10, -112], [50, -136], [64, -100], [116, -104], [102, -60], [128, -30], [108, 20]];
    c.moveTo(-100, 50); for (const [px, py] of pts) c.lineTo(px, py + Math.sin(t * 3 + px) * 2); c.lineTo(100, 50);
  }
  c.closePath(); preenche(P.cab);
  if (tipo === 'ninja') {
    c.beginPath(); c.arc(0, -150, 36, 0, TAU); preenche(P.cab);
    retRed(c, -24, -122, 48, 14, 6); preenche('#7a2440', 4);
    c.strokeStyle = P.cab2; c.lineWidth = 6; c.beginPath(); c.arc(-6, -156, 20, 3.6, 5.2); c.stroke();
  }
  rosto(); preenche(P.pele);
  for (const sx of [-1, 1]) { c.beginPath(); c.ellipse(sx * 94, 18, 14, 22, 0, 0, TAU); preenche(P.pele, 5); }
  // franja
  c.beginPath();
  if (tipo === 'ninja') {               // franja de lado, para a esquerda
    c.moveTo(104, -60); c.lineTo(80, -10); c.lineTo(50, -50); c.lineTo(10, 0); c.lineTo(-20, -44); c.lineTo(-70, 10); c.lineTo(-74, -40); c.lineTo(-100, -20); c.lineTo(-96, -80); c.quadraticCurveTo(0, -140, 104, -60);
  } else if (tipo === 'pirata') {       // franja reta
    c.moveTo(-100, -20); c.lineTo(-96, -12); for (let i = 0; i <= 10; i++) c.lineTo(-90 + i * 18, -30 + (i % 2) * 10); c.lineTo(100, -20); c.quadraticCurveTo(80, -118, 0, -116); c.quadraticCurveTo(-80, -118, -100, -20);
  } else if (tipo === 'alquimista') {   // risca de lado com mecha branca
    c.moveTo(-96, -10); c.quadraticCurveTo(-80, -60, -30, -62); c.quadraticCurveTo(40, -64, 100, -10); c.quadraticCurveTo(110, -100, 20, -114); c.quadraticCurveTo(-90, -112, -96, -10);
  } else if (tipo === 'cacador') {
    c.moveTo(-98, -6); for (let i = 0; i <= 7; i++) c.arc(-84 + i * 24, -52, 18, Math.PI, 0); c.lineTo(100, -6); c.quadraticCurveTo(96, -110, 0, -112); c.quadraticCurveTo(-96, -110, -98, -6);
  } else {
    const fr = [[-84, -8], [-70, -50], [-46, -4], [-26, -50], [0, -8], [20, -54], [44, -6], [64, -48], [84, -4], [100, -20], [100, -70], [60, -112], [0, -118], [-60, -112], [-104, -72]];
    c.moveTo(-100, -20); for (const [px, py] of fr) c.lineTo(px, py);
  }
  c.closePath(); preenche(P.cab);
  c.strokeStyle = P.cab2; c.lineWidth = 7;
  c.beginPath(); c.moveTo(-50, -98); c.quadraticCurveTo(-36, -76, -38, -52); c.stroke();
  if (tipo === 'alquimista') { c.strokeStyle = '#f0f0f0'; c.lineWidth = 12; c.beginPath(); c.moveTo(30, -110); c.quadraticCurveTo(50, -60, 70, -30); c.stroke(); }

  // ---------- chapéus ----------
  if (tipo === 'pirata') {              // tricórnio com pena
    c.save(); c.translate(0, -96);
    c.beginPath(); c.moveTo(-150, 10); c.quadraticCurveTo(-120, -30, -70, -40); c.quadraticCurveTo(-40, -110, 0, -112); c.quadraticCurveTo(40, -110, 70, -40);
    c.quadraticCurveTo(120, -30, 150, 10); c.quadraticCurveTo(0, -20, -150, 10); c.closePath(); preenche('#1b1b24');
    c.beginPath(); c.moveTo(-130, 4); c.quadraticCurveTo(0, -24, 130, 4); c.strokeStyle = '#f2c53d'; c.lineWidth = 6; c.stroke();
    const bal = Math.sin(t * 3) * 0.08;
    c.save(); c.translate(60, -60); c.rotate(0.6 + bal); c.beginPath(); c.ellipse(0, -50, 16, 56, 0, 0, TAU); preenche('#2fb3a0', 4); linha(c, 0, 0, 0, -100, CONT, 3); c.restore();
    c.restore();
  } else if (tipo === 'cacador') {      // boné virado para trás
    c.beginPath(); c.moveTo(-96, -50); c.quadraticCurveTo(-90, -136, 0, -138); c.quadraticCurveTo(90, -136, 96, -50); c.closePath(); preenche('#2f5a8a');
    c.beginPath(); c.moveTo(-96, -60); c.quadraticCurveTo(-150, -62, -150, -40); c.quadraticCurveTo(-120, -36, -92, -44); c.closePath(); preenche('#244a72', 5);
    c.beginPath(); c.arc(0, -136, 9, 0, TAU); preenche('#244a72', 4);
  } else if (tipo === 'treinador') {    // gorro com pompom
    c.beginPath(); c.moveTo(-104, -40); c.quadraticCurveTo(-100, -150, 0, -152); c.quadraticCurveTo(100, -150, 104, -40); c.closePath(); preenche('#f2c53d');
    retRed(c, -110, -62, 220, 34, 14); preenche('#e0a92a', 5);
    c.beginPath(); c.arc(0, -160, 24 + Math.sin(t * 6) * 1.5, 0, TAU); preenche('#ffffff', 5);
  }
  if (tipo === 'feiticeiro') {          // talismãs de papel flutuando
    for (let i = 0; i < 3; i++) {
      const a = t * 0.9 + i * TAU / 3, px = Math.cos(a) * 150, py = -60 + Math.sin(a) * 30 + Math.sin(t * 3 + i) * 8;
      c.save(); c.translate(px, py); c.rotate(Math.sin(t * 2 + i) * 0.25);
      retRed(c, -14, -32, 28, 64, 3); preenche('#f3ead2', 3);
      c.strokeStyle = '#c8323c'; c.lineWidth = 3; c.beginPath(); c.moveTo(-6, -20); c.lineTo(6, -10); c.lineTo(-6, 0); c.lineTo(6, 10); c.moveTo(0, 16); c.arc(0, 18, 5, 0, TAU); c.stroke();
      c.restore();
    }
  }

  // ---------- olhos, boca ----------
  const piscando = (t % 3.4) > 3.27;
  const ox = olhar * 6;
  for (const sx of [-1, 1]) {
    const ex = sx * 40, ey = 22;
    const sobe = expr === 'choque' ? -12 : expr === 'serio' ? 4 : expr === 'confiante' ? (sx < 0 ? 2 : -6) : -4;
    const incl = expr === 'serio' ? sx * 0.25 : expr === 'confiante' ? sx * 0.15 : -sx * 0.08;
    c.save(); c.translate(ex, ey - 46 + sobe); c.rotate(incl); linha(c, -20, 0, 20, 0, CONT, 7); c.restore();
    if (piscando && expr !== 'choque') { c.beginPath(); c.moveTo(ex - 22, ey + 4); c.quadraticCurveTo(ex, ey + 14, ex + 22, ey + 4); contorno(6); continue; }
    const rx = expr === 'choque' ? 20 : 22, ry = expr === 'choque' ? 24 : (tipo === 'ninja' ? 24 : 30);
    c.beginPath(); c.ellipse(ex, ey, rx, ry, 0, 0, TAU); c.fillStyle = '#ffffff'; c.fill(); contorno(5);
    const ir = expr === 'choque' ? 9 : 16;
    const gi = c.createLinearGradient(ex, ey - ir, ex, ey + ir); gi.addColorStop(0, mistura(P.olhos, '#000000', 0.5)); gi.addColorStop(1, P.olhos);
    c.beginPath(); c.ellipse(ex + ox, ey + 3, ir * 0.9, ir * 1.15, 0, 0, TAU); c.fillStyle = gi; c.fill();
    c.beginPath(); c.ellipse(ex + ox, ey + 4, ir * 0.4, ir * 0.55, 0, 0, TAU); c.fillStyle = CONT; c.fill();
    c.fillStyle = '#fff'; c.beginPath(); c.arc(ex + ox - 6, ey - 7, 5.5, 0, TAU); c.fill(); c.beginPath(); c.arc(ex + ox + 6, ey + 10, 3, 0, TAU); c.fill();
    c.beginPath(); c.ellipse(ex, ey, rx, ry, 0, Math.PI * 1.08, Math.PI * 1.92); c.strokeStyle = CONT; c.lineWidth = 8; c.stroke();
  }
  if (tipo === 'alquimista') { for (const sx of [-1, 1]) { c.beginPath(); c.arc(sx * 40, 22, 34, 0, TAU); c.strokeStyle = '#c9a24a'; c.lineWidth = 5; c.stroke(); } linha(c, -6, 18, 6, 18, '#c9a24a', 5); }
  if (tipo === 'cacador') { c.fillStyle = 'rgba(90,50,30,0.45)'; for (const [fx, fy] of [[-62, 50], [-50, 56], [-66, 60], [62, 50], [50, 56], [66, 60]]) { c.beginPath(); c.arc(fx, fy, 2.6, 0, TAU); c.fill(); } }
  c.fillStyle = 'rgba(255,120,140,0.32)'; for (const sx of [-1, 1]) { c.beginPath(); c.ellipse(sx * 58, 64, 15, 8, 0, 0, TAU); c.fill(); }
  c.fillStyle = '#7a2534';
  if (expr === 'feliz') { c.beginPath(); c.moveTo(-18, 70); c.quadraticCurveTo(0, 96, 18, 70); c.closePath(); c.fill(); contorno(4); }
  else if (expr === 'choque') { c.beginPath(); c.ellipse(0, 78, 11, 15, 0, 0, TAU); c.fill(); contorno(4); }
  else if (expr === 'confiante') { c.beginPath(); c.moveTo(-16, 74); c.quadraticCurveTo(4, 86, 20, 68); contorno(5); }
  else { linha(c, -14, 76, 14, 76, CONT, 5); }
  if (expr === 'choque') { c.beginPath(); c.moveTo(104, -30); c.quadraticCurveTo(118, -6, 104, 4); c.quadraticCurveTo(90, -6, 104, -30); c.fillStyle = '#9fe4ff'; c.fill(); contorno(3); }
  c.restore();
}

// Fofo: a criatura inventada do treinador (nuvenzinha com broto de folha)
function fofo(c, x, y, s, t, { alpha = 1, expr = 'feliz' } = {}) {
  const CONT = '#0b1020', pulo = Math.abs(Math.sin(t * 3.2)) * 18;
  c.save(); c.globalAlpha *= alpha; c.translate(x, y - pulo * s); c.scale(s, s * (1 - 0.04 * Math.cos(t * 6.4)));
  c.lineJoin = 'round'; c.lineCap = 'round';
  c.beginPath();
  for (const [bx, by, r] of [[-40, 0, 38], [0, -22, 44], [40, 0, 38], [0, 18, 46]]) { c.moveTo(bx + r, by); c.arc(bx, by, r, 0, TAU); }
  c.fillStyle = '#bfe6ff'; c.fill();
  c.beginPath(); c.ellipse(0, 4, 78, 54, 0, 0, TAU); c.strokeStyle = CONT; c.lineWidth = 5; c.stroke();
  c.beginPath(); c.ellipse(0, 4, 76, 52, 0, 0, TAU); c.fillStyle = '#bfe6ff'; c.fill();
  c.beginPath(); c.moveTo(0, -48); c.quadraticCurveTo(-4, -70, 4, -82); c.strokeStyle = '#3f8a3a'; c.lineWidth = 5; c.stroke();
  for (const sx of [-1, 1]) { c.save(); c.translate(2, -80); c.rotate(sx * 0.9 + Math.sin(t * 4) * 0.1); c.beginPath(); c.ellipse(sx * 14, 0, 16, 8, 0, 0, TAU); c.fillStyle = '#6cc35a'; c.fill(); c.strokeStyle = CONT; c.lineWidth = 3; c.stroke(); c.restore(); }
  const pisca = (t % 2.9) > 2.8;
  for (const sx of [-1, 1]) {
    if (pisca) { linha(c, sx * 22 - 7, 0, sx * 22 + 7, 0, CONT, 4); continue; }
    c.beginPath(); c.ellipse(sx * 22, 0, 7, expr === 'choque' ? 11 : 9, 0, 0, TAU); c.fillStyle = CONT; c.fill();
    c.fillStyle = '#fff'; c.beginPath(); c.arc(sx * 22 - 2, -3, 2.5, 0, TAU); c.fill();
  }
  c.fillStyle = 'rgba(255,120,140,0.45)'; for (const sx of [-1, 1]) { c.beginPath(); c.ellipse(sx * 40, 14, 9, 5, 0, 0, TAU); c.fill(); }
  c.beginPath(); c.moveTo(-6, 16); c.quadraticCurveTo(0, 22, 6, 16); c.strokeStyle = CONT; c.lineWidth = 3; c.stroke();
  c.restore();
}
