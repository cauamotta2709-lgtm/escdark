// Laboratório Otaku: peças reutilizáveis por todos os episódios (rótulos, barras, esfera, balão, toro...).
// As cenas de cada episódio ficam em escritorio/bancos/laboratorio-otaku/episodios/<NNN-slug>/cenas.js.
'use strict';

const CX = 540, CY = 760;

// ---------------- peças ----------------
function etiqueta(c, t, t0, txt, { cor = PAL.cor, y = 330, extra = null, corExtra = PAL.cor2, tExtra = 1e9 } = {}) {
  const a = entra(t, t0, 0.45);
  if (a <= 0) return;
  c.save(); c.globalAlpha *= a; c.translate(0, (1 - a) * 24);
  c.font = F.mono(30, 700); c.letterSpacing = '4px';
  const w = c.measureText(txt).width + 56;
  let wx = 0;
  if (extra) { c.font = F.mono(26, 800); wx = c.measureText(extra).width + 40; }
  const tot = w + (extra ? wx + 16 : 0);
  const x0 = CX - tot / 2;
  retRed(c, x0, y - 30, w, 60, 30); c.fillStyle = rgba(cor, 0.12); c.fill(); c.strokeStyle = rgba(cor, 0.7); c.lineWidth = 2.5; c.stroke();
  c.font = F.mono(30, 700); c.fillStyle = cor; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(txt, x0 + w / 2, y + 1);
  if (extra) {
    const ae = entra(t, tExtra, 0.35, E.back);
    if (ae > 0) {
      c.save(); c.globalAlpha *= clamp(ae); const ex = x0 + w + 16;
      c.translate(ex + wx / 2, y); c.scale(ae, ae); c.translate(-(ex + wx / 2), -y);
      retRed(c, ex, y - 28, wx, 56, 10); c.fillStyle = corExtra; c.fill();
      c.font = F.mono(26, 800); c.letterSpacing = '3px'; c.fillStyle = '#05070d'; c.fillText(extra, ex + wx / 2, y + 1);
      c.restore();
    }
  }
  c.restore();
}

function barra(c, x, y, w, h, k, cor, { fundo = 'rgba(255,255,255,0.08)', glow = 16 } = {}) {
  c.save();
  retRed(c, x, y, w, h, h / 2); c.fillStyle = fundo; c.fill();
  if (k > 0.001) { c.shadowColor = cor; c.shadowBlur = glow; retRed(c, x, y, Math.max(h, w * clamp(k)), h, h / 2); c.fillStyle = cor; c.fill(); }
  c.restore();
}

function leitura(c, t, t0, rot, valor, x, y, { cor = PAL.tinta, alinha = 'center', px = 64, corRot = PAL.apagado } = {}) {
  const a = entra(t, t0, 0.4);
  if (a <= 0) return;
  rotulo(c, rot, x, y - px * 0.78, { alinha, alpha: a, px: 26, cor: corRot });
  texto(c, valor, x, y, { fonte: F.titulo(px), cor, alinha, alpha: a, espaco: 1 });
}

// esfera de energia girando em todas as direções (a "assinatura" visual do canal)
function esfera(c, cx, cy, R, t, { intens = 1, cor = PAL.cor, aneis = 14, seed = 11, nucleo = 1 } = {}) {
  if (R <= 1) return;
  const r = rng(seed);
  c.save();
  // halo
  const h = c.createRadialGradient(cx, cy, R * 0.2, cx, cy, R * 1.9);
  h.addColorStop(0, rgba(cor, 0.35 * intens)); h.addColorStop(0.5, rgba(cor, 0.12 * intens)); h.addColorStop(1, rgba(cor, 0));
  c.fillStyle = h; c.beginPath(); c.arc(cx, cy, R * 1.9, 0, TAU); c.fill();
  c.globalCompositeOperation = 'lighter';
  const esc = R / 220;
  for (let i = 0; i < aneis; i++) {
    const ax = r() * TAU, ay = r() * TAU, w = (2.2 + r() * 3.2) * (r() < 0.5 ? -1 : 1), raio = R * (0.62 + r() * 0.42), fase = r() * TAU;
    for (let k = 0; k < 2; k++) {
      const cabeca = fase + k * Math.PI + w * t, comp = 1.5 + r() * 0.8;
      const N = 40, pts = [];
      for (let j = 0; j <= N; j++) {
        const th = cabeca - comp * j / N * Math.sign(w);
        let p = [Math.cos(th) * raio, Math.sin(th) * raio, 0];
        p = rotX(p, ax + t * 0.3); p = rotY(p, ay + t * 0.21);
        pts.push([cx + p[0], cy + p[1], p[2] / raio]);
      }
      // cauda em 4 pedaços: mais grossa e clara na cabeça
      c.lineCap = 'butt'; c.lineJoin = 'round';
      for (let q = 0; q < 4; q++) {
        const a = q * 10, bq = a + 10, f = 1 - q / 4;
        const prof = 0.55 + 0.45 * (pts[a + 5][2] + 1) / 2;
        c.beginPath(); c.moveTo(pts[a][0], pts[a][1]);
        for (let j = a + 1; j <= bq; j++) c.lineTo(pts[j][0], pts[j][1]);
        c.strokeStyle = rgba(cor, 0.22 * f * prof * intens); c.lineWidth = (10 + 14 * f) * esc; c.stroke();
        c.strokeStyle = rgba(cor, 0.85 * f * prof * intens); c.lineWidth = (2.5 + 6 * f) * esc; c.stroke();
        if (q === 0) { c.strokeStyle = `rgba(255,255,255,${0.85 * prof})`; c.lineWidth = 2.6 * esc; c.stroke(); }
      }
    }
  }
  // núcleo
  if (nucleo > 0) {
    const g = c.createRadialGradient(cx, cy, 0, cx, cy, R * 0.62);
    g.addColorStop(0, `rgba(255,255,255,${0.95 * nucleo})`); g.addColorStop(0.35, rgba(cor, 0.75 * nucleo)); g.addColorStop(1, rgba(cor, 0));
    c.fillStyle = g; c.beginPath(); c.arc(cx, cy, R * 0.62, 0, TAU); c.fill();
  }
  // faíscas
  for (let i = 0; i < 26; i++) {
    const a = r() * TAU + t * (1.5 + r() * 3), rr = R * (0.95 + 0.25 * r()) + Math.sin(t * 9 + i) * 6;
    c.fillStyle = `rgba(255,255,255,${0.35 + 0.5 * r()})`;
    c.beginPath(); c.arc(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr * 0.92, 1.5 + 2 * r(), 0, TAU); c.fill();
  }
  c.restore();
}

// contorno ondulado (balões)
function formaOndulada(c, cx, cy, R, t, amp, { sy = 1.08, seed = 2, n = 120 } = {}) {
  const r = rng(seed); const harm = [];
  for (let k = 2; k <= 6; k++) harm.push([k, r() * TAU, 2 + r() * 5, r() * 0.6 + 0.4]);
  c.beginPath();
  for (let i = 0; i <= n; i++) {
    const th = i / n * TAU;
    let d = 1;
    for (const [k, ph, w, a] of harm) d += amp * a * Math.sin(k * th + ph + w * t) / k;
    const x = cx + Math.cos(th) * R * d, y = cy + Math.sin(th) * R * d * sy;
    if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
  }
  c.closePath();
}

function balao(c, cx, cy, R, t, { amp = 0.02, tipo = 'agua', alpha = 1, seed = 2 } = {}) {
  c.save(); c.globalAlpha *= alpha;
  // nó
  const ny = cy + R * 1.08 * (1 + amp * 0.5);
  c.fillStyle = tipo === 'agua' ? '#2a8fd8' : 'rgba(220,230,255,0.75)';
  c.beginPath(); c.moveTo(cx, ny - 6); c.lineTo(cx - 16, ny + 22); c.lineTo(cx + 16, ny + 22); c.closePath(); c.fill();
  c.strokeStyle = 'rgba(220,230,255,0.45)'; c.lineWidth = 2.5;
  c.beginPath(); c.moveTo(cx, ny + 22); c.bezierCurveTo(cx + 18, ny + 70, cx - 18, ny + 110, cx + 6, ny + 160); c.stroke();
  formaOndulada(c, cx, cy, R, t, amp, { seed });
  const g = c.createRadialGradient(cx - R * 0.3, cy - R * 0.35, R * 0.1, cx, cy, R * 1.1);
  if (tipo === 'agua') { g.addColorStop(0, 'rgba(140,225,255,0.55)'); g.addColorStop(0.6, 'rgba(40,140,230,0.45)'); g.addColorStop(1, 'rgba(10,50,140,0.65)'); }
  else { g.addColorStop(0, 'rgba(255,255,255,0.20)'); g.addColorStop(0.7, 'rgba(200,215,255,0.08)'); g.addColorStop(1, 'rgba(200,215,255,0.18)'); }
  c.fillStyle = g; c.fill();
  c.strokeStyle = tipo === 'agua' ? 'rgba(150,225,255,0.9)' : 'rgba(230,238,255,0.75)'; c.lineWidth = 4; c.stroke();
  // reflexo
  c.save(); c.translate(cx - R * 0.42, cy - R * 0.48); c.rotate(-0.6);
  c.fillStyle = 'rgba(255,255,255,0.55)'; c.beginPath(); c.ellipse(0, 0, R * 0.16, R * 0.07, 0, 0, TAU); c.fill(); c.restore();
  c.restore();
}

// arco elíptico com ponta de seta (giros dentro do balão)
function giro(c, cx, cy, rx, ry, rot, a0, comp, cor, lw = 6, alpha = 1) {
  const pt = th => { const x = rx * Math.cos(th), y = ry * Math.sin(th); return [cx + x * Math.cos(rot) - y * Math.sin(rot), cy + x * Math.sin(rot) + y * Math.cos(rot)]; };
  c.save(); c.globalAlpha *= alpha; c.strokeStyle = cor; c.fillStyle = cor; c.lineWidth = lw; c.lineCap = 'round';
  c.beginPath();
  for (let i = 0; i <= 30; i++) { const p = pt(a0 + comp * i / 30); if (i === 0) c.moveTo(p[0], p[1]); else c.lineTo(p[0], p[1]); }
  c.stroke();
  const e = pt(a0 + comp), e2 = pt(a0 + comp - 0.08);
  const ang = Math.atan2(e[1] - e2[1], e[0] - e2[0]), cab = lw * 3.4;
  c.beginPath(); c.moveTo(e[0] + Math.cos(ang) * cab * 0.6, e[1] + Math.sin(ang) * cab * 0.6);
  c.lineTo(e[0] + Math.cos(ang + 2.4) * cab, e[1] + Math.sin(ang + 2.4) * cab);
  c.lineTo(e[0] + Math.cos(ang - 2.4) * cab, e[1] + Math.sin(ang - 2.4) * cab); c.closePath(); c.fill();
  c.restore();
}

function check(c, x, y, s, k, cor = PAL.verde) {
  if (k <= 0) return;
  c.save(); c.strokeStyle = cor; c.lineWidth = 10 * s; c.lineCap = 'round'; c.lineJoin = 'round'; c.shadowColor = cor; c.shadowBlur = 20;
  caminhoParcial(c, [[x - 34 * s, y], [x - 10 * s, y + 24 * s], [x + 38 * s, y - 28 * s]], k); c.stroke(); c.restore();
}

function carimbo(c, t, t0, txt, x, y, { cor = PAL.vermelho, px = 96, rot = -0.14 } = {}) {
  const k = prog(t, t0, t0 + 0.22);
  if (k <= 0) return;
  const s = lerp(2.2, 1, E.out(k));
  c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s); c.globalAlpha *= clamp(k * 1.6);
  c.font = F.titulo(px); c.letterSpacing = '4px';
  const w = c.measureText(txt).width + 60, h = px * 1.25;
  c.strokeStyle = cor; c.lineWidth = 8; retRed(c, -w / 2, -h / 2, w, h, 14); c.stroke();
  c.fillStyle = cor; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(txt, 0, 4);
  c.restore();
}

function pessoa(c, x, y, s, cor, alpha = 1) {
  c.save(); c.globalAlpha *= alpha; c.fillStyle = cor;
  c.beginPath(); c.arc(x, y - 30 * s, 17 * s, 0, TAU); c.fill();
  retRed(c, x - 24 * s, y - 8 * s, 48 * s, 52 * s, 20 * s); c.fill();
  c.restore();
}

// toro 3D em arame (tokamak)
function toro(c, cx, cy, t, { R = 300, r = 112, incl = 1.12, giroY = 0, alpha = 1, cor = 'rgba(190,205,240,0.5)' } = {}) {
  const P = (u, v, rr = r) => {
    let p = [(R + rr * Math.cos(v)) * Math.cos(u), rr * Math.sin(v), (R + rr * Math.cos(v)) * Math.sin(u)];
    p = rotY(p, giroY); p = rotX(p, incl - Math.PI / 2 + Math.PI / 2);
    return p;
  };
  return P;
}

// ---------------- cenas ----------------
