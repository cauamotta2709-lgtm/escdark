#!/usr/bin/env node
// Laboratório Otaku: gera o vídeo 9:16 de um roteiro.
//
//   node renderizar.mjs <episodio>/roteiro.json --narracao <pasta com sNN.mp3 + sNN.json>
//   node renderizar.mjs <episodio>/roteiro.json --simular            (sem voz: tempos estimados)
//   node renderizar.mjs <episodio>/roteiro.json --simular --quadros 1,5.5,12   (ou --quadros cenas)
//   opções: --fps 60  --saida pasta  --arquivo final.mp4  --crf 17  --preset slow
//
// As cenas do episódio vêm do cenas.js ao lado do roteiro.json (ou do campo "cenas" do roteiro).
// Precisa de Node 18+, playwright-core (ou playwright) e ffmpeg/ffprobe no PATH. O navegador é o
// Chromium do Playwright, se instalado; senão o Microsoft Edge ou o Chrome do próprio PC.
import fs from 'node:fs';
import path from 'node:path';
import { spawn, execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { gerarSom, SR } from './som.mjs';

const require = createRequire(import.meta.url);
let chromium;
try { ({ chromium } = require('playwright')); } catch { ({ chromium } = require('playwright-core')); }
const AQUI = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const opt = (n, d) => { const i = args.indexOf('--' + n); return i >= 0 ? args[i + 1] : d; };
const tem = n => args.includes('--' + n);
const arquivo = args.find(a => a.endsWith('.json'));
if (!arquivo) { console.error('Uso: node renderizar.mjs roteiros/<roteiro>.json [--narracao pasta | --simular]'); process.exit(1); }

const roteiro = JSON.parse(fs.readFileSync(arquivo, 'utf8'));
const fps = Number(opt('fps', 60));
const crf = opt('crf', '17');
const arquivoFinal = opt('arquivo', null);
const saidaDir = path.resolve(opt('saida', arquivoFinal ? path.dirname(path.resolve(arquivoFinal)) : path.join(AQUI, 'saida')));
const preset = opt('preset', 'slow');
// episódio feito à mão traz cenas.js; o escrito pelo Roteirista usa só os tipos genéricos (motor/tipos.js)
const generico = roteiro.segmentos.every(s => s.tipo);
let cenasArq = path.resolve(path.dirname(path.resolve(arquivo)), roteiro.cenas || 'cenas.js');
if (!fs.existsSync(cenasArq)) {
  if (!generico) { console.error('Não achei as cenas do episódio: ' + cenasArq); process.exit(1); }
  cenasArq = null;
}
const pastaVoz = opt('narracao', null);
const simular = tem('simular') || !pastaVoz;
const quadros = opt('quadros', null);
fs.mkdirSync(saidaDir, { recursive: true });

// ---------- áudio: decodifica mp3 em float mono 48 kHz ----------
function decodificar(arq) {
  const buf = execFileSync('ffmpeg', ['-v', 'error', '-i', arq, '-f', 'f32le', '-ac', '1', '-ar', String(SR), '-'], { maxBuffer: 1 << 30 });
  return new Float32Array(buf.buffer, buf.byteOffset, buf.byteLength / 4);
}

// tempos estimados por sílaba quando não há narração
function estimar(texto) {
  const palavras = texto.split(/\s+/).filter(Boolean);
  let t = 0.05; const out = [];
  for (const w of palavras) {
    const sil = Math.max(1, (w.toLowerCase().match(/[aeiouáéíóúâêôãõà]+/g) || []).length);
    const num = /\d/.test(w) ? 0.25 * w.replace(/\D/g, '').length : 0;
    const d = 0.095 + sil * 0.135 + num;
    out.push({ w, t, d });
    t += d + (/[.,:;!?…]$/.test(w) ? (/[.!?…]$/.test(w) ? 0.32 : 0.16) : 0.02);
  }
  return out;
}

// ---------- linha do tempo ----------
const INICIO = 0.3;
let cursor = INICIO;
const segs = [], vozes = [];
for (const s of roteiro.segmentos) {
  let palavras, audio = null;
  if (!simular) {
    const j = JSON.parse(fs.readFileSync(path.join(pastaVoz, s.id + '.json'), 'utf8'));
    palavras = j.palavras.map(p => ({ w: p.w, t: p.t, d: p.d }));
    audio = decodificar(path.join(pastaVoz, s.id + '.mp3'));
    // a fala tem espaço no começo: alinha a primeira palavra no cursor
  } else palavras = estimar(s.texto);
  // palavras do edge-tts vêm sem pontuação; recoloca a do texto para a legenda quebrar certo
  const tokens = s.texto.split(/\s+/).filter(Boolean);
  if (tokens.length === palavras.length) palavras.forEach((p, i) => { p.w = tokens[i]; });
  else { let k = 0; for (const p of palavras) { const alvo = p.w.toLowerCase(); for (let j = k; j < tokens.length; j++) if (tokens[j].toLowerCase().replace(/[^\p{L}\p{N}]/gu, '') === alvo.replace(/[^\p{L}\p{N}]/gu, '')) { p.w = tokens[j]; k = j + 1; break; } } }
  const lead = palavras[0]?.t || 0;
  const t0 = cursor - lead;               // onde o arquivo de voz começa
  const fim = palavras.length ? palavras[palavras.length - 1].t + palavras[palavras.length - 1].d : 1;
  segs.push({ id: s.id, cena: s.cena, tipo: s.tipo || null, p: s.p || null, t0: cursor, t1: t0 + fim, palavras: palavras.map(p => ({ w: p.w, t: t0 + p.t, d: p.d })) });
  if (audio) vozes.push({ t0, audio });
  cursor = t0 + fim + (s.pausa ?? 0.3);
}
const duracao = cursor + 0.2;
console.log(`roteiro ${roteiro.slug}: ${segs.length} falas, ${duracao.toFixed(2)} s${simular ? ' (tempos simulados)' : ''}`);

// ---------- navegador ----------
const ARGS = ['--font-render-hinting=none', '--disable-lcd-text', '--force-color-profile=srgb', '--enable-gpu-rasterization'];
let browser = null, falhas = [];
for (const canal of [null, 'msedge', 'chrome']) {   // Chromium do Playwright; senão o Edge ou o Chrome do PC
  try { browser = await chromium.launch(canal ? { channel: canal, args: ARGS } : { args: ARGS }); break; }
  catch (e) { falhas.push((canal || 'chromium') + ': ' + String(e.message).split('\n')[0]); }
}
if (!browser) { console.error('Nenhum navegador abriu.\n' + falhas.join('\n')); process.exit(1); }
// página do episódio: o index.html do motor com o cenas.js do episódio no lugar marcado
const pagina = path.join(AQUI, 'motor', `_episodio-${process.pid}.html`);
fs.writeFileSync(pagina, fs.readFileSync(path.join(AQUI, 'motor', 'index.html'), 'utf8')
  .replace('<!--EPISODIO-->', cenasArq ? `<script src="${pathToFileURL(cenasArq).href}"></script>` : ''));
process.on('exit', () => { try { fs.unlinkSync(pagina); } catch {} });
const page = await browser.newPage({ viewport: { width: 1080, height: 1920 }, deviceScaleFactor: 1 });
page.on('pageerror', e => console.error('[página]', e.message));
page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') console.error('[console]', m.text()); });
await page.addInitScript(v => { window.VIDEO = v; }, { roteiro, segs, duracao });
await page.goto(pathToFileURL(pagina).href);
await page.waitForFunction(() => window.__pronto === true || window.__erro, null, { timeout: 30000 });
const erro = await page.evaluate(() => window.__erro);
if (erro) { console.error(erro); process.exit(1); }
const { cues, blocos } = await page.evaluate(() => ({ cues: window.__cues, blocos: window.__blocos }));
const cdp = await page.context().newCDPSession(page);
const foto = async (t, fmt = 'jpeg') => {
  await page.evaluate(s => window.__seek(s), t);
  const r = await cdp.send('Page.captureScreenshot', fmt === 'png' ? { format: 'png' } : { format: 'jpeg', quality: 95, optimizeForSpeed: false });
  return Buffer.from(r.data, 'base64');
};

if (quadros) {
  const lista = quadros === 'cenas' ? blocos.map(b => +(b.t0 + Math.min(2.2, (b.t1 - b.t0) * 0.6)).toFixed(2)) : quadros.split(',').map(Number);
  for (const q of lista) {
    const out = path.join(saidaDir, `${roteiro.slug}-q${q.toFixed(2).replace('.', '_')}.png`);
    fs.writeFileSync(out, await foto(q, 'png'));
    console.log('quadro', out);
  }
  console.log(JSON.stringify(blocos.map(b => [b.nome, +b.t0.toFixed(2), +b.t1.toFixed(2)])));
  await browser.close();
  process.exit(0);
}

// ---------- som: voz + trilha + efeitos, com a música abaixando sob a voz ----------
const { musica, sfx, N } = gerarSom({ duracao, cues, blocos, secoes: roteiro.musica || {} });
const voz = new Float32Array(N);
for (const v of vozes) { const i0 = Math.round(v.t0 * SR); for (let i = 0; i < v.audio.length && i0 + i < N; i++) if (i0 + i >= 0) voz[i0 + i] += v.audio[i]; }
// envelope da voz (ataque 15 ms, soltura 350 ms)
const env = new Float32Array(N);
{ let e = 0; const at = Math.exp(-1 / (0.015 * SR)), rl = Math.exp(-1 / (0.35 * SR));
  for (let i = 0; i < N; i++) { const x = Math.abs(voz[i]); e = x > e ? at * e + (1 - at) * x : rl * e + (1 - rl) * x; env[i] = e; } }
const L = new Float32Array(N), R = new Float32Array(N);
const gMus = simular ? 0.9 : 0.42;  // voz na frente: música mais baixa com narração
for (let i = 0; i < N; i++) {
  const duck = simular ? 1 : 1 - 0.65 * Math.min(1, env[i] * 9);
  L[i] = voz[i] * 1.0 + musica[0][i] * gMus * duck + sfx[0][i] * 0.8;
  R[i] = voz[i] * 1.0 + musica[1][i] * gMus * duck + sfx[1][i] * 0.8;
}
const wav = path.join(saidaDir, roteiro.slug + '.wav');
{ const dados = Buffer.alloc(N * 8); for (let i = 0; i < N; i++) { dados.writeFloatLE(L[i], i * 8); dados.writeFloatLE(R[i], i * 8 + 4); }
  const h = Buffer.alloc(44); h.write('RIFF', 0); h.writeUInt32LE(36 + dados.length, 4); h.write('WAVE', 8); h.write('fmt ', 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(3, 20); h.writeUInt16LE(2, 22); h.writeUInt32LE(SR, 24); h.writeUInt32LE(SR * 8, 28); h.writeUInt16LE(8, 32); h.writeUInt16LE(32, 34); h.write('data', 36); h.writeUInt32LE(dados.length, 40);
  fs.writeFileSync(wav, Buffer.concat([h, dados])); }
// loudness em duas passadas (-14 LUFS, pico -1 dBTP)
let ln = 'loudnorm=I=-14:TP=-1.0:LRA=11';
{
  const r = spawn('ffmpeg', ['-hide_banner', '-i', wav, '-af', 'loudnorm=I=-14:TP=-1.0:LRA=11:print_format=json', '-f', 'null', '-']);
  let err = ''; r.stderr.on('data', d => err += d); await new Promise(ok => r.on('close', ok));
  const m = err.match(/\{[\s\S]*?"input_i"[\s\S]*?\}/);
  if (m) { const j = JSON.parse(m[0]); ln = `loudnorm=I=-14:TP=-1.0:LRA=11:measured_I=${j.input_i}:measured_TP=${j.input_tp}:measured_LRA=${j.input_lra}:measured_thresh=${j.input_thresh}:offset=${j.target_offset}:linear=true`; }
}

// ---------- vídeo ----------
const mp4 = arquivoFinal ? path.resolve(arquivoFinal) : path.join(saidaDir, roteiro.slug + '.mp4');
const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error',
  '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'mjpeg', '-i', '-',
  '-i', wav, '-map', '0:v', '-map', '1:a', '-af', ln + ',aresample=48000',
  '-c:v', 'libx264', '-preset', preset, '-crf', crf, '-pix_fmt', 'yuv420p', '-profile:v', 'high', '-tune', 'animation',
  '-c:a', 'aac', '-b:a', '256k', '-ar', '48000', '-shortest', '-movflags', '+faststart', mp4], { stdio: ['pipe', 'ignore', 'pipe'] });
let ffErr = ''; ff.stderr.on('data', d => { ffErr += d; });
const fimFF = new Promise((ok, falha) => ff.on('close', c => c === 0 ? ok() : falha(new Error('ffmpeg: ' + ffErr.slice(-2000)))));
const total = Math.round(duracao * fps), t0 = Date.now();
for (let i = 0; i < total; i++) {
  const b = await foto(i / fps);
  if (!ff.stdin.write(b)) await new Promise(r => ff.stdin.once('drain', r));
  if (i % (fps * 5) === 0) { const el = (Date.now() - t0) / 1000; process.stdout.write(`  ${Math.round(100 * i / total)}%  ${el.toFixed(0)} s\n`); }
}
ff.stdin.end();
await fimFF;
fs.unlinkSync(wav);
// capa: o quadro mais forte da abertura
fs.writeFileSync(mp4.replace(/\.mp4$/i, '') + '-capa.jpg', await foto(Math.min(duracao - 0.5, (segs[0].t1 - 0.4))));
await browser.close();
console.log(`pronto em ${((Date.now() - t0) / 1000).toFixed(0)} s: ${mp4}`);
