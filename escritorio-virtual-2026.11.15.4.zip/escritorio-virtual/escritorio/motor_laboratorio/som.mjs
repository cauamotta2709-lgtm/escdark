// Laboratório Otaku: trilha e efeitos sonoros 100% sintetizados (sem samples, sem direitos autorais).
// gerarSom({ duracao, cues, blocos }) -> { musica:[L,R], sfx:[L,R] } em Float32Array a 48 kHz.
export const SR = 48000;
const TAU = Math.PI * 2;
const mtof = m => 440 * Math.pow(2, (m - 69) / 12);

function rng(seed) {
  let s = seed | 0;
  return () => { s = (s + 0x6D2B79F5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

class Biquad {
  constructor(tipo, f, q = 0.707) { this.tipo = tipo; this.x1 = this.x2 = this.y1 = this.y2 = 0; this.set(f, q); }
  set(f, q = this.q) {
    this.q = q; f = Math.max(20, Math.min(f, SR * 0.45));
    const w = TAU * f / SR, c = Math.cos(w), s = Math.sin(w), a = s / (2 * q);
    let b0, b1, b2;
    if (this.tipo === 'lp') { b0 = (1 - c) / 2; b1 = 1 - c; b2 = (1 - c) / 2; }
    else if (this.tipo === 'hp') { b0 = (1 + c) / 2; b1 = -(1 + c); b2 = (1 + c) / 2; }
    else { b0 = a; b1 = 0; b2 = -a; }
    const a0 = 1 + a;
    this.b0 = b0 / a0; this.b1 = b1 / a0; this.b2 = b2 / a0; this.a1 = -2 * c / a0; this.a2 = (1 - a) / a0;
  }
  p(x) { const y = this.b0 * x + this.b1 * this.x1 + this.b2 * this.x2 - this.a1 * this.y1 - this.a2 * this.y2; this.x2 = this.x1; this.x1 = x; this.y2 = this.y1; this.y1 = y; return y; }
}

// reverb de Schroeder simples (mono -> estéreo)
function reverb(entrada, { mix = 0.3, tam = 1 } = {}) {
  const N = entrada.length;
  const combs = [1557, 1617, 1491, 1422, 1277, 1356].map(n => Math.round(n * tam * SR / 44100));
  const L = new Float32Array(N), R = new Float32Array(N);
  const proc = (atrasos, saida, fb) => {
    const bufs = atrasos.map(n => ({ b: new Float32Array(n), i: 0, lp: 0 }));
    for (let i = 0; i < N; i++) {
      let s = 0;
      for (const c of bufs) { const y = c.b[c.i]; c.lp = y * 0.7 + c.lp * 0.3; c.b[c.i] = entrada[i] + c.lp * fb; c.i = (c.i + 1) % c.b.length; s += y; }
      saida[i] = s / bufs.length;
    }
    for (const n of [225, 556].map(n => Math.round(n * SR / 44100))) {
      const b = new Float32Array(n); let k = 0;
      for (let i = 0; i < N; i++) { const bv = b[k]; const y = -saida[i] + bv; b[k] = saida[i] + bv * 0.5; k = (k + 1) % n; saida[i] = y; }
    }
  };
  proc(combs.slice(0, 3).concat([combs[3] + 23]), L, 0.84);
  proc(combs.slice(2).concat([combs[0] + 37]), R, 0.84);
  for (let i = 0; i < N; i++) { L[i] *= mix; R[i] *= mix; }
  return [L, R];
}

export function gerarSom({ duracao, cues = [], blocos = [], bpm = 96, semente = 1, secoes = {} }) {
  const N = Math.ceil((duracao + 0.5) * SR);
  const r = rng(semente);
  const ruido = () => r() * 2 - 1;
  const mus = [new Float32Array(N), new Float32Array(N)];
  const fx = [new Float32Array(N), new Float32Array(N)];
  const envio = new Float32Array(N);
  const idx = t => Math.max(0, Math.round(t * SR));
  const pan = p => [Math.cos((p + 1) * Math.PI / 4), Math.sin((p + 1) * Math.PI / 4)];
  const add = (buf, i, v, p = 0, rev = 0) => { if (i < 0 || i >= N) return; const [a, b] = pan(p); buf[0][i] += v * a; buf[1][i] += v * b; if (rev) envio[i] += v * rev; };

  const BEAT = 60 / bpm, BAR = BEAT * 4;
  const bloco = nome => blocos.find(b => b.nome === nome);
  const tDe = (nome, padrao) => (bloco(nome) || { t0: padrao }).t0;
  const fimDe = (nome, padrao) => (bloco(nome) || { t1: padrao }).t1;
  // seções da música
  // cada seção começa no bloco indicado pelo roteiro ("musica": {grooveA: "<cena>", ...}); o padrão é o EXP. 001
  const NOME = { grooveA: 'minato', grooveB: 'patinadora', tensao: 'fusao', cheio: 'tokamak', pausa: 'medidor', fim: 'cta', ...secoes };
  const S = {
    grooveA: tDe(NOME.grooveA, BAR * 2), grooveB: tDe(NOME.grooveB, BAR * 8), tensao: tDe(NOME.tensao, BAR * 12),
    cheio: tDe(NOME.cheio, BAR * 14), pausa: tDe(NOME.pausa, duracao - BAR * 3), fim: tDe(NOME.fim, duracao - BAR * 1.5)
  };
  const tFusao = (cues.find(c => c.tipo === 'boom' && c.t > S.tensao) || { t: S.cheio }).t;

  // progressão em Ré menor: Dm - Bb - F - C (2 compassos cada)
  const PROG = [[62, 65, 69, 50], [62, 65, 70, 46], [60, 65, 69, 41], [60, 64, 67, 48]];
  const acorde = t => PROG[Math.floor(t / (BAR * 2)) % 4];

  // ---- pad (serras desafinadas com filtro) ----
  {
    const lp = [new Biquad('lp', 900, 0.6), new Biquad('lp', 900, 0.6)];
    const fases = [];
    for (let v = 0; v < 6; v++) fases.push(r());
    for (let i = 0; i < N; i++) {
      const t = i / SR;
      const ch = acorde(t);
      const brilho = t < S.grooveA ? 500 : t < S.tensao ? 800 : t < tFusao ? lerp2(800, 2600, (t - S.tensao) / Math.max(0.1, tFusao - S.tensao)) : t < S.pausa ? 1300 : 650;
      if (i % 64 === 0) { lp[0].set(brilho + 120 * Math.sin(t * 0.7)); lp[1].set(brilho + 120 * Math.sin(t * 0.7 + 1)); }
      // envelope de troca de acorde (ataque lento)
      const pos = (t % (BAR * 2)) / (BAR * 2);
      const env = Math.min(1, pos * 6) * (1 - Math.max(0, pos - 0.94) * 12);
      let sL = 0, sR = 0;
      for (let v = 0; v < 3; v++) {
        const f = mtof(ch[v]);
        for (const d of [-0.12, 0.12]) {
          const ph = (t * f * Math.pow(2, d / 12) + fases[v]) % 1;
          const saw = 2 * ph - 1;
          if (d < 0) sL += saw; else sR += saw;
        }
      }
      const fade = Math.min(1, t / 1.5) * Math.min(1, (duracao + 0.3 - t) / 1.2);
      const g = 0.045 * env * Math.max(0, fade);
      mus[0][i] += lp[0].p(sL) * g; mus[1][i] += lp[1].p(sR) * g;
      envio[i] += (sL + sR) * g * 0.15;
    }
  }
  function lerp2(a, b, k) { k = Math.max(0, Math.min(1, k)); return a + (b - a) * k; }

  // ---- drone grave ----
  for (let i = 0; i < N; i++) {
    const t = i / SR, ch = acorde(t);
    const f = mtof(ch[3] - 12);
    const fade = Math.min(1, t / 0.8) * Math.max(0, Math.min(1, (duracao + 0.3 - t) / 1.5));
    const v = (Math.sin(TAU * f * t) + 0.3 * Math.sin(TAU * f * 2 * t)) * 0.09 * fade * (t > S.pausa && t < S.fim ? 0.6 : 1);
    mus[0][i] += v; mus[1][i] += v;
  }

  // ---- bateria leve ----
  const kick = (t0, g = 1) => {
    const i0 = idx(t0), n = Math.round(0.45 * SR);
    for (let k = 0; k < n; k++) { const t = k / SR; const f = 45 + 95 * Math.exp(-t * 28); const ph = TAU * (45 * t + 95 * (1 - Math.exp(-t * 28)) / 28); add(mus, i0 + k, Math.sin(ph) * Math.exp(-t * 7) * 0.42 * g); void f; }
  };
  const hat = (t0, g = 1, p = 0.2) => {
    const i0 = idx(t0), n = Math.round(0.06 * SR), hp = new Biquad('hp', 7000, 0.8);
    for (let k = 0; k < n; k++) { const t = k / SR; add(mus, i0 + k, hp.p(ruido()) * Math.exp(-t * 70) * 0.08 * g, p); }
  };
  const rim = (t0, g = 1) => {
    const i0 = idx(t0), n = Math.round(0.12 * SR), bp = new Biquad('bp', 1800, 4);
    for (let k = 0; k < n; k++) { const t = k / SR; add(mus, i0 + k, (bp.p(ruido()) * 1.6 + Math.sin(TAU * 820 * t) * 0.4) * Math.exp(-t * 40) * 0.12 * g, -0.1, 0.3); }
  };
  for (let b = 0; b * BEAT < duracao; b++) {
    const t = b * BEAT;
    const tens = t >= S.tensao && t < tFusao;
    const pausa = t >= S.pausa && t < S.fim;
    if (t < S.grooveA || pausa || tens || t > duracao - BAR) continue;
    const cheio = t >= S.cheio;
    if (b % 4 === 0 || b % 4 === 2 || (cheio && b % 8 === 7)) kick(t, cheio ? 1 : 0.8);
    if (b % 4 === 2 && t >= S.grooveB) rim(t, cheio ? 1 : 0.7);
    hat(t + BEAT / 2, cheio ? 1 : 0.7, 0.25);
    if (cheio) { hat(t + BEAT / 4, 0.4, -0.25); hat(t + 3 * BEAT / 4, 0.45, -0.25); }
  }

  // ---- arpejo (triângulo com filtro) ----
  {
    const lp = new Biquad('lp', 2500, 0.9);
    const passo = BEAT / 4;
    for (let k = 0; k * passo < duracao; k++) {
      const t0 = k * passo;
      if (t0 < S.grooveB || (t0 >= S.tensao && t0 < tFusao) || t0 >= S.pausa) continue;
      const ch = acorde(t0), padrao = [0, 1, 2, 1, 0, 2, 1, 2];
      const m = ch[padrao[k % 8]] + (k % 16 >= 8 ? 12 : 0);
      const f = mtof(m), i0 = idx(t0), n = Math.round(0.22 * SR);
      const g = (t0 >= S.cheio ? 0.05 : 0.035) * (k % 4 === 0 ? 1.2 : 1);
      const p = Math.sin(k * 0.9) * 0.5;
      for (let j = 0; j < n; j++) { const t = j / SR; const ph = (t * f) % 1; const tri = 4 * Math.abs(ph - 0.5) - 1; add(mus, i0 + j, lp.p(tri) * Math.exp(-t * 14) * g, p, 0.5); }
    }
  }

  // ---- acorde final ----
  {
    const t0 = Math.max(0, duracao - 2.6), ch = [50, 57, 62, 65, 69];
    for (let i = idx(t0); i < N; i++) {
      const t = i / SR - t0; let s = 0;
      for (const m of ch) s += Math.sin(TAU * mtof(m) * t) + 0.25 * Math.sin(TAU * mtof(m) * 2 * t);
      const env = Math.min(1, t / 0.05) * Math.exp(-t * 0.9) * Math.max(0, Math.min(1, (duracao + 0.3 - i / SR) / 0.6));
      add(mus, i, s * 0.018 * env, 0, 0.6);
    }
  }

  // ================= efeitos =================
  const E = {
    whoosh(c) {
      const dur = c.dur || 0.42, i0 = idx(c.t - dur * 0.6), n = Math.round(dur * SR), bp = new Biquad('bp', 400, 1.2);
      for (let k = 0; k < n; k++) { const u = k / n; if (k % 32 === 0) bp.set(300 + 3500 * Math.sin(u * Math.PI)); const env = Math.sin(u * Math.PI) ** 2; add(fx, i0 + k, bp.p(ruido()) * env * 0.5 * (c.ganho ?? 1), lerp2(-0.6, 0.6, u), 0.2); }
    },
    boom(c) {
      const i0 = idx(c.t), n = Math.round(1.8 * SR), lp = new Biquad('lp', 900, 0.7);
      for (let k = 0; k < n; k++) { const t = k / SR; const ph = TAU * (38 * t + 80 * (1 - Math.exp(-t * 9)) / 9); const s = Math.sin(ph) * Math.exp(-t * 2.4) * 0.8 + lp.p(ruido()) * Math.exp(-t * 6) * 0.35; add(fx, i0 + k, s * (c.ganho ?? 1), 0, 0.25); }
    },
    impacto(c) {
      const i0 = idx(c.t), n = Math.round(0.7 * SR), lp = new Biquad('lp', 2500, 0.7);
      for (let k = 0; k < n; k++) { const t = k / SR; const s = Math.sin(TAU * (55 * t + 60 * (1 - Math.exp(-t * 20)) / 20)) * Math.exp(-t * 6) * 0.6 + lp.p(ruido()) * Math.exp(-t * 18) * 0.4; add(fx, i0 + k, s * (c.ganho ?? 1), 0, 0.3); }
    },
    tick(c) {
      const i0 = idx(c.t), n = Math.round(0.03 * SR);
      for (let k = 0; k < n; k++) { const t = k / SR; add(fx, i0 + k, Math.sin(TAU * 2400 * t) * Math.exp(-t * 260) * 0.22 * (c.ganho ?? 1), 0.15); }
    },
    pop(c) {
      const i0 = idx(c.t), n = Math.round(0.18 * SR), f0 = mtof(74 + (c.nota || 0));
      for (let k = 0; k < n; k++) { const t = k / SR; const f = f0 * (1 + 0.5 * Math.exp(-t * 60)); add(fx, i0 + k, Math.sin(TAU * f * t) * Math.exp(-t * 26) * 0.3 * (c.ganho ?? 1), 0, 0.35); }
    },
    ding(c) {
      const i0 = idx(c.t), n = Math.round(1.4 * SR);
      for (let k = 0; k < n; k++) { const t = k / SR; const s = Math.sin(TAU * 1318.5 * t) * 0.6 + Math.sin(TAU * 1975.5 * t) * 0.3 + Math.sin(TAU * 2637 * t) * 0.15; add(fx, i0 + k, s * Math.exp(-t * 4) * 0.16 * (c.ganho ?? 1), 0.1, 0.6); }
    },
    erro(c) {
      const i0 = idx(c.t), n = Math.round(0.42 * SR), lp = new Biquad('lp', 1400, 0.8);
      for (let k = 0; k < n; k++) { const t = k / SR; const ph = (t * 110) % 1, ph2 = (t * 116.5) % 1; const g = t < 0.18 || t > 0.22 ? 1 : 0; add(fx, i0 + k, lp.p((2 * ph - 1) + (2 * ph2 - 1)) * g * Math.exp(-t * 3) * 0.13 * (c.ganho ?? 1)); }
    },
    carimbo(c) {
      const i0 = idx(c.t), n = Math.round(0.5 * SR), lp = new Biquad('lp', 1800, 0.7);
      for (let k = 0; k < n; k++) { const t = k / SR; const s = Math.sin(TAU * (70 * t + 40 * (1 - Math.exp(-t * 30)) / 30)) * Math.exp(-t * 14) * 0.7 + lp.p(ruido()) * Math.exp(-t * 30) * 0.6; add(fx, i0 + k, s * (c.ganho ?? 1), 0, 0.2); }
    },
    risco(c) {
      const i0 = idx(c.t), n = Math.round(0.28 * SR), bp = new Biquad('bp', 3000, 2);
      for (let k = 0; k < n; k++) { const u = k / n; if (k % 32 === 0) bp.set(2000 + 3000 * u); add(fx, i0 + k, bp.p(ruido()) * Math.sin(u * Math.PI) * 0.5 * (c.ganho ?? 1), lerp2(-0.5, 0.5, u)); }
    },
    subida(c) {
      const dur = Math.max(0.3, c.dur || 1), i0 = idx(c.t), n = Math.round(dur * SR), bp = new Biquad('bp', 300, 3);
      for (let k = 0; k < n; k++) { const u = k / n, t = k / SR; if (k % 32 === 0) bp.set(250 + 4000 * u * u); const f = 110 + 500 * u * u; const s = bp.p(ruido()) * 0.6 + Math.sin(TAU * f * t) * 0.12; add(fx, i0 + k, s * u * u * 0.55 * (c.ganho ?? 1), 0, 0.3); }
    },
    estouro_agua(c) {
      const i0 = idx(c.t), n = Math.round(1.1 * SR), lp = new Biquad('lp', 3000, 0.7), bp = new Biquad('bp', 900, 2);
      for (let k = 0; k < n; k++) { const t = k / SR; let s = lp.p(ruido()) * Math.exp(-t * 9) * 0.7 + Math.sin(TAU * (60 * t + 50 * (1 - Math.exp(-t * 25)) / 25)) * Math.exp(-t * 10) * 0.6; if (k % 900 < 300 && t > 0.05) s += bp.p(ruido()) * Math.exp(-t * 4) * 0.5; add(fx, i0 + k, s * (c.ganho ?? 1), 0, 0.3); }
      for (let j = 0; j < 14; j++) { const tg = c.t + 0.1 + r() * 0.8, f = 600 + r() * 1400, i1 = idx(tg), m = Math.round(0.05 * SR); for (let k = 0; k < m; k++) { const t = k / SR; add(fx, i1 + k, Math.sin(TAU * f * (1 + t * 8) * t) * Math.exp(-t * 80) * 0.12, r() * 2 - 1, 0.4); } }
    },
    estouro(c) {
      const i0 = idx(c.t), n = Math.round(1 * SR), lp = new Biquad('lp', 5000, 0.7);
      for (let k = 0; k < n; k++) { const t = k / SR; const s = lp.p(ruido()) * Math.exp(-t * 12) * 0.9 + Math.sin(TAU * (48 * t + 70 * (1 - Math.exp(-t * 18)) / 18)) * Math.exp(-t * 5) * 0.7; add(fx, i0 + k, s * (c.ganho ?? 1), 0, 0.3); }
    },
    trava(c) {
      for (const [dt, f] of [[0, 2200], [0.07, 3100]]) { const i0 = idx(c.t + dt), n = Math.round(0.05 * SR); for (let k = 0; k < n; k++) { const t = k / SR; add(fx, i0 + k, (Math.sin(TAU * f * t) + ruido() * 0.5) * Math.exp(-t * 120) * 0.35, 0.1); } }
      E.ding({ t: c.t + 0.12, ganho: 0.4 });
    },
    zumbido(c) {
      const dur = c.dur || 2, i0 = idx(c.t), n = Math.round(dur * SR), lp = new Biquad('lp', 800, 2);
      for (let k = 0; k < n; k++) { const t = k / SR, u = k / n; const env = Math.min(1, u * 5) * Math.min(1, (1 - u) * 6); const s = (Math.sin(TAU * 110 * t) + 0.5 * Math.sin(TAU * 220.7 * t) + 0.3 * ((t * 55) % 1 * 2 - 1)) * (0.7 + 0.3 * Math.sin(TAU * 7 * t)); add(fx, i0 + k, lp.p(s) * env * 0.12 * (c.ganho ?? 1)); }
    },
    plasma(c) {
      const dur = c.dur || 5, i0 = idx(c.t), n = Math.round(dur * SR), bp = new Biquad('bp', 500, 1.5), lp = new Biquad('lp', 300, 1);
      for (let k = 0; k < n; k++) { const t = k / SR, u = k / n; if (k % 64 === 0) bp.set(500 + 300 * Math.sin(t * 2.3)); const env = Math.min(1, u * 8) * Math.min(1, (1 - u) * 8); const s = bp.p(ruido()) * 0.5 + lp.p((t * 60) % 1 * 2 - 1) * 0.6; add(fx, i0 + k, s * env * 0.16 * (c.ganho ?? 1), Math.sin(t * 0.8) * 0.5, 0.2); }
    },
    zap(c) {
      const i0 = idx(c.t), n = Math.round(0.6 * SR), hp = new Biquad('hp', 1200, 0.8);
      for (let k = 0; k < n; k++) { const t = k / SR; const crack = (r() < 0.25 ? ruido() : 0); const s = hp.p(crack) * Math.exp(-t * 6) * 1.1 + Math.sin(TAU * (120 + 60 * Math.sin(t * 40)) * t) * Math.exp(-t * 4) * 0.25; add(fx, i0 + k, s * (c.ganho ?? 1), 0, 0.3); }
    },
    vento(c) {
      const dur = c.dur || 4, i0 = idx(c.t), n = Math.round(dur * SR), bp = new Biquad('bp', 500, 0.8);
      for (let k = 0; k < n; k++) { const t = k / SR, u = k / n; if (k % 64 === 0) bp.set(380 + 260 * Math.sin(t * 1.7) + 140 * Math.sin(t * 4.1)); const env = Math.min(1, u * 4) * Math.min(1, (1 - u) * 4); add(fx, i0 + k, bp.p(ruido()) * env * 0.5 * (c.ganho ?? 1), Math.sin(t * 1.2) * 0.7, 0.2); }
    }
  };
  for (const c of cues) { if (E[c.tipo]) E[c.tipo](c); else console.warn('efeito desconhecido', c.tipo); }

  const [rL, rR] = reverb(envio, { mix: 0.35 });
  for (let i = 0; i < N; i++) { mus[0][i] += rL[i] * 0.6; mus[1][i] += rR[i] * 0.6; }
  return { musica: mus, sfx: fx, N };
}
