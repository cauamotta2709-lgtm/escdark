"""Laboratório Otaku: o formato "laboratorio" (desde a versão 2026.11.15.1).

Cada vídeo é um episódio feito 100% por código, sem imagem de IA nem foto da internet:
  escritorio/bancos/<canal>/episodios/<NNN-slug>/roteiro.json  (falas, título, descrição, hashtags)
  escritorio/bancos/<canal>/episodios/<NNN-slug>/cenas.js      (as animações daquele episódio)
Também vale a mesma estrutura em canais/<canal>/episodios/ (episódios que você colocar à mão).

Os episódios novos são escritos pelo Roteirista (escritorio/roteirista.py) a partir do banco de temas
pesquisados (bancos/<canal>/temas.json): cada tema vira um roteiro.json que usa as animações prontas
do motor (motor/tipos.js), sem precisar de cenas.js.

A linha de produção fica assim:
  Olheiro     pega o próximo episódio; se não houver, chama o Roteirista para escrever um
  Carregador  narra cada fala com o edge-tts, guardando o tempo de cada palavra
  Legendador  só copia título, descrição e hashtags do roteiro (a legenda é desenhada pelo motor)
  Editor      roda o motor (escritorio/motor_laboratorio/renderizar.mjs): Node + navegador + ffmpeg
  Postador    controle de qualidade e pacote em canais/<canal>/prontos/

O motor precisa do Node.js e do pacote playwright-core. `preparar()` instala os dois sozinho no
Windows (Node pelo winget, playwright-core pelo npm na pasta do motor). O navegador usado é o
Microsoft Edge que já vem no Windows, então não baixa nenhum navegador extra.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import threading
import time
from pathlib import Path

from . import canais, roteirista
from .nucleo import Job, medir_pid

MOTOR = Path(__file__).resolve().parent / "motor_laboratorio"
FORMATO = "laboratorio"
_trava_preparo = threading.Lock()
_pronto: bool | None = None
_motivo = ""


# ---------------------------------------------------------------- episódios
def _pastas_episodios(canal: str) -> list[Path]:
    """Pastas de episódio do canal, primeiro as dele, depois as que vieram nas atualizações."""
    achadas, vistos = [], set()
    for base in (canais.pasta(canal) / "episodios", canais.EXTRAS / canal / "episodios"):
        for p in sorted(base.glob("*/roteiro.json")) if base.is_dir() else []:
            if p.parent.name not in vistos:
                vistos.add(p.parent.name)
                achadas.append(p.parent)
    return sorted(achadas, key=lambda p: p.name)


def episodios(canal: str) -> list[dict]:
    """Episódios válidos do canal: {"id", "pasta", "roteiro"}. Um com erro é pulado com aviso."""
    lista = []
    for pasta in _pastas_episodios(canal):
        try:
            roteiro = canais.ler(pasta / "roteiro.json")
            cenas = pasta / (roteiro.get("cenas") or "cenas.js")
            generico = all(s.get("tipo") for s in roteiro.get("segmentos") or [{}])
            if not roteiro.get("segmentos") or not (cenas.is_file() or generico):
                raise ValueError("faltam os segmentos ou o cenas.js")
        except (OSError, ValueError) as e:
            print(f"[laboratorio] episódio {pasta.name} ignorado: {e}", flush=True)
            continue
        lista.append({"id": pasta.name, "pasta": pasta, "roteiro": roteiro})
    return lista


# ---------------------------------------------------------------- banco de temas + Roteirista
def temas(canal: str) -> list[dict]:
    """Temas pesquisados do canal (o canal pode ter o próprio temas.json, que ganha do da atualização)."""
    return roteirista.carregar_temas([canais.pasta(canal) / "temas.json", canais.EXTRAS / canal / "temas.json"])


def _temas_livres(canal: str) -> list[dict]:
    """Temas que ainda não viraram episódio (a pasta NNN-<tema> marca o tema como escrito)."""
    escritos = {p.name.split("-", 1)[-1] for p in _pastas_episodios(canal)}
    try:
        fora = canais.indisponiveis(canais.pasta(canal) / "usados.json")
    except (OSError, ValueError):
        fora = set()
    escritos |= {str(x).split("-", 1)[-1] for x in fora}
    return [t for t in temas(canal) if t["id"] not in escritos]


def _numero_seguinte(canal: str) -> int:
    maior = 0
    for pasta in _pastas_episodios(canal):
        m = re.match(r"(\d+)-", pasta.name)
        if m:
            maior = max(maior, int(m.group(1)))
    try:  # episódios já postados e apagados do PC continuam contando
        for x in canais.indisponiveis(canais.pasta(canal) / "usados.json"):
            m = re.match(r"(\d+)-", str(x))
            if m:
                maior = max(maior, int(m.group(1)))
    except (OSError, ValueError):
        pass
    return maior + 1


def escrever_episodio(canal: str, cfg: dict | None = None, log=print) -> Path | None:
    """O Roteirista escreve o próximo episódio a partir do banco de temas. Devolve a pasta (ou None)."""
    livres = _temas_livres(canal)
    if not livres:
        return None
    tema = livres[0]
    numero = _numero_seguinte(canal)
    roteiro = roteirista.escrever(tema, numero, cfg or {}, log)
    pasta = canais.pasta(canal) / "episodios" / roteiro["slug"]
    pasta.mkdir(parents=True, exist_ok=True)
    (pasta / "roteiro.json").write_text(json.dumps(roteiro, ensure_ascii=False, indent=1), encoding="utf-8")
    return pasta


def tem_episodios(canal: str) -> bool:
    return bool(_pastas_episodios(canal)) or bool(temas(canal))


def proximo(job: Job, canal: str, cfg: dict | None = None, log=print) -> dict | None:
    """O primeiro episódio que ainda não virou vídeo, já reservado para este job (ou None).
    Sem episódio pronto, o Roteirista escreve um novo a partir do banco de temas."""
    arq = canais.pasta(canal) / "usados.json"
    for tentativa in range(2):
        fora = canais.indisponiveis(arq)
        for ep in episodios(canal):
            if ep["id"] not in fora:
                canais.reservar(job, arq, [ep["id"]])
                return ep
        if tentativa == 0 and not escrever_episodio(canal, cfg, log):
            break
    return None


def restantes(canal: str) -> int:
    try:
        fora = canais.indisponiveis(canais.pasta(canal) / "usados.json")
    except (OSError, ValueError):
        return 0
    return sum(1 for ep in episodios(canal) if ep["id"] not in fora) + len(_temas_livres(canal))


def montar(job: Job, ep: dict) -> None:
    """Preenche o job com o episódio escolhido."""
    r = ep["roteiro"]
    job.tema = r.get("poder") or r.get("titulo") or ep["id"]
    job.roteiro = [s["texto"] for s in r["segmentos"]]
    job.arquivos["episodio"] = str(ep["pasta"])
    job.arquivos["roteiro_lab"] = r
    fontes = r.get("fontes_dos_fatos") or []
    job.referencia = {"titulo": r.get("titulo", ep["id"]), "formato": FORMATO, "episodio": ep["id"],
                      "fonte": fontes[0] if fontes and isinstance(fontes[0], str) else ""}


# ---------------------------------------------------------------- Node + playwright-core
def achar_node() -> str | None:
    achado = shutil.which("node")
    if achado:
        return achado
    if os.name == "nt":  # o winget instala, mas a janela já aberta não enxerga o PATH novo
        for base in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                     os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                     os.path.expandvars(r"%LocalAppData%\Programs")):
            exe = Path(base) / "nodejs" / "node.exe"
            if exe.is_file():
                os.environ["PATH"] = f"{exe.parent}{os.pathsep}{os.environ.get('PATH', '')}"
                return str(exe)
    return None


def _npm(node: str) -> list[str]:
    pasta = Path(node).parent
    for nome in ("npm.cmd", "npm"):
        if (pasta / nome).is_file():
            return [str(pasta / nome)]
    achado = shutil.which("npm")
    return [achado] if achado else []


def _modulo_ok() -> bool:
    return any((MOTOR / "node_modules" / m / "package.json").is_file() for m in ("playwright-core", "playwright"))


def preparar(log=print, instalar: bool = True) -> bool:
    """Garante Node + playwright-core para o motor. Devolve True se dá para renderizar."""
    global _pronto, _motivo
    with _trava_preparo:
        if _pronto:
            return True
        node = achar_node()
        if not node and instalar and os.name == "nt" and shutil.which("winget"):
            log("instalando o Node.js pelo winget (uma vez só; aceite se o Windows pedir)")
            subprocess.run(["winget", "install", "-e", "--id", "OpenJS.NodeJS.LTS", "--silent",
                            "--accept-source-agreements", "--accept-package-agreements"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            node = achar_node()
        if not node:
            _pronto, _motivo = False, "o Node.js não está instalado (rode instalar.bat de novo)"
            return False
        if not _modulo_ok() and instalar:
            npm = _npm(node)
            if npm:
                log("instalando o playwright-core na pasta do motor (uma vez só, ~10 MB)")
                env = {**os.environ, "PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD": "1"}
                r = subprocess.run([*npm, "install", "--no-audit", "--no-fund", "--omit=dev"], cwd=MOTOR, env=env,
                                   capture_output=True, text=True, encoding="utf-8", errors="replace",
                                   shell=os.name == "nt" and npm[0].endswith(".cmd"))
                if r.returncode != 0:
                    log(f"npm install falhou: {(r.stderr or r.stdout)[-300:]}")
        if not _modulo_ok():
            _pronto, _motivo = False, "falta o playwright-core (rode `npm install` em escritorio/motor_laboratorio)"
            return False
        _pronto, _motivo = True, ""
        return True


def motivo() -> str:
    return _motivo


# ---------------------------------------------------------------- narração
def narrar(agente, job: Job, cfg: dict) -> Path:
    """Narra cada fala com o edge-tts (sNN.mp3 + sNN.json com o tempo de cada palavra)."""
    pasta = job.pasta / "narracao"
    pasta.mkdir(parents=True, exist_ok=True)
    segs = job.arquivos["roteiro_lab"]["segmentos"]
    voz = cfg.get("voz_edge", "pt-BR-AntonioNeural")
    for i, s in enumerate(segs, 1):
        agente.tarefa(f"narrando a fala {i} de {len(segs)} (job {job.id})")
        mp3 = pasta / f"{s['id']}.mp3"
        palavras = agente.edge(s["texto"], mp3, cfg)  # [(início, fim, palavra)]
        if not palavras:
            raise RuntimeError(f"o edge-tts não mandou o tempo das palavras na fala {s['id']}")
        (pasta / f"{s['id']}.json").write_text(json.dumps({
            "texto": s["texto"], "voz": voz, "rate": cfg.get("voz_edge_velocidade", "+8%"),
            "palavras": [{"t": round(a, 3), "d": round(b - a, 3), "w": w} for a, b, w in palavras]},
            ensure_ascii=False, indent=1), encoding="utf-8")
    job.arquivos["narracao"] = str(pasta)
    job.arquivos["voz"] = "edge-tts"
    return pasta


# ---------------------------------------------------------------- render
def renderizar(agente, job: Job, cfg: dict) -> Path:
    """Roda o motor e devolve o mp4. Mostra o progresso no painel."""
    if not preparar(agente.log):
        raise RuntimeError("o motor do Laboratório não está pronto: " + motivo())
    node = achar_node()
    ep = Path(job.arquivos["episodio"])
    final = job.pasta / "final.mp4"
    cmd = [node, str(MOTOR / "renderizar.mjs"), str(ep / "roteiro.json"),
           "--narracao", job.arquivos["narracao"], "--arquivo", str(final),
           "--fps", str(cfg.get("lab_fps", 60)), "--crf", str(cfg.get("crf", 17)),
           "--preset", str(cfg.get("lab_preset", cfg.get("preset", "slow")))]
    with agente.vaga_pesada("renderizar o episódio"):
        proc = subprocess.Popen(cmd, cwd=MOTOR, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, encoding="utf-8", errors="replace")
        erros: list[str] = []
        threading.Thread(target=lambda: erros.extend(proc.stderr), daemon=True).start()
        limite = time.time() + float(cfg.get("lab_timeout_s", 4 * 3600))
        cpu_contada = 0.0
        for linha in proc.stdout:  # "  37%  210 s" a cada 5 s de vídeo
            m = re.match(r"\s*(\d+)%\s+(\d+) s", linha)
            if m:
                pct, gasto = int(m.group(1)), int(m.group(2))
                falta = f", faltam ~{max(1, round(gasto * (100 - pct) / max(pct, 1) / 60))} min" if pct >= 3 else ""
                agente.tarefa(f"desenhando o episódio quadro a quadro: {pct}%{falta} (job {job.id})")
                cpu, _ = medir_pid(proc.pid)
                if cpu > cpu_contada:
                    agente.tele.somar(agente.chave, cpu_s=cpu - cpu_contada)
                    cpu_contada = cpu
            elif linha.startswith("roteiro "):
                agente.log(linha.strip())
            if time.time() > limite or agente.parar.is_set():
                proc.kill()
                raise RuntimeError("render do episódio passou do tempo limite ou foi interrompido")
        proc.wait()
    if proc.returncode != 0 or not final.is_file():
        raise RuntimeError("o motor falhou: " + "".join(erros)[-500:])
    job.arquivos["final"] = str(final)
    capa = final.with_name("final-capa.jpg")
    if capa.is_file():
        job.arquivos["capa"] = str(capa)
    return final
